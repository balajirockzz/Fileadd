//
// Example code, not for use in production environments.
//

define(['vb/BusinessObjectsTransforms',], (businessObjectsTransforms) => {
'use strict';

    // Overridden Request transform
    class Request {
         /**
          * @typedef {Object} Configuration
          * @property {Object} fetchConfiguration configuration for the current fetch call
          * @property {Object} endpointDefinition metadata for the endpoint
          * @property {Object} parameters: Path and query parameters. These are not writable.
          * @property {Object} initConfig map of other configuration passed into the request. The
          * 'initConfig' exactly matches the 'init' parameter of the request.
          * @property {string} url full url of the request.
          */

        /**
         * @typedef {Object} PaginateOptions
         * @property {number} iterationLimit
         * @property {number} offset which item the response should begin from
         * @property {String} pagingState
         * @property {number} size how many items should be returned
         */

        /**
         * paginate function appends limit and offset parameters to the url
         * @param {Configuration} configuration
         * @param {PaginateOptions} options
         * @returns {Configuration} configuration object
         */
        paginate(configuration, options) {
            // TODO: Add code here
            return businessObjectsTransforms.request.paginate(configuration, options);
        }

        /**
         * filter builds filter expression query parameter using either the deprecated
         * filterCriteria array or filterCriterion object set on the options.
         * @param {Configuration} configuration
         * @param {Object} options
         * @param {Object} transformsContext a transforms context object that can be used by authors of transform
         * functions to store contextual information for the duration of the request.
         * @returns {Configuration} configuration object, the url looks like ?filter=foo eq bar
         */

        filter(configuration, options, transformsContext) {
            // TODO: Add code here

            if(options && options.text)
            // options.text = options.text.toUpperCase();
            
            // if(transformsContext['vb-textFilterAttributes'] && transformsContext['vb-textFilterAttributes'].length>0){
            //   transformsContext['vb-textFilterAttributes'][0] = '('+transformsContext['vb-textFilterAttributes'][0]+')';
            // }

            if (transformsContext['vb-textFilterAttributes'] &&
    transformsContext['vb-textFilterAttributes'].length > 0 &&
    transformsContext['vb-textFilterAttributes'][0] === "DisplayName") {

    // Ensure filtering happens only on PersonNumber
    transformsContext['vb-textFilterAttributes'] = ["DisplayName"];
}

             let returnVal = businessObjectsTransforms.request.filter(configuration, options, transformsContext);


             if(returnVal.url.includes('OPEX') ){
             returnVal.url = returnVal.url.replace('%20%3E%20' , '%20LIKE%20').replace('OPEX','6');
             }
             else{
              if(returnVal.url.includes('DDDD'))
             returnVal.url =   returnVal.url.replace('%20%3E%20' , '%20IN%20(').replaceAll('DDDD','\'')+(')');
            //  returnVal.url =   returnVal.url.replace('\'(' , '(').replaceAll(')/',')');
             }

             return returnVal;
        }

        /**
         * sort the 'uriParameters' property is passed in as options. Normally uriParameters are appended
         * to the URL automatically, but there may be cases where the user would want to adjust the query parameters.
         * @param {Configuration} configuration
         * @param {Array} options
         * @returns {Configuration} configuration object, the url looks like ?orderBy=foo:asc
         */
        sort(configuration, options) {
            // TODO: Add code here
            return businessObjectsTransforms.request.sort(configuration, options);
        }

        /**
         * select typically uses the 'responseType' to construct a query parameter to select and expand
         * the fields returned from the service
         * Example:
         *
         * Employee
         * - firstName
         * - lastName
         * - department
         *   - items[]
         *     - departmentName
         *     - location
         *        - items[]
         *          - locationName
         *
         * would result in this 'fields' query parameter:
         *
         *   fields=firstName,lastName;department:departmentName;department.location:locationName
         *
         * Another multi-level example:
         *   fields=PartyId;Address:PartyId,AddressId;Address.AddressPurpose:Purpose,AddressPurposeId
         *
         *   {
         *     "PartyId": 100000013637002,
         *         "Address": [
         *             {
         *                 "PartyId": 100000013637002,
         *                 "AddressId": 100000013637005,
         *                 "AddressPurpose": [
         *                     {
         *                         "Purpose": "SELL_TO",
         *                         "AddressPurposeId": 100000013637018
         *                     }
         *                 ]
         *             }
         *         ]
         *     }
         *
         * 'options' has two optional properties:
         * - type: a VB type
         * - fields: an array of fields, whose structure is defined by the dynamic UI components:
         *    type attrs = Array<string | { name: string, attributes?: attrs }>
         *
         * Both 'type' and 'fields' will be used when creating the "fields=" query
         *
         * @param {Configuration} configuration
         * @param {Object} options
         * @return {Object} configuration object
         */
        select(configuration, options) {
            // TODO: Add code here
            return businessObjectsTransforms.request.select(configuration, options);
        }

        /**
         * fetchByKeys is called when the current fetch call is a fetch to get one or more keys.
         * A getAll endpoint can be used for multikey lookup using 'q' param.
         * A getOne endpoint generally needs a single key to be used in the path param.
         * This transform is called by itself. The other transforms are called only when fetchFirst or fetchByOffset is
         * used.
         * @param {Configuration} configuration
         * @return {Configuration} configuration object
         */
        fetchByKeys(configuration) {
            // TODO: Add code here
            return businessObjectsTransforms.request.fetchByKeys(configuration);
        }
    }

    // Overridden Response transform
   class Response {
        /**
         * paginate response transform
         * @param {Object} configuration the Response object
         * @param {Object} context a transforms context object that can be used by authors of transform
         * functions to access/store contextual information for the duration of the request.
         * @returns {Object}
         */
        paginate(configuration, context) {
            // TODO: Add code here
            return businessObjectsTransforms.response.paginate(configuration, context);
        }
    }

    return {
        request: Request,
        response: Response
    };
});