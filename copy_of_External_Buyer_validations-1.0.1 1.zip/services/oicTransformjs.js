//
// Example code, not for use in production environments.
//
define(['services/customTransform',], (customTransform) => {
'use strict';

  // Overridden Request transform
  class Request extends customTransform.request {
    filter(configuration, options, transformsContext) {
			// TODO: Add code here
		}
		sort(configuration, options, transformsContext) {
			// TODO: Add code here
		}

  }

  // Overridden Response transform
  class Response extends customTransform.response {
    
  }

  return {
    request: Request,
    response: Response
  };
});