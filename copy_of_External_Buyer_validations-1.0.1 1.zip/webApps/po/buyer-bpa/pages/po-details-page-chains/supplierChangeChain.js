define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class supplierChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.details 
     */
    async run(context, { details }) {
      const { $page, $flow, $application } = context;

      await $application.functions.openSpinnerDialog();

  //     await Actions.resetVariables(context, {
  //       variables: [
  //   '$flow.variables.transReqDetails.supplier_site',
  // ],
  //     });

      if( details && details.SupplierId) {

        const results = await Promise.all([
          async () => {

      const response = await Actions.callRest(context, {
            endpoint: 'fscm/getSuppliersSite',
            uriParams: {
              q: 'SupplierSite in '+ $application.functions.getInClause($flow.variables.supplierAssoc.supplierSiteList),
              SupplierId: details.SupplierId,
            },
      });

          
                  if (response.ok) {
                
               $page.variables.supplierSIteADP.data = response.body.items;
                  }
            
           
          },
          async () => {

            const response2 = await Actions.callRest(context, {
              endpoint: 'fscm/getSupplierContacts',
              uriParams: {
                id: details.SupplierId,
              },
            });

            if (response2.ok) {
              let items =response2.body.items;
              $page.variables.supplierContactsADP.data = items;

              if(items.length >0){
                $flow.variables.transReqDetails.supplier_contact_id = items[0].SupplierContactId;
               $flow.variables.transReqDetails.supplier_contact = items[0].LastName+', '+items[0].FirstName;
              }
            
            }
          },
        ].map(sequence => sequence()));

      }
      else{
      $page.variables.supplierSIteADP.data = [];
      }

      $page.variables.SupplierId = details.SupplierId;
      $flow.variables.transReqDetails.supplier =details.Supplier;

      await $application.functions.closeSpinnerDialog();
    }
  }

  return supplierChangeChain;
});
