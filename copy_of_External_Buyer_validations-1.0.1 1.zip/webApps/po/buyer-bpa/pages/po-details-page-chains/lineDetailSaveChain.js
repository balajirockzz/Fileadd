define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class lineDetailSaveChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {number} params.lineId 
     */
    async run(context, { lineId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if ($application.functions.isFormValid('line_form')) {
     

      if (lineId) {

        await Actions.fireDataProviderEvent(context, {
          target: $variables.requestLinesADP,
          remove: {
            data: lineId,
            keys: lineId.request_line_id,
          },
        });
      } else {

        if ($application.functions.isFormValid('line_form')) {    

             $variables.lineDetails.created_by = $application.user.username;
         $variables.lineDetails.updated_by = $application.user.username;

          if ($variables.lineDetails.request_line_id) {
            await Actions.fireDataProviderEvent(context, {
              update: {
                data: $variables.lineDetails,
                keys: $variables.lineDetails.request_line_id,
              },
              target: $variables.requestLinesADP,
            });
          }
          else {
            $variables.lineDetails.request_line_id = $variables.requestLinesADP.data.length + 1;
            $variables.lineDetails.line_num = $variables.requestLinesADP.data.length + 1;
            await Actions.fireDataProviderEvent(context, {
              add: {
                data: $variables.lineDetails,
                keys: $variables.lineDetails.request_line_id,
                indexes: 0,
              },
              target: $variables.requestLinesADP,
            });
          }
        }
       
      }

      const lineDialogClose = await Actions.callComponentMethod(context, {
        selector: '#lineDialog',
        method: 'close',
      });
    }
     }
  }

  return lineDetailSaveChain;
});
