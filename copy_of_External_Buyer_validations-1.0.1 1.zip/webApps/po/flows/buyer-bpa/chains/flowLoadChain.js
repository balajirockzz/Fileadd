define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class flowLoadChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $flow, $application, $constants, $variables } = context;

      await $application.functions.openSpinnerDialog();

      let buyerGroups=[];
      let supplierList=[];
      let supplierSiteList=[];
      let buList=[];
      let orgList=[];
      let buyerList=[];
      let supAssocList =[];

            $variables.transferStatusADP.data = [{ label: 'Draft', value: 'DRAFT' }, 
      { label: 'Approved', value: 'APPROVED' },
      { label: 'Rejected', value: 'REJECTED' },
      { label: 'Open', value: 'OPEN' },
      { label: 'In-Complete', value: 'INCOMPLETE' },
      { label: 'Withdrawn', value: 'WITHDRAWN' },
      { label: 'Pending Approval', value: 'PENDING APPROVAL' }, 
      { label: 'Error', value: 'ERROR' }];


            $variables.communicationMethodADP.data = [
  {
     label: 'None', value: 'NONE'
  },
  {
        label: 'E-Mail',value: 'EMAIL'
  },
  {
    label: 'Fax',value: 'FAX'
  },
  {
    label: 'Print',value: 'PRINT'
  },
];
    

          if(1 === 1){
      
      const response = await Actions.callRest(context, {
        endpoint: 'fscm_conn/getCommonLookups',
        uriParams: {
          LookupType: 'BUYER TO BUYER GROUP',
          q: 'Meaning='+$application.user.username,
        },
      });

      if (response.ok) {
         response.body.items.forEach( (item)=>{
          buyerGroups.push(item.Tag);
        });

          const results = await Promise.all([
            async () => {

         const response2 = await Actions.callRest(context, {
                endpoint: 'fscm_conn/getCommonLookups',
                uriParams: {
                  LookupType: 'BUYER GROUP TO SUPPLIER',
                },
              });

              if (response2.ok) {
                const results2 = await ActionUtils.forEach(response2.body.items, async (item, index) => {
                  if(item.lookupsDFF && item.lookupsDFF.items){
                    item.lookupsDFF.items.forEach((rec)=>{
                     if(buyerGroups.includes(rec.externalBuyerCompanyCode)){
                      supAssocList.push(rec.externalBuyerCompanyCode);
                      if(!buList.includes(rec.externalBuyerBu))
                         buList.push(rec.externalBuyerBu);
                      if(!orgList.includes(item.Meaning))
                         orgList.push(item.Meaning);
                          if(!supplierList.includes(item.Description))
                         supplierList.push(item.Description);
                          if(!supplierSiteList.includes(item.Tag))
                         supplierSiteList.push(item.Tag);
                     }
                    });


                  }
                }, { mode: 'serial' });

                 const response4 = await Actions.callRest(context, {
                endpoint: 'fscm_conn/getPartsShippingMethodsLOV',
                uriParams: {
                  q: 'OrganizationCode in '+$application.functions.getInClause(orgList)
                },
              });

              if (response4.ok) {
                $flow.variables.shippingMethodADP.data = response4.body.items;

              }
              
              }
            },
            async () => {

              const response3 = await Actions.callRest(context, {
        endpoint: 'fscm_conn/getCommonLookups',
        uriParams: {
              LookupType: 'BUYER TO BUYER GROUP',
              q: 'Tag in '+$application.functions.getInClause(buyerGroups),
        },
      });

              if (response3.ok) {
                 const results2 = await ActionUtils.forEach(response3.body.items, async (item, index) => {
                  if(!buyerList.includes(item.Meaning))
                         buyerList.push(item.Meaning);
                 });
              }
            },
            async () => {
              const response5 = await Actions.callRest(context, {
                endpoint: 'fscm_conn/getPayablesPaymentTermsLOV',
              });

              if (response5.ok) {
                $flow.variables.paymentTermADP.data = response5.body.items;
              }
            },
            async () => {
              const response7 = await Actions.callRest(context, {
                endpoint: 'businessObjects/getall_POStylesBO',
                uriParams: {
                  limit: 100,
                },
              });

              if (response7.ok) {
                
                $flow.variables.poStylesADP.data = response7.body.items;
              }
            },
          ].map(sequence => sequence()));

      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Rest API Error',
        });
      }
          }
     let supplierAssocation =  {"supAssocList": supAssocList,
      "buyerList":buyerList ,"orgList":orgList,"buList" : buList,
      "supplierSiteList":supplierSiteList ,"supplierList":supplierList,
      "buyerGroups": buyerGroups
      };

      $flow.variables.supplierAssoc = supplierAssocation;
      $flow.variables.procurementBU.data = $application.functions.getLOV(buList);
      $flow.variables.buyerADP.data = $application.functions.getLOV(buyerList);
      // const response6 = await Actions.callRest(context, {
      //           endpoint: 'fscm_conn/getProcurementPersonsLOV',
      //           uriParams: {
      //             q: 'PersonNumber in '+$application.functions.getInClause(buyerList),
      //           },
      //         });

      //         if (response6.ok) {
      //           $flow.variables.buyerADP.data = response6.body.items;
              
         
      //         }
      

      console.log(supplierAssocation);
      
    }
      

  }
  
  return flowLoadChain;
});
