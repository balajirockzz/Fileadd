/* Copyright (c) 2024, Oracle and/or its affiliates */

define(['knockout',
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ko,
  ActionChain,
  Actions
) => {
  'use strict';

  class spSaveChain extends ActionChain {

    /**
     * Submit form data
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.submit 
     */
    async run(context, { submit = 'N' }) {
      const { $page, $flow, $variables, $application, $functions } = context;

      // await $application.functions.isFormValid('hdr_form');
        let bodyvar ={};
       let updateBpa ={
    "BatchId": 115582,
    "ActionCode": "UPDATE",
    "ProcurementBU": "Vision Operations",
    "AgreementNumber": 1003356,
    "Supplier": "CV_SuppA01",
    "SupplierSite": "CVSuppA01Site01",
    "ChangeOrderDescription": "End date the agreement",
    "ChangeOrderInitiatingParty": "BUYER",
    "StartDate": "2025-01-01",
    "EndDate": "2025-06-01",
   // "Buyer":"",
    "PaymentTerms":"",
    "FreightTerms":"",
    "NoteToSupplier":"",
    "NoteToReceiver":"",
    "Description":"",
    "FOB":""
};     
       let lines = $page.variables.requestLinesADP.data;
       let controls = $page.variables.businessControlsADP.data;
       let isFailed = false;
      if ($application.functions.isFormValid('hdr_form') && lines.length >0 && controls.length >0 && $page.variables.submitComments) {

         
         delete $flow.variables.transReqDetails.FreightTermsCode;
         delete $flow.variables.transReqDetails.FOBCode;
         delete $flow.variables.transReqDetails.DocumentStyle;
         delete $flow.variables.transReqDetails.DocumentStyleId;
         delete $flow.variables.transReqDetails.DocumentStyleTemp;
         
         $flow.variables.transReqDetails.lines = lines;
         $flow.variables.transReqDetails.businessUnitAccess = controls;
         
          $flow.variables.transReqDetails.BatchId =Date.now();
        //  $flow.variables.transReqDetails.AgreementNumber = 'BPO'+Math.floor(Date.now()/1000);

        const response4 = await Actions.callRest(context, {
          endpoint: 'FSCMApiConnection/getFinBusinessUnitsLOV',
          uriParams: {
            q: "BusinessUnitName="+"'"+$variables.clientbu_var+"'",
          },
        });

        await Actions.fireNotificationEvent(context, {
          summary: response4.body.items[0].LegalEntityId,
          message: 'LegalEntityId',
        });
        const response5 = await Actions.callRest(context, {
          endpoint: 'FSCMApiConnection/getLegalEntitiesLOVLegalEntityId',
          uriParams: {
            LegalEntityId: response4.body.items[0].LegalEntityId,
          },
        });

        await Actions.fireNotificationEvent(context, {
          summary: response5.body.LegalEntityIdentifier,
          message: 'LegalEntityIdentifierNumber',
        });

        const response6 = await Actions.callRest(context, {
          endpoint: 'ords_conn/getStp_extBpaAgreementnum',
        });

// $flow.variables.transReqDetails.AgreementNumber = 'BPO'+Date.now();
    $flow.variables.transReqDetails.AgreementNumber = 'BPAE'+response5.body.LegalEntityIdentifier+response6.body.nextval;

        if (!$variables.headerId) {
                           
                           $flow.variables.transReqDetails.ActionCode ="ORIGINAL";
                           bodyvar = JSON.parse(JSON.stringify($flow.variables.transReqDetails)); 

        }
        else {
               delete $flow.variables.transReqDetails.CreatedBy;
               updateBpa.BatchId = Date.now();
               updateBpa.ProcurementBU = $flow.variables.transReqDetails.ProcurementBU;
               updateBpa.AgreementNumber = $flow.variables.transReqDetails.AgreementNumber;
               updateBpa.AgreementAmount = $flow.variables.transReqDetails.AgreementAmount;
               updateBpa.Supplier = $flow.variables.transReqDetails.Supplier;
               updateBpa.SupplierSite = $flow.variables.transReqDetails.SupplierSite;
               updateBpa.ChangeOrderDescription =$variables.submitComments;
               updateBpa.StartDate = $flow.variables.transReqDetails.StartDate;
               updateBpa.EndDate = $flow.variables.transReqDetails.EndDate;
              // updateBpa.Buyer = $flow.variables.transReqDetails.Buyer;
               updateBpa.PaymentTerms = $flow.variables.transReqDetails.PaymentTerms;
               updateBpa.FreightTerms = $flow.variables.transReqDetails.FreightTerms;
               updateBpa.NoteToReceiver = $flow.variables.transReqDetails.NoteToReceiver;
               updateBpa.NoteToSupplier = $flow.variables.transReqDetails.NoteToSupplier;
               updateBpa.Description = $flow.variables.transReqDetails.Description;
               updateBpa.FOB = $flow.variables.transReqDetails.FOB;
               bodyvar = updateBpa;
               bodyvar.lines = lines;
               bodyvar.businessUnitAccess = controls;
        }

        await Actions.callChain(context, {
          chain: 'CancelBPOLines',
        });


        bodyvar.lines.forEach((item,i)=>{
          let isUpdate = false;
          if($variables.bpoDetails && $variables.bpoDetails.lines){
          $variables.bpoDetails.lines.items.forEach((line) => {
        
            if(line.AgreementLineId === item.AgreementLineId)
              isUpdate = true;
          });
        
          }
          // delete bodyvar.lines[i].CreatedBy;
          //    delete bodyvar.lines[i].CreationDate;
          //    delete bodyvar.lines[i].LastUpdatedBy;
          //    delete bodyvar.lines[i].LastUpdateDate;
        
          if(!isUpdate){
            delete bodyvar.lines[i].AgreementLineId;
        
            delete bodyvar.lines[i].Description; 
        
            delete bodyvar.lines[i].ItemNumber;
            delete bodyvar.lines[i].price;
        
          }
          else{
            let updatedItem = {
            "ActionCode": "SYNC",
            "LineNumber": bodyvar.lines[i].LineNumber,
            "Price": bodyvar.lines[i].Price,
            "SupplierItem":bodyvar.lines[i].SupplierItem,
            "AgreementQuantity":bodyvar.lines[i].AgreementQuantity,
            //"Status":bodyvar.lines[i].Status,
        };
            bodyvar.lines[i] = updatedItem;
          }
        
        
        
        });
        
        
            bodyvar.businessUnitAccess.forEach((item,i)=>{
          let isUpdate = false;
          if($variables.bpoDetails && $variables.bpoDetails.businessUnitAccess){
          $variables.bpoDetails.businessUnitAccess.items.forEach((line) => {
        
            if(line.OrganizationAssignmentId === item.OrganizationAssignmentId)
              isUpdate = true;
          });
        
          }
        
          bodyvar.businessUnitAccess[i].BillToBUId = bodyvar.businessUnitAccess[i].BillToBUId || bodyvar.businessUnitAccess[i].BilltoBUId;
          if(bodyvar.businessUnitAccess[i].BilltoBUId)
           delete bodyvar.businessUnitAccess[i].BilltoBUId;
        
          if(!isUpdate){
            delete bodyvar.businessUnitAccess[i].OrganizationAssignmentId;
        
          }
          else{
        
             let updatedItem = {
            // "ActionCode": "SYNC",
            "RequisitioningBU": bodyvar.businessUnitAccess[i].RequisitioningBU,
            "EnabledFlag": bodyvar.businessUnitAccess[i].EnabledFlag,
             "PurchasingSite": bodyvar.businessUnitAccess[i].PurchasingSite,
            "ShipToLocation": bodyvar.businessUnitAccess[i].ShipToLocation,
            "BillToBU": bodyvar.businessUnitAccess[i].BillToBU,
            "BillToLocation": bodyvar.businessUnitAccess[i].BillToLocation,
        };
          //  delete bodyvar.businessUnitAccess[i] ;        
          // delete bodyvar.businessUnitAccess.shift();    
          bodyvar.businessUnitAccess[i] = updatedItem;
          }
          
        
        
        
        });
               
           
        // if ( $variables.allowPriceOverrideflag  === 'Y') {
        
        // $variables.lineDetails.AllowPriceOverrideFlag = 'true';
        // }
        // else{
        //    $variables.lineDetails.AllowPriceOverrideFlag = 'false';
        // }

           bodyvar.DocumentTypeCode = "BLANKET";

          bodyvar.SupplierContactId = null;
          // delete $flow.variables.transReqDetails.CreatedBy;
               
                  //  $flow.variables.transReqDetails.SupplierCommunicationMethodCode = $flow.variables.transReqDetails.SupplierCommunicationMethodCode ? ($flow.variables.transReqDetails.SupplierCommunicationMethodCode).toUpperCase() : null;
               
                                  //  if ($flow.variables.transReqDetails.SupplierCommunicationMethodCode === 'E-MAIL'){
                                  //   $flow.variables.transReqDetails.SupplierCommunicationMethodCode = "EMAIL"; 
                                  //  }




      //  $flow.variables.transReqDetails.SUBMIT =  submit === 'Y' ? 'SUBMIT' : ($flow.variables.transReqDetails.po_status ?  $flow.variables.transReqDetails.po_status:'DRAFT'); 
        const response = await Actions.callRest(context, {
          endpoint: 'fscm_conn/CreatePurchaseAgreementImportRequests',
          body: bodyvar,
        });

        if (!response.ok) {
          const statusText = await $functions.getStatusText(response.status);

           isFailed =true;
          await Actions.fireNotificationEvent(context, {
            message: 'Rest API Error',
            summary: statusText,
          });
        } else {

          if(response.body.X_RETURN_CODE === 'ERROR'){
             isFailed =true;
                await Actions.fireNotificationEvent(context, {
                  summary: 'BPA Save failed',
                  displayMode: 'transient',
                  type: 'confirmation',
                  message: response.body.X_RETURN_MESSAGE,
                });

          }
          
          else
          if(submit === 'Y'){
            const response2 = await Actions.callRest(context, {
              endpoint: 'fscm_conn/postPurchaseAgreementImportRequests',
              uriParams: {
                'header_id': response.body.InterfaceHeaderId.toString(),
              },
              body: {
                documentTypeCode: 'BLANKET',
                procurementBU: response.body.ProcurementBU,
                defaultBuyer: $flow.variables.transReqDetails.Buyer ,
                approvalActionCode: 'SUBMIT',
                communicateAgreementsFlag: null,
                importSource: null,
                batchId: response.body.BatchId.toString(),
                createOrUpdateItemFlag: null,
              },
//              contentType: 'application/vnd.oracle.adf.action+json',
            });
            if(response2.ok) {

              const inputString = response2.body.result;
              const startIndex = inputString.indexOf("Request ID ") + "Request ID ".length;
              const endIndex = inputString.indexOf(" was submitted.");
              const requestId = inputString.substring(startIndex, endIndex);
              
              console.log("requestId",+requestId);

              const essResult= await Actions.callChain(context, {
                chain: 'ESSJobStatusCheckActionChain',
                params: {
                  ESSJobID: requestId,
                },
              });
              $flow.variables.FlowESSCheck = essResult;

             console.log("essResult",+essResult);
              if ($variables.ESSJobComplted === true) {


               const error_response= await Actions.callRest(context, {
                  endpoint: 'fscm_conn/getPurchasingDocumentImportErrors',
                  uriParams: {
                    q: "RequestId=" + requestId,
                  },
                });

                if (response2.body.Status === 'ERROR') {
                  await Actions.fireNotificationEvent(context, {
                    summary: "Errored occured while creating BPO" +error_response.body.items[0].ErrorMessage,
                    type: 'error',
                  });

                  isFailed =true;
                }
                else{
                  $variables.BPAAgrementNumberReqPayload.loadRequestId = requestId;

                  const response3 = await Actions.callRest(context, {
                    endpoint: 'ics_conn/PurchaseAgreementAgreementNumberandErros',
                    body: $variables.BPAAgrementNumberReqPayload,
                  });

                  if (response3.body.AgreementNumber) {

                    await Actions.fireNotificationEvent(context, {
                      summary: "BPA Number-" +response3.body.AgreementNumber,
                      type: 'confirmation',
                    });
               

                  } else {
                     await Actions.fireNotificationEvent(context, {
                       summary: 'Import Process Submited: '+requestId,
                       type: 'confirmation',
                     });
                  }

                }
              }
              
              
             
          }
          else{
            isFailed = true;
             await Actions.fireNotificationEvent(context, {
            summary: 'PO submittion failed',
            displayMode: 'transient',
            type: 'error',
          });
          }
          }
          else{

          }
         
        }

       

        if(!isFailed)
        await Actions.callChain(context, {
          chain: 'spCancelChain',
        });
      
      }
       else {
        await Actions.fireNotificationEvent(context, {
          displayMode: 'transient',
          summary: 'Missing required fields'+(lines.length < 1? ': Atleast One Item Details is mandatory':''),
        });
        
      }

    }
  }

  return spSaveChain;
});
