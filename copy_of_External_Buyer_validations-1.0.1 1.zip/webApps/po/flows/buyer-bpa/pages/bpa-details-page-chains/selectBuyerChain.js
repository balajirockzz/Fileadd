define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class selectBuyerChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $variables, $functions } = context;

      // const response = await Actions.callRest(context, {
      //   endpoint: 'fscm_conn/getProcurementPersonsLOV',
      // });

      await Actions.fireNotificationEvent(context, {
        summary: data.DISPLAY_NAME,
        message: data.PERSON_ID,
      });
     
      $flow.variables.transReqDetails.Buyer = data.DISPLAY_NAME;


            await Actions.resetVariables(context, {
        variables: [
    '$page.variables.ExternalIdentifiersADP_copy.data',
  ],
      });

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.ExternalIdentifiersADP_copy,
      });


 const getWorkerss = await Actions.callRest(context, {
   endpoint: 'hcm_conn/getWorkers',
   uriParams: {
     q: "PersonNumber=" + data.PERSON_NUMBER,
   },
 });

      if (getWorkerss.ok === true) {
        $variables.ExternalIdentifiersADP_copy.data = getWorkerss.body.items[0].externalIdentifiers;

        const externalIdentifierNumbers = await $functions.getExternalIdentifierNumber($variables.ExternalIdentifiersADP_copy.data, 'Legacy Dell NT Domain\\User');

        // ---- TODO: Add your code here ---- //
        console.log("externalIdentifierNumber-"+externalIdentifierNumbers);
        $variables.Ext_Num_var = externalIdentifierNumbers;

        $variables.lineDetails.LineAttribute10 = $variables.Ext_Num_var;

        await Actions.fireNotificationEvent(context, {
          summary: $variables.Ext_Num_var,
          message: 'ext',
        });
      }


      
    }
  }

  return selectBuyerChain;
});
