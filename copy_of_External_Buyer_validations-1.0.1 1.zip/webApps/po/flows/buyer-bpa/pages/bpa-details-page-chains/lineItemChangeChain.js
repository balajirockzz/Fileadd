define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class lineItemChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables } = context;

   

      // ---- TODO: Add your code here ---- //
      console.log(key);
      console.log(data);
      console.log(metadata);

      if(!data)
       data = metadata.detail.itemContext.data;

      $variables.lineDetails.Item = data.ItemNumber;
      $variables.lineDetails.ItemDescription = data.ItemDescription;
       $variables.lineDetails.Description = data.ItemDescription;
      // $variables.lineDetails.attribute1 = data.OrganizationCode;
      $variables.lineDetails.UOM = data.PrimaryUOMName;
      // $variables.lineDetails.organization_code = data.OrganizationCode;
      // $variables.lineDetails.line_type = data.InventoryItemFlag ? 'Goods':'Rate Based Services';
      $variables.lineDetails.LineNumber = $page.variables.requestLinesADP.data.length + 1;
      // $variables.lineDetails.item_description = data.item_description;

      const results = await Promise.all([
        async () => {

          const response2 = await Actions.callRest(context, {
            endpoint: 'fscm_conn/getItems',
            uriParams: {
              expand: 'ItemCategories',
              q: "ItemNumber = '"+data.ItemNumber+"' and OrganizationCode= '"+data.OrganizationCode+"'",
              fields: 'ItemCategories',
            },
          });

          if (!response2.ok) {
            // if(response2.items.length >0 && response2.items[0].ItemCategories && response2.items[0].ItemCategories.items[0].CategoryName)
            // $variables.lineDetails.category_name = response2.items[0].ItemCategories.items[0].CategoryName; 
            // else
            // $variables.lineDetails.category_name = "Goods";

          }
        },
               async () => {
                    const response3 = await Actions.callRest(context, {
             endpoint: 'fscm_conn/getItemsV2_2',
             uriParams: {
               q: "ItemNumber='"+ data.ItemNumber +"' AND OrganizationCode='"+ data.OrganizationCode +"'",
               fields: 'ItemNumber,OrganizationCode,DefaultBuyerValue',
             },
           });

             const hrefValue = response3.body.items[0].links[0].href;

          const href_var = hrefValue.split('/').pop();

          $variables.hnsec_var = href_var;

          await Actions.fireNotificationEvent(context, {
            summary: $variables.hnsec_var,
          });

            let onecostbody = {
  "ocPriceCallRequest": {
    "messageTimeStamp": "2025-02-19T00:00:00.000+00:00",
    "senderID": "",
    "receiverID": "",
    "organizationCode": data.OrganizationCode,
    "checkSourcingLaneFlag": "N",
    "priceType": "",
    "messageID": "",
    "itemList": {
      "item": [{
        "itemNumber": data.ItemNumber,
        "supplierNumber":  $variables.supplierNumber ,
        "supplierSiteId":  $flow.variables.transReqDetails.SupplierSite,
        "effectiveDate": "2025-02-19T00:00:00.000+00:00"
      }]
    },
    "toLocation": $flow.variables.transReqDetails.ShipToLocationCode ,
    "documentStyle": $flow.variables.transReqDetails.DocumentStyle 
  }
};

    let response = await Actions.callRest(context, {
      endpoint: 'ics_conn/postSTP_PROC_INT_012_1_0GetItemOneCost',
      body: onecostbody,
    });

          if (response.ok) {
             $variables.lineDetails.Price = Number(response.body.ocPriceCallResponse.itemList.item[0].ocPrice);
              $variables.lineDetails.LineAttribute4 = response.body.ocPriceCallResponse.itemList.item[0].ocPrice ? Number(response.body.ocPriceCallResponse.itemList.item[0].ocPrice) : null;
               $variables.lineDetails.LineAttribute5 = response.body.ocPriceCallResponse.itemList.item[0].priceType ? response.body.ocPriceCallResponse.itemList.item[0].priceType : null;
            $variables.lineDetails.LineAttribute6 = '50'
          }
        },
      ].map(sequence => sequence()));

    }
  }

  return lineItemChangeChain;
});
