define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class CollectionToolbarSpAddChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

 await Actions.fireNotificationEvent(context, {
   summary: $variables.controlDetails.RequisitioningBU,
 });

      await Actions.fireNotificationEvent(context, {
        summary: $variables.SupplierId,
        message: 'supplier id',
      });

      await Actions.fireNotificationEvent(context, {
        summary: $flow.variables.transReqDetails.SupplierSiteId,
        message: 'supplier site',
      });

      await Actions.fireNotificationEvent(context, {
        message: 'procuremnet BU',
        summary: $flow.variables.transReqDetails.ProcurementBU,
      });


      if ($variables.businessControlsADP.data.length) {

        await Actions.resetVariables(context, {
          variables: [
    '$page.variables.lineDetails',
  ],
        });

    $page.variables.lineDetails = {};
    $page.variables.lineDetails.AllowPriceOverrideFlag = true;
    $page.variables.lineDetails.AttributeCategory = $flow.variables.transReqDetails.AttributeCategory;
    $page.variables.lineDetails.LineAttribute10 = $variables.Ext_Num_var;

    let loc_var='LocationCode='+"'"+$variables.Location_var+"'";

        const response = await Actions.callRest(context, {
          endpoint: 'hcm_conn/getLocationsV2_2',
          uriParams: {
            q: loc_var,
          },
        });

                    if (!response.ok) {
          $variables.org_Error_var = 'OrganizationName='+"'"+' '+"'";
          
          
        } else {

          //  let organization_var='OrganizationName='+"'"+response.body.items[0].InventoryOrganizationName+"'";
          $variables.org_Error_var = 'OrganizationName='+"'"+response.body.items[0].InventoryOrganizationName+"'";

        }

        const response2 = await Actions.callRest(context, {
          endpoint: 'fscm_conn/getInventoryOrganizations2',
          uriParams: {
            q: $variables.org_Error_var,
          },
        });

          if (!response2.ok) {
        } else {
          $variables.organizationCode = response2.body.items[0].OrganizationCode;
        }

        const lineDialogOpen = await Actions.callComponentMethod(context, {
          selector: '#lineDialog',
          method: 'open',
        });
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Please Add The Control Details',
        });
      }
    }
  }

  return CollectionToolbarSpAddChain;
});
