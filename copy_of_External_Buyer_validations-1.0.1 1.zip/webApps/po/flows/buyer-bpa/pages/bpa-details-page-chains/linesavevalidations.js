define([
  'vb/action/actionChain',
    'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class linesavevalidations extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const progresBarOpen = await Actions.callComponentMethod(context, {
        selector: '#ProgresBar',
        method: 'open',
      });

      // MAV_PUR_DOC_ATTR_XREF
      const response11 = await Actions.callRest(context, {
        endpoint: 'FSCMApiConnection/getCommonLookupsTypeChildLookupCodes2',
        uriParams: {
          type: 'STP_CMN_PURDOCATTRXREF_LKP',
        },
      });

      const filterOrgs = await $functions.filterOrgs(response11.body.items, $variables.organizationCode);

      $variables.RequireForLovalidation = filterOrgs;

      await Actions.fireNotificationEvent(context, {
        summary: $variables.RequireForLovalidation,
      });

      await Actions.fireNotificationEvent(context, {
        summary: $variables.clientbu_var,
        message: $variables.lineDetails.Item,
      });

            // find supplier address id
            const response2 = await Actions.callRest(context, {
              endpoint: 'FSCMApiConnection/getSuppliersSupplieridChildSitesSiteid',
              uriParams: {
                supplierid: $variables.SupplierId,
                siteid: $flow.variables.transReqDetails.SupplierSiteId,
              },
            });
// add the address id with supplier id
      const response3 = await Actions.callRest(context, {
        endpoint: 'FSCMApiConnection/getSuppliersSupplierIdChildAddressesSupplierAddressId',
        uriParams: {
          SupplierAddressId: response2.body.SupplierAddressId,
          SupplierId: $variables.SupplierId,
          fields: 'AddressName,CountryCode,Country,City',
        },
      });

            $variables.Country_var = response3.body.CountryCode;

      await Actions.fireNotificationEvent(context, {
        summary: $variables.Country_var,
        message: 'Country',
      });

      // to check the requestion bu and get the loaction id
      const response4 = await Actions.callRest(context, {
        endpoint: 'FSCMApiConnection/getFinBusinessUnitsLOV',
        uriParams: {
          q: "BusinessUnitName="+"'"+ $variables.clientbu_var+"'",
          onlyData: 'true',
        },
      });

if (response4.body.items[0].LocationId === null || response4.body.items[0].LocationId === undefined) {
        $variables.location_id_var = 0;
      } else {
        $variables.location_id_var = response4.body.items[0].LocationId;
      }

      await Actions.fireNotificationEvent(context, {
        summary: $variables.location_id_var,
        message: 'location Id var',
      });

      // by passing the location id need to get the country code
      const response5 = await Actions.callRest(context, {
        endpoint: 'hcm_conn/getLocations',
        uriParams: {
          q: "LocationId="+$variables.location_id_var,
        },
      });

      await Actions.fireNotificationEvent(context, {
        message: 'locationid',
        summary: response5.body.items[0].Country,
      });

      if ($variables.Country_var === 'IN' && response5.body.items[0].Country === 'IN') {

        await Actions.fireNotificationEvent(context, {
          summary: '1',
        });

        // validate both the country codes
        const checkCountry2 = await $functions.checkCountry($variables.Country_var, response5.body.items[0].Country);

        // to check wheather the po is there in service level or not/MAV_PROC_BU_LINE_OF_SERVICE
        const response = await Actions.callRest(context, {
          endpoint: 'fscm_conn/getCommonLookups',
          uriParams: {
            q: "Tag IN ('SERVICE','MANUFACTURING') and Meaning=" + "'"+ $flow.variables.transReqDetails.ProcurementBU+"'",
            LookupType: 'STP_PROC_EXT_024_BULINESER_LKP',
          },
        });

                  // to find the hsnsac code
                  const response6 = await Actions.callRest(context, {
                    endpoint: 'fscm_conn/getItemsV2ItemidChildItemEffCategoryCategoryidChildItemEFFBTaxPrivateVO',
                    uriParams: {
                      fields: 'hsnSac',
                      categoryid: $variables.hnsec_var,
                      itemid: $variables.hnsec_var,
                    },
                  });

        await Actions.fireNotificationEvent(context, {
          summary: response6.body.items[0].hsnSac,
        });

        // to get the output as true or false
        const checkStatus2 = await $functions.checkStatus(response.body.count, checkCountry2, response6.body.items[0].hsnSac);

        await Actions.fireNotificationEvent(context, {
          summary: checkStatus2,
        });

        if (checkStatus2 === "true") {

          const response10 = await Actions.callRest(context, {
            endpoint: 'FSCMApiConnection/getTaxRegistrations',
            uriParams: {
              q: "PartyName="+"'"+$flow.variables.transReqDetails.Supplier+"'"+"and PartyCountryCode ='IN'",
            },
          });

          if (response10.body.items[0].RegistrationStatusCode === 'REGISTERED') {
            $variables.line_valid_var = 'Yes';
          } else {
            $variables.line_valid_var = 'No';
          }
        } else {
          $variables.line_valid_var = 'FalseHsnc';
        }
      } else if ($variables.RequireForLovalidation === 'true') {
        await Actions.fireNotificationEvent(context, {
          summary: '2',
        });

        // for taking count/MAV_CN_EXCLD_PO_STYLE_L_O_CODE
        const response7 = await Actions.callRest(context, {
          endpoint: 'fscm_conn/getCommonLookups',
          uriParams: {
            LookupType: 'STP_CMN_CN_EXCLPOSTYLOCODE_LKP',
            q: "Meaning="+"'"+ $flow.variables.transReqDetails.DocumentStyle+"'",
            onlyData: 'true',
          },
        });

        if (response7.body.count === 0) {
          await Actions.fireNotificationEvent(context, {
            summary: 'zero',
          });

          await Actions.fireNotificationEvent(context, {
            summary: $flow.variables.transReqDetails.CurrencyCode,
            message: 'currency code',
          });

          await Actions.fireNotificationEvent(context, {
            summary: $flow.variables.transReqDetails.ProcurementBU,
            message: 'procurement BU',
          });

          // MAV_BU_LOCAL_CURRENCY
          const response8 = await Actions.callRest(context, {
            endpoint: 'fscm_conn/getCommonLookups',
            uriParams: {
              LookupType: 'STP_CMN_BULOCALCURRENCY_LKP',
              q: "Meaning="+"'"+ $flow.variables.transReqDetails.ProcurementBU+"'",
              onlyData: 'true',
              fields: 'Tag',
            },
          });

          if (response8.body.count === 0) {
            $variables.tag_var = 'null';
          } else {
            $variables.tag_var = response8.body.items[0].Tag;
          }

          await Actions.fireNotificationEvent(context, {
            summary: $variables.tag_var,
          });

          const response9 = await Actions.callRest(context, {
            endpoint: 'FSCMApiConnection/getItemsV2IdChildItemEffCategoryId2ChildItemEFFBCompliancePrivateVO2',
            uriParams: {
              id: $variables.hnsec_var,
              id2: $variables.hnsec_var,
            },
          });

          const polovalidation = await $functions.polovalidation(response9.body.items[0].localOverseasCode, $variables.tag_var, $flow.variables.transReqDetails.CurrencyCode);

          $variables.line_valid_var = polovalidation;
        } else {
          await Actions.fireNotificationEvent(context, {
            summary: 'one',
          });

          $variables.line_valid_var = 'Yes';
        }
      } else {
        $variables.line_valid_var = 'Yes';
      }

      const progresBarClose = await Actions.callComponentMethod(context, {
        selector: '#ProgresBar',
        method: 'close',
      });

    }
  }

  return linesavevalidations;
});
