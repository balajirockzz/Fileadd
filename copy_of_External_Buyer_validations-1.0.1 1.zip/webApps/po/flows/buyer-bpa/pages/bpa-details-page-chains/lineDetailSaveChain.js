define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class lineDetailSaveChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {number} params.lineId 
     */
    async run(context, { lineId }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

    


      await Actions.callChain(context, {
        chain: 'linesavevalidations',
      });

      if ($variables.line_valid_var === "true" || $variables.line_valid_var === 'Yes' ) {

          if (lineId && $application.functions.isFormValid('line_form')) {

            if(!lineId.CreatedBy){

            await Actions.fireDataProviderEvent(context, {
              target: $variables.requestLinesADP,
              remove: {
                data: lineId,
                keys: lineId.AgreementLineId,
              },
            });
            }
            else{

              let val =  JSON.parse(JSON.stringify(lineId));

              val.Status ='Canceled';


             await Actions.fireDataProviderEvent(context, {
                  update: {
                    data: val,
                    keys: val.AgreementLineId,
                  },
                  target: $variables.requestLinesADP,
                }, { id: 'E' });
            }
          } else {

            if ($application.functions.isFormValid('line_form')) {    

              if ($variables.lineDetails.AgreementLineId) {
                await Actions.fireDataProviderEvent(context, {
                  update: {
                    data: $variables.lineDetails,
                    keys: $variables.lineDetails.AgreementLineId,
                  },
                  target: $variables.requestLinesADP,
                }, { id: 'E' });
              }
              else {

              const checkItemsPOline = await $functions.checkItemsPOline($variables.requestLinesADP.data, $variables.lineDetails);

              if (checkItemsPOline.success===false) {

                  $variables.lineDetails.AgreementLineId = $variables.requestLinesADP.data.length + 1;
                 // $variables.lineDetails.line_num = $variables.requestLinesADP.data.length + 1;
                   $variables.lineDetails.ActionCode = "ADD";
                  await Actions.fireDataProviderEvent(context, {
                    add: {
                      data: $variables.lineDetails,
                      keys: $variables.lineDetails.AgreementLineId,
                      indexes: 0,
                    },
                    target: $variables.requestLinesADP,
                  });
              } else {
                await Actions.fireNotificationEvent(context, {
                  summary: JSON.stringify(checkItemsPOline.message),
                  displayMode: 'transient',
                });
              }
              }

            const lineDialogClose = await Actions.callComponentMethod(context, {
              selector: '#lineDialog',
              method: 'close',
            });
            }
           
          
    
        }

        const totalSum = await $functions.calculateAggrementSum($variables.requestLinesADP.data);

        $flow.variables.transReqDetails.AgreementAmount = totalSum;
      }  else if ($variables.line_valid_var === 'falsepolo') {
        await Actions.fireNotificationEvent(context, {
          summary: "BPO Creation is blocked due to Inconsistent L/O code with PO Currency"+"("+$flow.variables.transReqDetails.CurrencyCode+")",
        });
      } else if ($variables.line_valid_var === 'No') {
        await Actions.fireNotificationEvent(context, {
          summary: 'BPO Creation is blocked due to Tax is Not Registered for the Supplier',
        });
      } else if ($variables.line_valid_var === 'FalseHsnc') {
        await Actions.fireNotificationEvent(context, {
          summary: 'BPO Creation is blocked as the Item doesn\'t have an HSN Code assigned at Item Master.',
        });
      }
     }
  }

  return lineDetailSaveChain;
});
