define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class RefreshBPOSearchPage extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $application.functions.openSpinnerDialog();

       const buyerNameFunc = await $functions.buyerNameFunc($application.user.fullName);

       

      $variables.qParameterForBPA = 'Buyer=' +"'"+ buyerNameFunc+"'"+'';

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.searchResultsSDP,
      });

      await Actions.resetVariables(context, {
        variables: [
    '$flow.variables.searchFilter.text',
  ],
      });

      await $application.functions.closeSpinnerDialog();
    }
  }

  return RefreshBPOSearchPage;
});
