define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class supplierSiteChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables } = context;


        let reqBuArray =[];

      if(!data)
      data = metadata.itemContext.data;

      await Actions.fireNotificationEvent(context, {
        summary: data.InvoiceCurrencyCode,
        message: 'currency code',
      });

      if(data){

        $variables.supplier_site_var = data.SUPPLIER_SITE_ID;

        const results = await Promise.all([
          async () => {

                                    reqBuArray = $application.functions.filterADPData(
                      $application.functions.getADPData($application.variables.buyerAssoc.ASSOCIATIONS,'ASSOCIATION_ID'),['SUPPLIER_SITE_ID'],[data.SUPPLIER_SITE_ID])

      $flow.variables.transReqDetails.SupplierSite = data? data.SUPPLIER_SITE:null;
             const response = await Actions.callRest(context, {
                        endpoint: 'fscm_conn/getSupplierSite',
                        uriParams: {
                          supplierId: data.SUPPLIER_ID,
                          siteId: data.SUPPLIER_SITE_ID,
                        },
                      });
                  
                          if (response.ok) {                
                            data = response.body;

      // $flow.variables.transReqDetails.SupplierSite = data? data.SupplierSite:null;
       $flow.variables.transReqDetails.SupplierCommunicationMethodCode = data.CommunicationMethod  ? data.CommunicationMethod:null;
       $flow.variables.transReqDetails.SupplierEmailAddress = data.Email  ? data.Email:null;
       $flow.variables.transReqDetails.PaymentTerms = data.PaymentTerms ? data.PaymentTerms:null;
        $flow.variables.transReqDetails.FOBCode = data.FOBCode ? data.FOBCode:null;
         $flow.variables.transReqDetails.ShippingMethod = data.ShippingMethod ? data.ShippingMethod:null;
          $flow.variables.transReqDetails.FreightTermsCode = data.FreightTermsCode ? data.FreightTermsCode:null;
       $flow.variables.transReqDetails.CurrencyCode =data.InvoiceCurrencyCode ? data.InvoiceCurrencyCode:( data.PaymentCurrencyCode? data.PaymentCurrencyCode  :'US Dollar');               $flow.variables.transReqDetails.SupplierSite = data.SupplierSite;
       $flow.variables.transReqDetails.Currency = data.InvoiceCurrency ? data.InvoiceCurrency: (data.PaymentCurrency? data.PaymentCurrency :'US Dollar');

              $variables.supplier_site_var = data.SUPPLIER_SITE_ID;

                          }
          },
          async () => {

    const responseReqBU = await Actions.callRest(context, {
              endpoint: 'fscm_conn/getSupplierAssignments',
              uriParams: {
                siteId: data.SUPPLIER_SITE_ID,
                supplierId: data.SUPPLIER_ID,
                q: 'ClientBUId in '+$application.functions.getInClause(
                  reqBuArray,'REQUISITION_BU_ID'
                ),
              },
            });

            $page.variables.RequisitionBuADP.data = responseReqBU.body.items;

            await Actions.fireNotificationEvent(context, {
              summary: $variables.supplier_site_var,
              message: data.SUPPLIER_SITE_ID+"'"+$flow.variables.transReqDetails.SupplierSiteId,
            });

            // const response2 = await Actions.callRest(context, {
            //   endpoint: 'FSCMApiConnection/getSuppliersSupplieridChildSitesSiteid',
            //   uriParams: {
            //     supplierid: $variables.SupplierId,
            //     siteid: $flow.variables.transReqDetails.SupplierSiteId,
            //   },
            // });

            // const response3 = await Actions.callRest(context, {
            //   endpoint: 'fscm_conn/getSuppliersSupplierIdChildAddressesSupplierAddressId',
            //   uriParams: {
            //     SupplierAddressId: response2.body.SupplierAddressId,
            //     SupplierId: $variables.SupplierId,
            //   },
            // });

            // $variables.Country_var = response3.body.Country;
          },
        ].map(sequence => sequence()));


     
    }


      // const responseReqBU = await Actions.callRest(context, {
      //   endpoint: 'fscm_conn/getSupplierAssignments',
      //   uriParams: {
      //     siteId: data.SUPPLIER_SITE_ID,
      //     supplierId: $flow.variables.transReqDetails.SupplierId,
      //   },
      // });
    }
  }

  return supplierSiteChain;
});
