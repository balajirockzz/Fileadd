define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SourceAgreementChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables } = context;

     
      

      await $application.functions.openSpinnerDialog();

    
     

      if (data) {

        await Actions.fireNotificationEvent(context, {
          summary: data.lines.items[0].LineNumber,
          message: data.lines.items[0].AllowPriceOverrideFlag,
        });

        await Actions.fireNotificationEvent(context, {
          summary: data.AgreementNumber,
        });

        // $variables.lineDetails.SourceAgreementLine = data.SourceLineAgreementNumber? data.SourceLineAgreementNumber: null;
    $variables.lineDetails.SourceAgreementLine = data.lines.items[0].LineNumber ? data.lines.items[0].LineNumber: null;
    // if (data.allow_price_override_flag=='Y' && $variables.hyperlinkPriceflag==false)
      if (data.lines.items[0].AllowPriceOverrideFlag===true && $variables.hyperlinkPriceflag==false) {

          const response = await Actions.callRest(context, {
            endpoint: 'fscm_conn/getPurchaseAgreementLines2',
            uriParams: {
              q: "AgreementNumber='"+ data.AgreementNumber+"' AND LineNumber='"+ data.lines.items[0].LineNumber+"'",
            },
            responseBodyFormat: 'json',
          });
// q: "AgreementNumber='"+ data.SourceAgreementNumber+"' AND LineNumber='"+ data.SourceLineAgreementNumber+"'",
        if (response.ok) {
             const response2 = await Actions.callRest(context, {
               endpoint: 'fscm_conn/getPurchaseAgreementsPurchaseAgreementsUniqIDChildLinesAgreementLineId2',
               uriParams: {
                 AgreementLineId: response.body.items[0].AgreementLineId,
                 purchaseAgreementsUniqID: response.body.items[0].AgreementHeaderId,
               },
             });

            $variables.lineDetails.Price = response2.body.Price;

          $variables.ManualPriceCheckFlag = true;

          $variables.ComparOveridePrice = response2.body.Price;
        }
      } else {

         $variables.lineDetails.Price =$variables.DFFlines.latestOcPrice;

      }
      } else {
         $variables.lineDetails.Price =$variables.DFFlines.latestOcPrice;
      }

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.hyperlinkPriceflag',
  ],
      });
      
    

      await $application.functions.closeSpinnerDialog();


      
    }
  }

  return SourceAgreementChangeChain;
});
