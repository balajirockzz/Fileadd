define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getSTP_PROC_EXT_005_PO_GETSO1_0Fetch extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{hookHandler:'vb/RestHookHandler'}} params.configuration
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const callRestEndpoint1 = await Actions.callRest(context, {
        endpoint: 'ics_conn/getSTP_PROC_EXT_005_PO_GETSO1_0',
        uriParams: {
          'doc_style': 'Dell-Standard Style',
          'procurement_bu': $flow.variables.transReqDetails.ProcurementBU,
          'supplier_name': $flow.variables.transReqDetails.Supplier,
          'supplier_site': $flow.variables.transReqDetails.SupplierSite,
          'item_number': $variables.lineDetails.Item,
        },
        responseType: 'getSTPPROCEXT05POGETSO1Response',
        hookHandler: configuration.hookHandler,
        requestType: 'json',
      });

      return callRestEndpoint1;
    }
  }

  return getSTP_PROC_EXT_005_PO_GETSO1_0Fetch;
});