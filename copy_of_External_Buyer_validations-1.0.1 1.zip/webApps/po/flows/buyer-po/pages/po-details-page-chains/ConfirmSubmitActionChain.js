define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SubmitActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $application.functions.openSpinnerDialog();

       let lines = $page.variables.requestLinesADP.data;

      // $flow.variables.transReqDetails.lines.items = $variables.requestLinesADP.data;

      if ($application.functions.isFormValid('hdr_form') && lines.length >0) {
      

      if ($flow.variables.transReqDetails.POHeaderId) {
          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.submitComments',
  ],
          });

          const ojDialogSubmitOpen = await Actions.callComponentMethod(context, {
            selector: '#oj-dialog-submit',
            method: 'open',
          });

          await $application.functions.closeSpinnerDialog();
        




        } else {
          await Actions.callChain(context, {
            chain: 'SubmitActionChain',
          });
      }
      } else {
        await Actions.fireNotificationEvent(context, {
          displayMode: 'transient',
          summary: 'Missing required fields'+(lines.length < 1? ': Atleast One Item Details is mandatory':''),
        });

        await $application.functions.closeSpinnerDialog();
      }
      await $application.functions.closeSpinnerDialog();
    }
  }

  return SubmitActionChain;
});
