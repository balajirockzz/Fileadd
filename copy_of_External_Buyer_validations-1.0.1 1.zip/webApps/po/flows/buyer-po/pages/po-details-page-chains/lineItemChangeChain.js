define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class lineItemChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

   

      await $application.functions.openSpinnerDialog();

      // ---- TODO: Add your code here ---- //
      console.log(key);
      console.log(data);
      console.log(metadata);

      if(!data)
       data = metadata.detail.itemContext.data;

      await Actions.fireNotificationEvent(context, {
        summary: data.ItemNumber,
        message: data.OrganizationCode,
      });

      $variables.lineDetails.Item = data.ItemNumber;
      $variables.lineDetails.Description = data.ItemDescription;
      $variables.lineDetails.attribute1 = data.OrganizationCode;
      $variables.lineDetails.UOM = data.PrimaryUOMName;
      $variables.lineDetails.OrganizationCode = data.OrganizationCode;
      $variables.lineDetails.LineType = data.LineType ? 'Goods':'Rate Based Services';
     $variables.lineDetails.LineNumber = 
  ($page.variables.requestLinesADP.data.length > 0 && 
   $page.variables.requestLinesADP.data[$page.variables.requestLinesADP.data.length - 1].LineNumber !== undefined)
    ? ($page.variables.requestLinesADP.data[$page.variables.requestLinesADP.data.length - 1].LineNumber + 1)
    : 1;

      await Actions.fireNotificationEvent(context, {
        summary: data.ItemId,
      });

   
      // $variables.lineDetails.item_description = data.item_description;
      // $variables.lineDetails.item_description = data.item_description;
     



      const results = await Promise.all([
        async () => {

          const response2 = await Actions.callRest(context, {
            endpoint: 'fscm_conn/getItems',
            uriParams: {
              expand: 'ItemCategories',
              q: "ItemNumber = '"+data.ItemNumber+"' and OrganizationCode= '"+data.OrganizationCode+"'",
              fields: 'ItemCategories',
            },
          });

          if (!response2.ok) {
            if(response2.items.length >0 && response2.items[0].ItemCategories && response2.items[0].ItemCategories.items[0].CategoryName)
            $variables.lineDetails.category_name = response2.items[0].ItemCategories.items[0].CategoryName; 
            else
            $variables.lineDetails.category_name = "Goods";

          }
        },
        async () => {
           const response = await Actions.callRest(context, {
             endpoint: 'fscm_conn/getItemsV2_2',
             uriParams: {
               q: "ItemNumber='"+ data.ItemNumber +"' AND OrganizationCode='"+ data.OrganizationCode +"'",
               fields: 'ItemNumber,OrganizationCode,DefaultBuyerValue',
             },
           });

          // ---- TODO: Add your code here ---- //
          const hrefValue = response.body.items[0]["@context"].links[0].href;

          await Actions.fireNotificationEvent(context, {
            summary: response.body.items[0]["@context"].links[0].href,
            message: 'item values',
          });

          const href_var = hrefValue.split('/').pop();

          $variables.hnsec_var = href_var;

          await Actions.fireNotificationEvent(context, {
            summary: $variables.hnsec_var,
          });

          // const response6 = await Actions.callRest(context, {
          //   endpoint: 'fscm_conn/getItemsV2ItemidChildItemEffCategoryCategoryidChildItemEFFBTaxPrivateVO',
          //   uriParams: {
          //     categoryid: href_var,
          //     itemid: href_var,
          //     fields: 'hsnSac',
          //   },
          // });
          // console.log('+++++++++href++++'+hrefValue);
          // if (response.ok) {
          //   $variables.DFFlines.itemBuyer1 = response.body.items[0].DefaultBuyerValue;
          // }
        },
    
        async () => {
          const response5 = await Actions.callRest(context, {
            endpoint: 'fscm_conn/getSuppliersSupplierIdChildSitesSupplierSiteIdChildDFF',
            uriParams: {
              SupplierId: $flow.variables.transReqDetails.SupplierId,
              SupplierSiteId: $flow.variables.transReqDetails.SupplierSiteId,
            },
          });
// "supplierSiteId":  $flow.variables.transReqDetails.SupplierSite,
            let onecostbody = {
  "ocPriceCallRequest": {
    "messageTimeStamp": "2025-02-19T00:00:00.000+00:00",
    "senderID": "",
    "receiverID": "",
    "organizationCode": data.OrganizationCode,
    "checkSourcingLaneFlag": "N",
    "priceType": "",
    "messageID": "",
    "itemList": {
      "item": [{
        "itemNumber": data.ItemNumber,
        "supplierNumber":  $variables.supplierNumber ,
        "supplierSiteId":  response5.body.items[0].supplierSiteId,
        "effectiveDate": "2025-02-19T00:00:00.000+00:00"
      }]
    },
    "toLocation": $flow.variables.transReqDetails.ShipToLocationCode ,
    "documentStyle": $flow.variables.transReqDetails.DocumentStyle 
  }
};
    let response3 = await Actions.callRest(context, {
      endpoint: 'ics_conn/postSTP_PROC_INT_012_1_0GetItemOneCost',
      body: onecostbody,
    });

          if (response3.ok) {
             $variables.lineDetails.Price = response3.body.ocPriceCallResponse.itemList.item[0].ocPrice ? Number(response3.body.ocPriceCallResponse.itemList.item[0].ocPrice) : null;
              $variables.DFFlines.latestOcPrice = response3.body.ocPriceCallResponse.itemList.item[0].ocPrice ? Number(response3.body.ocPriceCallResponse.itemList.item[0].ocPrice) : null;
               $variables.DFFlines.priceType = response3.body.ocPriceCallResponse.itemList.item[0].priceType ? response3.body.ocPriceCallResponse.itemList.item[0].priceType : null;
              $variables.DFFlines.reasonCode = '50';
                $variables.ManualPriceCheckFlag = true;
                  $variables.DFFlines.ocPriceSite = response3.body.ocPriceCallResponse.site ? response3.body.ocPriceCallResponse.site : null;
          }
        },
      ].map(sequence => sequence()));

        //  const response4 = await Actions.callRest(context, {
        //     endpoint: 'ics_conn/getSTP_PROC_EXT_005_PO_GETSO1_0',
        //     uriParams: {
        //       'doc_style': $page.variables.DocumentStyle,
        //       'item_number': data.ItemNumber,
        //       'procurement_bu': $flow.variables.transReqDetails.ProcurementBU,
        //       'supplier_name': $flow.variables.transReqDetails.Supplier,
        //       'supplier_site': $flow.variables.transReqDetails.SupplierSite,
        //     },
        //   });

      // ---- TODO: Add your code here ---- //

      //  let doc_var='DocumentStyle='+"'"+$page.variables.DocumentStyle+"'"+'AND'+'ProcurementBU='+"'"+$flow.variables.transReqDetails.ProcurementBU+"'"+'AND'+'Supplier='+"'"+$flow.variables.transReqDetails.Supplier+"'"+'AND'+'SupplierSite='+"'"+$flow.variables.transReqDetails.SupplierSite+"'"+'AND'+'lines.ItemId='+"'"+data.ItemId+"'";

      let doc_var =
  `DocumentStyle='Dell-Blanket Purchase Order' AND
   ProcurementBU='${$flow.variables.transReqDetails.ProcurementBU}' AND
   Supplier='${$flow.variables.transReqDetails.Supplier}' AND
   SupplierSite='${$flow.variables.transReqDetails.SupplierSite}' AND
   lines.ItemId='300000069301433'`;
   
      const response7 = await Actions.callRest(context, {
        endpoint: 'FSCMApiConnection/getPurchaseAgreements',
        uriParams: {
          q: doc_var,
          onlyData: 'true',
          expand: 'lines',
        },
      });

      if (response7.ok) {
            
              //  $variables.SourceAgreementNumberADP.data = $application.functions.getADPData(response4.body.Results, 'SourceAgreementNumber');
            $variables.SourceAgreementNumberADP.data = $application.functions.getADPData(response7.body.items, 'AgreementNumber');
              // $variables.lineDetails.SourceAgreementNumber = $variables.SourceAgreementNumberADP.data[0].SourceAgreementNumber;
               $variables.lineDetails.SourceAgreementNumber = $variables.SourceAgreementNumberADP.data[0].AgreementNumber;
      }

      await Actions.fireNotificationEvent(context, {
        summary: $variables.lineDetails.Item,
      });


      await $application.functions.closeSpinnerDialog();

    }
  }

  return lineItemChangeChain;
});
