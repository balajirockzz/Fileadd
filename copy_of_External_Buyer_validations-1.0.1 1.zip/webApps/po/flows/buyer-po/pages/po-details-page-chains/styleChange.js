define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class styleChange extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.details 
     * @param {string} params.style 
     */
    async run(context, { details, style }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      $flow.variables.transReqDetails.DocumentStyle = details.data.display_name;
      $flow.variables.transReqDetails.DocumentStyleId = details.data.style_id;
      $variables.DocumentStyle = details.data.style_name;
      

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.DFFheaders',
  ],
      });

      const getWorkers = await Actions.callRest(context, {
        endpoint: 'hcm_conn/getWorkers',
        uriParams: {
          q: "PersonNumber=" + $application.user.username,
        },
      });

      if (getWorkers.ok === true) {
        $variables.ExternalIdentifiersADP.data = getWorkers.body.items[0].externalIdentifiers;

         const externalIdentifierNumbe = await $functions.getExternalIdentifierNumber($variables.ExternalIdentifiersADP.data, 'Legacy Dell NT Domain\\User');

        // ---- TODO: Add your code here ---- //
        console.log("externalIdentifierNumber-"+externalIdentifierNumbe);

        if (style === 'Dell-Strat Buy Purchase Order' || style === 'Dell-Standard Purchase Order' || style === 'Dell-LTB Blanket PO' || style === 'Dell-Services Purchase Order' || style === 'Dell-Blanket Purchase Order') {
          $variables.DFFheaders.createdBy = 'Created Via External Buyer By:' +externalIdentifierNumbe;
        }
      }
    }
  }

  return styleChange;
});
