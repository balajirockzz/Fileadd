/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class spSubmitChain extends ActionChain {

    /**
     * Notify primary action is triggered
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;
       let lines = $page.variables.requestLinesADP.data;
      if ($application.functions.isFormValid('hdr_form') && lines.length >0) {

      let ojDialogSubmitOpen = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-submit',
        method: 'isOpen',
      });

      if (ojDialogSubmitOpen) {


         $flow.variables.transReqDetails.change_order_description = $page.variables.submitComments; 
        

        // Call save chain
        await Actions.callChain(context, {
          chain: 'spSaveChain',
          params: {
            submit: 'Y',
          },
        }, { id: 'callSaveChain' });

        // // Navigate to page
        // await Actions.navigateToPage(context, {
        //   page: '/',
        // }, { id: 'navigateToPage' });
      } else {
        const ojDialogSubmitOpen2 = await Actions.callComponentMethod(context, {
          selector: '#oj-dialog-submit',
          method: 'open',
        });
      }
      }

       else {
        await Actions.fireNotificationEvent(context, {
          displayMode: 'transient',
          summary: 'Missing required fields'+(lines.length < 1? ': Atleast One Item Details is mandatory':''),
        });
        
      }
    }
  }

  return spSubmitChain;
});
