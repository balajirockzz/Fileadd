define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ManualPriceValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if(value!=$page.variables.DFFlines.latestOcPrice && value !=$page.variables.DFFlines.ocPriceSite && value !=$page.variables.ComparOveridePrice){
  $page.variables.DFFlines.reasonCode='40';
  $page.variables.DFFlines.priceType='MN';

}
else{
        if(value) {

   $page.variables.DFFlines.reasonCode='50';
  $page.variables.DFFlines.priceType='B';
        }
}
    }
  }

  return ManualPriceValueChangeChain;
});
