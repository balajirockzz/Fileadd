define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class pageLoadChain extends ActionChain {

    /**
     * @param {Object} context
     * @return {{cancelled:boolean}} 
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $application.functions.openSpinnerDialog();

      let buyerGroups =[];
      let buyerOrgs =[];
      $flow.variables.transReqDetails = {};
      $flow.variables.transReqDetails.buyer_name = $flow.variables.transReqDetails.BuyerId;

      if($variables.headerId){

       let response = await Actions.callRest(context, {
         endpoint: 'fscm_conn/getPurchaseOrder',
         uriParams: {
           purchaseOrdersUniqID: $variables.headerId,
           onlyData: 'true',
           expand: 'DFF,lines,lines.DFF,lines.schedules',
         },
       });

        if (response.ok) {
if (response.body.DFF.items.length > 0) {
    
    $variables.DFFheaders = response.body.DFF.items[0];
}
 else {

            // If items is undefined, empty, or not an array, assign an empty object
                $variables.DFFheaders = {};
}

          // assignPOdetails
           
          $flow.variables.transReqDetails = response.body;
           console.log('responseof the body'+response.body);

          // codeb
let containsbuyerid=$application.variables.buyersADP.data.some(person => person.PERSON_ID === response.body.BuyerId);

          // ---- TODO: Add your code here ---- //
          console.log('contains buyer id '+containsbuyerid);
          // codeb
          if (!containsbuyerid) {
          const add_buyer={"DISPLAY_NAME":response.body.Buyer,"PERSON_ID":response.body.BuyerId};

            // $application.variables.buyersADP.data=$application.variables.buyersADP.data.push(add_buyer);
            $application.variables.buyersADP.data.push(add_buyer);
         console.log('buyersadpdataloaded',$application.variables.buyersADP.data);
          }


         // $flow.variables.transReqDetails.DocumentStyleId = response.body.DocumentStyleId;
          // $page.variables.requestLinesADP.data = response.body.lines ? response.body.lines : [];
          $variables.readOnlyFields = true;   
          $variables.requestLinesADP.data = response.body.lines.items ? response.body.lines.items : [];

          console.log($page.variables.requestLinesADP.data)

          

          

          $page.variables.supplierSIteADP.data = await $application.functions.filterADPData($application.functions.getADPData($application.variables.buyerAssoc.ASSOCIATIONS,'SUPPLIER_SITE_ID'), [
  'SUPPLIER_ID',
], [
  $flow.variables.transReqDetails.SupplierId,
]);
         
        const results = await Promise.all([
          async () => {

            const response2 = await Actions.callRest(context, {
              endpoint: 'fscm_conn/getSupplierContacts',
              uriParams: {
                id: $flow.variables.transReqDetails.SupplierId,
              },
            });

            if (response2.ok) {
              $page.variables.supplierContactsADP.data = response2.body.items;

              if($flow.variables.transReqDetails.SupplierContactId && $flow.variables.transReqDetails.SupplierContact){

                let names = $flow.variables.transReqDetails.SupplierContact.split(',');

                response2.body.items.forEach( (item)=>{

                 if( item.FirstName === names[1].trim()
                  && item.LastName === names[0].trim()){
                  $flow.variables.transReqDetails.SupplierContactId = item.SupplierContactId;

                  }



                });


              }
            
            }
          },
            async () => {

                    let   reqBuArray = await $application.functions.filterADPData($application.functions.getADPData($application.variables.buyerAssoc.ASSOCIATIONS,'SUPPLIER_SITE_ID'), [
  'SUPPLIER_SITE_ID',
], [
  $flow.variables.transReqDetails.SupplierSiteId,
]);
             // let  reqBuArray = $application.functions.getADPData($application.variables.buyerAssoc.ASSOCIATIONS,$flow.variables.transReqDetails.SupplierSiteId);
              console.log("BU-",JSON.stringify(reqBuArray));
              const response4 = await Actions.callRest(context, {
                endpoint: 'fscm_conn/getSupplierAssignments',
                uriParams: {
                  siteId: $flow.variables.transReqDetails.SupplierSiteId,
                  supplierId: $flow.variables.transReqDetails.SupplierId,
                   q: 'ClientBUId in '+$application.functions.getInClause(
            reqBuArray,'REQUISITION_BU_ID'
          ),
                },
              });

              if (response4.ok) {

                $page.variables.RequisitionBuADP.data = response4.body.items;
              }
            },
            async () => {
            
                    let   reqBuArray = await $application.functions.filterADPData($application.functions.getADPData($application.variables.buyerAssoc.ASSOCIATIONS,'SUPPLIER_SITE_ID'), [
  'SUPPLIER_SITE_ID',
], [
  $flow.variables.transReqDetails.SupplierSiteId,
]);
              
              const response4 = await Actions.callRest(context, {
                endpoint: 'fscm_conn/getSupplierAssignments',
                uriParams: {
                  siteId: $flow.variables.transReqDetails.SupplierSiteId,
                  supplierId: $flow.variables.transReqDetails.SupplierId,
                },
              });
            
              if (response4.ok) {
                $page.variables.billToBUADP.data = response4.body.items;
              }
            },
        ].map(sequence => sequence()));
        } else {
          let errorvar = JSON.stringify(response.body);
            const errorObj = JSON.parse(errorvar);
             const errorMessage = errorObj["o:errorDetails"][0].detail;
          await Actions.fireNotificationEvent(context, {
            summary: JSON.stringify(errorMessage),
          });
        }
        
      } else {
        $flow.variables.transReqDetails.BuyerId = $application.variables.buyerDetails.PERSON_ID;
        $flow.variables.transReqDetails.Buyer = $application.variables.buyerDetails.DISPLAY_NAME;
      }

  

      const response3 = await Actions.callRest(context, {
        endpoint: 'ics_conn/getStp005Itembuyerlov',
      });

      
   
    

      $variables.itemBuyerADP.data = $application.functions.getADPData(response3.body.items,'EXT_IDENTIFIER_NUMBER');

      await $application.functions.closeSpinnerDialog();

      // Navigation to this page can be canceled by returning an object with the property cancelled set to true. This is useful if the user does not have permission to view this page.
      return { cancelled: false };
    }
  }

  return pageLoadChain;
});
