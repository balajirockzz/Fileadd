define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class CollectionToolbarSpAddChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.fireNotificationEvent(context, {
        summary: $flow.variables.transReqDetails.RequisitioningBU,
        message: $flow.variables.transReqDetails.RequisitioningBUId,
      });

  //     await Actions.resetVariables(context, {
  //       variables: [
  //   '$page.variables.lineDetails',
  // ],
  //     });

     $page.variables.lineDetails = {};
      $variables.disableItemFlag = true;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.hyperlinkPriceflag',
  ],
      });

          
      if ($flow.variables.transReqDetails.POHeaderId) {

        const response = await Actions.callRest(context, {
          endpoint: 'fscm_conn/getPurchaseOrder',
          uriParams: {
            purchaseOrdersUniqID: $flow.variables.transReqDetails.POHeaderId,
            expand: 'lines,lines.schedules',
            onlyData: 'true',
          },
        });

          $variables.OrganizationCodeArrayCheck = response.body;
      }

      $variables.hnsec_var = '0';
      
      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.updateLineFlag',
    '$page.variables.DFFlines',
  ],
      });

      await Actions.fireNotificationEvent(context, {
        summary: $variables.Ext_Num_var,
        message: 'ext number',
      });

      $variables.DFFlines.itemBuyer1 = $variables.Ext_Num_var;
      // $variables.DFFlines.itemBuyer1 = $flow.variables.transReqDetails.BuyerId;

      const lineDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#lineDialog',
        method: 'open',
      });
    }
  }

  return CollectionToolbarSpAddChain;
});
