define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class RefreshPoSearchPage extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await $application.functions.openSpinnerDialog();

      $variables.qParameterForBPO = 'BuyerDisplayName=' +"'"+ $application.user.fullName+"'"+'';

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.searchResultsSDP,
      });

      await Actions.resetVariables(context, {
        variables: [
    '$flow.variables.searchFilter.text',
  ],
      });

      await $application.functions.closeSpinnerDialog();
    }
  }

  return RefreshPoSearchPage;
});
