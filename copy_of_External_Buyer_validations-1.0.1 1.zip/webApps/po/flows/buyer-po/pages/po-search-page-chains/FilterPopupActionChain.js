define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class FilterPopupActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $variables } = context;

      await Actions.resetDirtyDataStatus(context, {
      });

      $flow.variables.showFilter = false;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.searchResultsDP.data',
    '$flow.variables.searchFilter.text',
  ],
      });

      await Actions.resetDirtyDataStatus(context, {
      });

      $flow.variables.showFilter = true;
    }
  }

  return FilterPopupActionChain;
});
