define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class lineDetailSaveChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {number} params.lineId 
     */
    async run(context, { lineId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

     


      await $application.functions.openSpinnerDialog();

      const response = await Actions.callRest(context, {
        endpoint: 'ords_conn/getPODetails',
      });

            await Actions.fireDataProviderEvent(context, {
              add: {
                data: $variables.lineDetails,
                keys: $variables.lineDetails.amount,
                indexes: 0,
              },
              target: $variables.AddBuyerADP,
            });
          

      await $application.functions.closeSpinnerDialog();
    
     }
  }

  return lineDetailSaveChain;
});
