define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectValueItemChangeChainBuyerNew extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;


      // $variables.lineDetails.PERSON_NUMBER = data.PERSON_NUMBER;
      // $variables.lineDetails.DISPLAY_NAME = data.DISPLAY_NAME;
      // $variables.lineDetails.PERSON_ID = data.PERSON_ID;
      // $variables.lineDetails.EMAIL = data.EMAIL_ADDRESS;
      // $variables.lineDetails.ENABLED_FLAG = true;
      // $variables.lineDetails.BUYER_CODE = data.BUYER_CODE;

      $variables.lineDetails.PERSON_NUMBER = data.PersonNumber;
      $variables.lineDetails.DISPLAY_NAME = data.DisplayName;
      $variables.lineDetails.PERSON_ID = data.PersonId;
      $variables.lineDetails.EMAIL = data.Email;
      $variables.lineDetails.ENABLED_FLAG = true;

      await Actions.fireNotificationEvent(context, {
        summary: $variables.lineDetails.PERSON_NUMBER,
        message: $variables.lineDetails.DISPLAY_NAME,
      });

      await Actions.fireNotificationEvent(context, {
        summary: $variables.lineDetails.PERSON_ID,
        message: $variables.lineDetails.EMAIL,
      });

      const response3 = await Actions.callRest(context, {
        endpoint: 'hcm_conn/getWorkers',
        uriParams: {
          q: "PersonNumber="+data.PersonNumber,
        },
      });

 if (response3.ok === true) {
        $variables.ExternalIdentifiersADP_copy.data = response3.body.items[0].externalIdentifiers;

         const externalIdentifierNumbers = await $functions.getExternalIdentifierNumber($variables.ExternalIdentifiersADP_copy.data, 'Buyer Code');

        // ---- TODO: Add your code here ---- //
        console.log("externalIdentifierNumber-"+externalIdentifierNumbers);
        $variables.Mapping_details_var = externalIdentifierNumbers;

        await Actions.fireNotificationEvent(context, {
          summary: $variables.Mapping_details_var,
        });

        $variables.lineDetails.BUYER_CODE = $variables.Mapping_details_var;
      }

      const response = await Actions.callRest(context, {
        endpoint: 'HCMRestApi/getUserAccounts',
        uriParams: {
          q: "PersonNumber="+data.PersonNumber,
        },
      });

      const response2 = await Actions.callRest(context, {
        endpoint: 'HCMRestApi/getUserAccountsGuidChildUserAccountRoles',
        uriParams: {
          Guid: response.body.items[0].GUID,
          q: "RoleCode in ('DELL_STP_PROCUREMENT_EXTERNAL_BUYER_APPLICATION_JR','DELL_STP_PROCUREMENT_EXTERNAL_BUYER_JR','DELL_STP_PROCUREMENT_EXTERNAL_BUYER_ADMIN_JR')",
        },
      });

      if (response2.body.count !== 0) {
        $variables.Buyer_Add_Btn = true;
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'This Specific Buyer Does Not Have the Specific Roles Assigned.',
          displayMode: 'persist',
          type: 'error',
        });
      }
    }
  }

  return SelectValueItemChangeChainBuyerNew;
});
