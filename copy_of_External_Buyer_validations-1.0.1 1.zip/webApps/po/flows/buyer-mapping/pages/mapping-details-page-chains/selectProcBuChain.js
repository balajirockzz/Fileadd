define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class selectProcBuChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.details 
     */
    async run(context, { details }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      if(details && details.itemContext.data)
      $variables.lineDetails.PROCUREMENT_BU = details.itemContext.data.ProcurementBU;
    }

  }

  return selectProcBuChain;
});
