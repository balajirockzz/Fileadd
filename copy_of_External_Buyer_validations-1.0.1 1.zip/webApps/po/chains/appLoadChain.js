define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class appLoadChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $application, $constants, $variables } = context;

      const results2 = await Promise.all([
        async () => {

          const response2 = await Actions.callRest(context, {
            endpoint: 'ords_conn/getBuyerGroupDetails',
            uriParams: {
              id: 'U'+$application.user.username,
            },
          });

          if (!response2.ok) {
            await Actions.fireNotificationEvent(context, {
              summary: 'User is not associated to Buyer Group',
              displayMode: 'transient',
              type: 'info',
            });
          } else {
            $variables.buyerAssoc = response2.body;
            $variables.buyersADP.data = response2.body.BUYERS;
            
            $variables.buyersADP_copy.data = response2.body.BUYERS;

            response2.body.BUYERS.forEach((item)=>{

              if(item.PERSON_NUMBER === $application.user.username)
                    $application.variables.buyerDetails = item;
            });


            $variables.suppliersADP.data = $application.functions.getADPData(response2.body.ASSOCIATIONS,'SUPPLIER_ID');   
            $variables.procurementBuADP.data = $application.functions.getADPData(response2.body.ASSOCIATIONS,'PROCUREMENT_BU_ID');   
            $variables.requsitioningBuADP.data = $application.functions.getADPData(response2.body.ASSOCIATIONS,'REQUISITION_BU_ID');     
                
            // $variables.procurementBuADP.data = $application.functions.filterADPData(
            //   $application.functions.getADPData(response2.body.ASSOCIATIONS,'PROCUREMENT_BU_ID'),[],[]);
          }
        },
        async () => {

          const response = await Actions.callRest(context, {
            endpoint: 'fscm_conn/getPurchasingDocumentStylesLOV',
          });

          if (response.ok) {

            let poStyles= [];
            let bpaStyles =[];

            
            const results = await ActionUtils.forEach(response.body.items, async (item, index) => {
              item.label = item.DisplayName;
              item.value = item.DisplayName;
              if(item.DisplayName && item.DisplayName.includes('Dell') && !(item.StatusCode.includes('INACTIVE'))){
              if(item.DisplayName.includes('Blanket Purchase'))
              bpaStyles.push(item);
              else if(item.DisplayName.includes('Purchase Order') && ! (item.DisplayName.includes('Blanket')))
              poStyles.push(item);
              }
            }, { mode: 'serial' });


            $variables.bpaDocumentStyleADP.data = bpaStyles;

            $variables.poDocumentStyleADP.data = poStyles;
            
          } else {
            await Actions.fireNotificationEvent(context, {
              summary: 'Error while loading styles',
              displayMode: 'transient',
            });
          }

          const DBSTYLE = await Actions.callRest(context, {
            endpoint: 'ords_conn/getDocumentStyle',
          });

          if (DBSTYLE.ok === true) {


            let poStylesNew= [];
            let bpaStylesNew =[];

            
            const results = await ActionUtils.forEach(DBSTYLE.body.items, async (item, index) => {
              item.label = item.display_name;
              item.value = item.display_name;
              if(item.display_name && item.display_name.includes('Dell') && !(item.status_code.includes('INACTIVE'))){
              if(item.display_name.includes('Blanket Purchase'))
              bpaStylesNew.push(item);
              else if(item.display_name.includes('Purchase Order') && ! (item.display_name.includes('Blanket')))
              poStylesNew.push(item);
              }
            }, { mode: 'serial' });


            $variables.BPAPageDocumentStyleADP.data = bpaStylesNew;

            $variables.POPageDocumentStyleADP.data = poStylesNew;
          }
        },
      ].map(sequence => sequence()));
    }
  }

  return appLoadChain;
});
