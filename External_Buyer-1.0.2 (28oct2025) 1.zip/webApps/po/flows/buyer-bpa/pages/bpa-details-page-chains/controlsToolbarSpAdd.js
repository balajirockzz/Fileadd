define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class CollectionToolbarSpAddChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.clientbu_var = $variables.controlDetailsTemp.RequisitioningBU;

      //     await Actions.resetVariables(context, {
      //       variables: [
      //   '$page.variables.lineDetails',
      // ],
      //     });
       //if($variables.businessControlsADP.data && $variables.businessControlsADP.data.length >0 )
      $page.variables.controlDetails = {};
      //$page.variables.controlDetails.EnabledFlag = true;
      $page.variables.controlDetails = $page.variables.controlDetailsTemp;
      
      // $page.variables.controlDetails. = true;
      



      const bUAccessDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#BUAccessDialog',
        method: 'open',
      });
    }
  }

  return CollectionToolbarSpAddChain;
});
