define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class pageLoadChain extends ActionChain {

    /**
     * @param {Object} context
     * @return {{cancelled:boolean}} 
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await $application.functions.openSpinnerDialog();

      let buyerGroups = [];
      let buyerOrgs = [];
      $flow.variables.transReqDetails = {};
      $flow.variables.transReqDetails.buyer_name = $flow.variables.transReqDetails.BuyerId;

      if ($variables.headerId) {

        let response = await Actions.callRest(context, {
          endpoint: 'fscm_conn/getPurchaseAgreement',
          uriParams: {
            purchaseAgreementsUniqID: $variables.headerId,
          },
        });

        if (response.ok) {
          // assignPOdetails

          $flow.variables.transReqDetails = response.body;
          let containsbuyerid=$application.variables.buyersADP.data.some(person => person.PERSON_ID === response.body.BuyerId);
          if (!containsbuyerid) {
          const add_buyer={"DISPLAY_NAME":response.body.Buyer,"PERSON_ID":response.body.BuyerId};

            // $application.variables.buyersADP.data=$application.variables.buyersADP.data.push(add_buyer);
            $application.variables.buyersADP.data.push(add_buyer);
          }
          //$flow.variables.transReqDetails.FreightTerms = response.body.FreightTerms;
          $variables.bpoDetails = response.body;
          $flow.variables.transReqDetails.StyleId = $flow.variables.transReqDetails.DocumentStyleId;
          $page.variables.requestLinesADP.data = response.body.lines ? response.body.lines.items : [];
          $page.variables.businessControlsADP.data = response.body.businessUnitAccess ? response.body.businessUnitAccess.items : [];
          $page.variables.DFFIntRequestPayload.p_Bpo_Number = $flow.variables.transReqDetails.AgreementNumber;
          $variables.readOnlyFields = true;



          const response3 = await Actions.callRest(context, {
            endpoint: 'ics_conn/STP_PROC_EXT_005_BPA_DF',
            body: $variables.DFFIntRequestPayload,
          }, { id: 'getDFF' });

          if (response3.ok === true) {

            $flow.variables.transReqDetails.AttributeCategory = response3.body.Results.HEADER_ATTRIBUTE_CATEGORY ? response3.body.Results.HEADER_ATTRIBUTE_CATEGORY : null
            $flow.variables.transReqDetails.Attribute1 = response3.body.Results.Attribute1 ? response3.body.Results.Attribute1 : null;
            $flow.variables.transReqDetails.Attribute2 = response3.body.Results.Attribute2 ? response3.body.Results.Attribute2 : null;
            $flow.variables.transReqDetails.Attribute3 = response3.body.Results.Attribute3 ? response3.body.Results.Attribute3 : null;
            $flow.variables.transReqDetails.Attribute4 = response3.body.Results.Attribute4 ? response3.body.Results.Attribute4 : null;
            $flow.variables.transReqDetails.Attribute5 = response3.body.Results.Attribute5 ? response3.body.Results.Attribute5 : null;
            $flow.variables.transReqDetails.Attribute6 = response3.body.Results.Attribute6 ? response3.body.Results.Attribute6 : null;
            $flow.variables.transReqDetails.Attribute7 = response3.body.Results.Attribute7 ? response3.body.Results.Attribute7 : null;
            $flow.variables.transReqDetails.Attribute8 = response3.body.Results.Attribute8 ? response3.body.Results.Attribute8 : null;
            $flow.variables.transReqDetails.Attribute9 = response3.body.Results.Attribute9 ? response3.body.Results.Attribute9 : null;
            $flow.variables.transReqDetails.Attribute10 = response3.body.Results.Attribute10 ? response3.body.Results.Attribute10 : null;
            $flow.variables.transReqDetails.Attribute11 = response3.body.Results.Attribute11 ? response3.body.Results.Attribute11 : null;
            $flow.variables.transReqDetails.Attribute12 = response3.body.Results.Attribute12 ? response3.body.Results.Attribute12 : null;
            $flow.variables.transReqDetails.Attribute13 = response3.body.Results.Attribute13 ? response3.body.Results.Attribute13 : null;
            $flow.variables.transReqDetails.Attribute14 = response3.body.Results.Attribute14 ? response3.body.Results.Attribute14 : null;
            $flow.variables.transReqDetails.Attribute15 = response3.body.Results.Attribute15 ? response3.body.Results.Attribute15 : null;
            $flow.variables.transReqDetails.Attribute16 = response3.body.Results.Attribute16 ? response3.body.Results.Attribute16 : null;
            $flow.variables.transReqDetails.Attribute17 = response3.body.Results.Attribute17 ? response3.body.Results.Attribute17 : null;
            $flow.variables.transReqDetails.Attribute18 = response3.body.Results.Attribute18 ? response3.body.Results.Attribute18 : null;
            $flow.variables.transReqDetails.Attribute19 = response3.body.Results.Attribute19 ? response3.body.Results.Attribute19 : null;
            $flow.variables.transReqDetails.Attribute20 = response3.body.Results.Attribute20 ? response3.body.Results.Attribute20 : null;
          }

          const results = await Promise.all([
            async () => {

              $page.variables.supplierSIteADP.data = $application.functions.filterADPData(
                $application.functions.getADPData($application.variables.buyerAssoc.ASSOCIATIONS, 'SUPPLIER_SITE_ID'), ['SUPPLIER_ID'], [$flow.variables.transReqDetails.SupplierId])

            },
            async () => {

              const response2 = await Actions.callRest(context, {
                endpoint: 'fscm_conn/getSupplierContacts',
                uriParams: {
                  id: $flow.variables.transReqDetails.SupplierId,
                },
              });

              if (response2.ok) {
                $page.variables.supplierContactsADP.data = response2.body.items;

                if ($flow.variables.transReqDetails.SupplierContactId && $flow.variables.transReqDetails.SupplierContact) {

                  let names = $flow.variables.transReqDetails.SupplierContact.split(',');

                  response2.body.items.forEach((item) => {

                    if (item.FirstName === names[1].trim()
                      && item.LastName === names[0].trim()) {
                      $flow.variables.transReqDetails.SupplierContactId = item.SupplierContactId;

                    }



                  });


                }

              }
            },
            async () => {

              let reqBuArray = $application.functions.filterADPData(
                $application.functions.getADPData($application.variables.buyerAssoc.ASSOCIATIONS, 'REQUISITION_BU_ID'),
                ['SUPPLIER_SITE_ID'], [$flow.variables.transReqDetails.SupplierSiteId]);

              const response4 = await Actions.callRest(context, {
                endpoint: 'fscm_conn/getSupplierAssignments',
                uriParams: {
                  siteId: $flow.variables.transReqDetails.SupplierSiteId,
                  supplierId: $flow.variables.transReqDetails.SupplierId,
                  q: 'ClientBUId in ' + $application.functions.getInClause(
                    reqBuArray, 'REQUISITION_BU_ID'
                  ),
                },
              });

              if (response4.ok) {
                $page.variables.RequisitionBuADP.data = response4.body.items;
              }
            },
            async () => {

              let reqBuArray = $application.functions.filterADPData(
                $application.functions.getADPData($application.variables.buyerAssoc.ASSOCIATIONS, 'REQUISITION_BU_ID'),
                ['SUPPLIER_SITE_ID'], [$flow.variables.transReqDetails.SupplierSiteId]);

              const response4 = await Actions.callRest(context, {
                endpoint: 'fscm_conn/getSupplierAssignments',
                uriParams: {
                  siteId: $flow.variables.transReqDetails.SupplierSiteId,
                  supplierId: $flow.variables.transReqDetails.SupplierId,
                },
              });

              if (response4.ok) {
                $page.variables.billToBUADP.data = response4.body.items;
              }
            },
          ].map(sequence => sequence()));
        } else {
          await Actions.fireNotificationEvent(context, {
            summary: 'API error',
          });
        }
        $variables.Location_var = $variables.businessControlsADP.data[0].ShipToLocation;

      } else {
        $flow.variables.transReqDetails.BuyerId = $application.variables.buyerDetails.PERSON_ID;
        $flow.variables.transReqDetails.Buyer = $application.variables.buyerDetails.DISPLAY_NAME;
      }

   const response3 = await Actions.callRest(context, {
        endpoint: 'ics_conn/getStp005Itembuyerlov',
      });

      $variables.itemBuyerADP.data = $application.functions.getADPData(response3.body.items,'EXT_IDENTIFIER_NUMBER');

      await $application.functions.closeSpinnerDialog();

      // Navigation to this page can be canceled by returning an object with the property cancelled set to true. This is useful if the user does not have permission to view this page.
      return { cancelled: false };
    }
  }

  return pageLoadChain;
});
