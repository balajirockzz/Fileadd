define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class supplierContactChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.details 
     */
    async run(context, { details }) {
      const { $page, $flow, $application } = context;

      if(details){

      $flow.variables.transReqDetails.SupplierContact =  details.FirstName+' '+details.LastName ;
      }
      else{
        $flow.variables.transReqDetails.SupplierContact = null;
      }

    }
  }

  return supplierContactChangeChain;
});
