define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class StyleChangeActionChain extends ActionChain {

    /**AttributeCategory
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.details 
     */
    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.details 
     * @param {string} params.stylename 
     */
    async run(context, { details, stylename }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

       $flow.variables.transReqDetails.DocumentStyle = details.data.display_name;
       $flow.variables.transReqDetails.AttributeCategory = details.data.display_name;
        $flow.variables.transReqDetails.Style = details.data.display_name;
       $flow.variables.transReqDetails.DocumentStyleId = details.data.style_id;


      const getWorkers = await Actions.callRest(context, {
        endpoint: 'hcm_conn/getWorkers',
        uriParams: {
          q: "PersonNumber=" + $application.user.username,
        },
      });

      if (getWorkers.ok === true) {
        $variables.ExternalIdentifiersADP.data = getWorkers.body.items[0].externalIdentifiers;

 const externalIdentifierNumbe = await $functions.getExternalIdentifierNumber($variables.ExternalIdentifiersADP.data, 'Legacy Dell NT Domain\\User');

        // ---- TODO: Add your code here ---- //
        console.log("externalIdentifierNumber-"+externalIdentifierNumbe);
        if (stylename === 'Dell-Blanket Purchase Order' || stylename === 'Dell-BSOM Blanket Purchase Order' || stylename === 'Dell-LTB Blanket Purchase Order') {
          $flow.variables.transReqDetails.Attribute4 = 'Created Via External Buyer By:' +externalIdentifierNumbe;
        }
      }

    }
  }

  return StyleChangeActionChain;
});

