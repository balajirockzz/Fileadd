define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ESSJobStatusCheckActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.ESSJobID 
     * @return {boolean} 
     */
    async run(context, { ESSJobID }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'fscm_conn/getESSJobStatus',
        uriParams: {
          finder: 'ESSJobStatusRF;requestId=' +ESSJobID,
        },
      });

      //if (response.body.items[0].RequestStatus !== 'RUNNING' && response.body.items[0].RequestStatus !== 'WAIT' && response.body.items[0].RequestStatus !=='READY' ) {
        if (response.body.items[0].RequestStatus !== 'RUNNING' && response.body.items[0].RequestStatus !== 'WAIT' && response.body.items[0].RequestStatus !=='READY' ) {
        $variables.ESSJobComplted = true;

          console.log("ESS_JOB_DONE");
        return true;
      } else {
        const eSSJobStatusCheckActionChain = await Actions.callChain(context, {
          chain: 'ESSJobStatusCheckActionChain',
          params: {
            ESSJobID: ESSJobID,
          },
        });
      }
    }
  }

  return ESSJobStatusCheckActionChain;
});

