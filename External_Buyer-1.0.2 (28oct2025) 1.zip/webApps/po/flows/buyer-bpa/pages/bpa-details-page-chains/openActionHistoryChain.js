define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class openActionHistoryChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      await $application.functions.openSpinnerDialog();

      await Actions.callChain(context, {
        chain: 'flow:openActionHistory',
        params: {
          PoNumber: $flow.variables.transReqDetails.AgreementNumber,
        },
      });

      await $application.functions.closeSpinnerDialog();

      const ojDialogActionOpen = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-action',
        method: 'open',
      });
    }
  }

  return openActionHistoryChain;
});
