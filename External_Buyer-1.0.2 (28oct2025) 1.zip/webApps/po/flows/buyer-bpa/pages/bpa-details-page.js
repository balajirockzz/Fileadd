define([], () => {
  'use strict';

  class PageModule {

    generateBIPReportREqPayload(po_number){
let payload =`<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:pub="http://xmlns.oracle.com/oxp/service/PublicReportService">
   <soap:Header/>
   <soap:Body>
      <pub:runReport>
         <pub:reportRequest>
            <pub:attributeFormat>csv</pub:attributeFormat>
            <pub:parameterNameValues>
               <pub:item>
                  <pub:name>p_po_number</pub:name>
                  <pub:values>
                     <pub:item>`+po_number+`</pub:item>
                  </pub:values>
               </pub:item>
            </pub:parameterNameValues>
            <pub:reportAbsolutePath>/Custom/Extension/STP/STP_PROC_EXT_005_External_Buyer_PO_ActionHistory_Report.xdo</pub:reportAbsolutePath>
            <pub:sizeOfDataChunkDownload>-1</pub:sizeOfDataChunkDownload>
         </pub:reportRequest>
      </pub:runReport>
   </soap:Body>
</soap:Envelope>`;

return payload;

}


    generateBIPReportREqPayload1() {
      let payload = `<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:pub="http://xmlns.oracle.com/oxp/service/PublicReportService">
   <soap:Header/>
   <soap:Body>
      <pub:runReport>
         <pub:reportRequest>
 
            <pub:reportAbsolutePath>/Custom/GBL_Custom/Extension/STP/PROC/Reports/STP_PROC_EXT_005_External_Buyer_Group_RPT.xdo</pub:reportAbsolutePath>
            <pub:sizeOfDataChunkDownload>-1</pub:sizeOfDataChunkDownload> 
         </pub:reportRequest>
         <pub:appParams>?</pub:appParams>
      </pub:runReport>
   </soap:Body>
</soap:Envelope>`;

      return payload;

    }

    getExternalIdentifierNumber(externalIdentifierNumber_ADP, externalIdentifierTypeSeach){

     
     for (let i = 0; i < externalIdentifierNumber_ADP.length; i++) 
     { if (externalIdentifierNumber_ADP[i].ExternalIdentifierType === externalIdentifierTypeSeach) 
         {  
          return externalIdentifierNumber_ADP[i].ExternalIdentifierNumber; 
        }    
       
     }
     return null;
}





      }

     PageModule.prototype.isCrossDivision = function (linesData) {
      let returnVal = 'Y';
      linesData.forEach(element => {
        if(element.from_division !== element.to_division){
          returnVal = 'N';
        }
      });
         return returnVal;
    };

     PageModule.prototype.isSameReviewer = function (linesData) {
      let returnVal = 'Y';
      let from_reviewer = null;
      let to_reviewer = null;
      linesData.forEach(element => {
        if(element.from_reviewer !== element.to_reviewer){
           returnVal = 'N';
        }
        if(from_reviewer && element.from_reviewer !== from_reviewer){
           returnVal = 'FROM';
        }
        if(to_reviewer && element.from_reviewer !== to_reviewer){
           returnVal = 'TO';
        }
        from_reviewer = element.from_reviewer ;
        to_reviewer = element.to_reviewer ;
      });
      return returnVal;
    };

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
  PageModule.prototype.calculateAggrementSum = function (lineArray) {
   let totalSum = 0;

   lineArray.forEach(record => {
     let quantity = record.hasOwnProperty('AgreementQuantity') ? record.AgreementQuantity : null;
     let price = record.Price;

           if (quantity === null) {
                totalSum += price;
              } else {
                    totalSum += quantity * price;
              }
 });

 console.log("SUM-", totalSum);
 return totalSum;
};

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    PageModule.prototype.checkItemsPOline = function (reqLinesADP, lineDetails) {
    for (let i = 0; i < reqLinesADP.length; i++) {
     
        if (reqLinesADP[i].Item === lineDetails.Item) {
          return { success: true, message: 'Same item cannot exist at more than one BPA line' };
        }
           
    }
    return { success: false };
  };


  PageModule.prototype.getStatusText = function(statusCode) {
  const codeMap = {
    200: "Ok",
    400: "Bad Request",
    401: "Unauthorized",
    402: "Payment Required",
    403: "Forbidden",
    404: "(Not Found), This action cannot be done on this Purchase Order",
    405: "Method Not Allowed",
    406: "Not Acceptable",
    407: "Proxy Authentication Required",
    408: "Request Timeout",
    409: "Conflict",
    410: "Gone",
    411: "Length Required",
    412: "Precondition Failed",
    413: "Payload Too Large",
    414: "URI Too Long",
    415: "Unsupported Media Type",
    416: "Range Not Satisfiable",
    417: "Expectation Failed",
    421: "Misdirected Request",
    422: "Unprocessable Entity",
    423: "Locked",
    424: "Failed Dependency",
    425: "Too Early",
    426: "Upgrade Required",
    428: "Precondition Required",
    429: "Too Many Requests",
    431: "Request Header Fields Too Large",
    451: "Unavailable For Legal Reasons",
    500: "Internal Server Error",
    501: "Not Implemented",
    502: "Bad Gateway",
    503: "Service Unavailable",
    504: "Gateway Timeout",
    505: "HTTP Version Not Supported",
    506: "Variant Also Negotiates",
    507: "Insufficient Storage",
    508: "Loop Detected",
    510: "Not Extended",
    511: "Network Authentication Required",
     555 : "User Defined Error"
    
  };

let result =  codeMap[statusCode] || "Unknown Status Code";
  return result;
};


PageModule.prototype.checkCountry = function (country1,country2) {
  console.log('++++++++country1+++++++'+country1);
  console.log('++++++++country2+++++++'+country2);
     let result;
      if (country1 === country2) {
        result = 'true';
        console.log('========='+1+result);
      }
      
      else {
        result = 'False';
        console.log('========='+2+result);
      }

      console.log("result+++++++++++++"+result);
      return result;
      
    };



PageModule.prototype.checkStatus = function (count,county,hnesc) {
  console.log('++++++++hnesc+++++++'+hnesc);
     let result;
      if (count === 1 && county === 'true' && hnesc !== null) {
        result = 'true';
        console.log('========='+1);
      }
      
      else if (count === 1 && county === 'true' && hnesc === null) {
        result = 'False';
        console.log('========='+2+hnesc+result);
      }
       else if (count === 0 || count === null || count === undefined ) {
        result= 'true';
        console.log('========='+3);
      }
      console.log("result+++++++++++++"+result);
      return result;
      
    };



// PageModule.prototype.polovalidation = function (loCode, buLocalCurrency, poCurrency) {
//   let result;
//   console.log('=====locode==========='+loCode);
//    console.log('=====buLocalCurrency==========='+buLocalCurrency);
//     console.log('=====poCurrency==========='+poCurrency);
//   if (loCode === 'L') {
//     if (poCurrency === buLocalCurrency) {
//       result = "true";
//       console.log("=====l 1=====");
//     } else {
//       result = "False";
//     }
//     console.log("=====l 2=====");
//   }

//   if (loCode === 'O') {
//     if (poCurrency !== buLocalCurrency) {
//       result = "true";
//       console.log("=====O 1=====");
//     } else {
//       result = "False";
//       console.log("=====O 2=====");
//     }
//   }

//   if (loCode === 'X') {
//     result = "true";
//     console.log("=====x=====");
//   }

//   if (loCode === null || loCode === undefined || loCode === '') {
//     result = "False";
//     console.log("=====no lo code=====");
//   }

//   if (loCode !== 'L' && loCode !== 'O' && loCode === 'X' && loCode !== null && loCode !== undefined && loCode !== ''){
//   result = "true";
//   }
//   console.log("+++++result+++++"+result);
//   return result;

// };



PageModule.prototype.polovalidation = function (loCode, buLocalCurrency, poCurrency) {
  let result;

  console.log("==== loCode ====", loCode);
  console.log("==== buLocalCurrency ====", buLocalCurrency);
  console.log("==== poCurrency ====", poCurrency);

  if (loCode === 'L') {
    result = (poCurrency === buLocalCurrency) ? "true" : "falsepolo";
    console.log('=====1====');
  } 
  else if (loCode === 'O') {
    result = (poCurrency !== buLocalCurrency) ? "true" : "falsepolo";
     console.log('=====2====');
  } 
  else if (loCode === 'X') {
     console.log('=====3====');
    result = "true";
  } 
  else if (loCode === null || loCode === undefined || loCode === '') {
     console.log('=====4====');
    result = "falsepolo";
  } 
  else {
     console.log('=====5====');
    // Any other value
    result = "true";
  }

  console.log("==== result ====", result);
  return result;
};





// PageModule.prototype.getRequiredForLOValidationABCD = function(apiResponse, inventoryOrg) {
//   let result;
//     let items = apiResponse.items;

//     for (let item of items) {
//       const lookupData = item.lookupsDFF.items[0]; // Assumes only one item in lookupsDFF

//       if (lookupData.inventoryOrg === inventoryOrg) {
//         result = lookupData.requiredForLOValidation;
//         return result;
//       }
//     }

//     return 'error';
// };



PageModule.prototype.getRequiredForLOValidationABCD = function(apiResponse, inventoryOrg) {
  let apiresult;
    try {
        let data = apiResponse;
       
        // Handle VB REST response wrapping
        if (apiResponse && apiResponse.body) {
            data = apiResponse.body;
        } else if (apiResponse && apiResponse.result) {
            data = apiResponse.result;
        } else if (apiResponse && apiResponse.data) {
            data = apiResponse.data;
        }
       
        // Check if data has items array
        if (!data || !data.items || !Array.isArray(data.items)) {
            console.error("No items array found in response");
             apiresult = 'Error'; // Not found
        return apiresult;
        }
       
        // Search through items
        for (let i = 0; i < data.items.length; i++) {
            const item = data.items[i];
           
            if (item && item.lookupsDFF && item.lookupsDFF.items &&
                Array.isArray(item.lookupsDFF.items) && item.lookupsDFF.items.length > 0) {
               
                const lookupData = item.lookupsDFF.items[0];
               
                if (lookupData && lookupData.inventoryOrg === inventoryOrg) {
                    apiresult = lookupData.requiredForLOValidation;
                    console.log('=======================api result ==============='+apiresult);
                    return apiresult;
                }
            }
        }
       
        // apiresult = null; // Not found
        // return apiresult;
       
    } catch (error) {
        console.error("Error:", error);
         apiresult = 'Error'; // Not found
        return apiresult;
    }
    return apiresult;
};



//  PageModule.prototype.filterOrgs = function (lookupdata, Org) {
//     const seen = new Set();
//     lookupdata.forEach(entry => {
//       if (entry.lookupsDFF && Array.isArray(entry.lookupsDFF.items)) {
//         entry.lookupsDFF.items.forEach(item => {
//           const flexContext = item.__FLEX_Context ? item.__FLEX_Context.trim().toUpperCase() : '';
//           const requiredFlag = item.requiredForLOValidation ? item.requiredForLOValidation.trim().toUpperCase() : '';
//           const inventoryOrg = item.inventoryOrg ? item.inventoryOrg.trim() : '';
//           if (
//             flexContext === 'STP_CMN_PURDOCATTRXREF_LKP' &&
//             requiredFlag === "YES" &&
//             inventoryOrg !== ''
//           ) {
//             seen.add(inventoryOrg);
//           }
//         });
//       }
//     });
//     const orgToCheck = Org ? Org.trim().toUpperCase() : '';
//     const uppercaseSeen = new Set([...seen].map(org => org.toUpperCase()));
//     return uppercaseSeen.has(orgToCheck);
//   };



  PageModule.prototype.filterOrgs = function (lookupdata, Org) {
    const seen = new Set();
    lookupdata.forEach(entry => {
      if (entry.lookupsDFF && Array.isArray(entry.lookupsDFF.items)) {
        entry.lookupsDFF.items.forEach(item => {
          const flexContext = item.__FLEX_Context ? item.__FLEX_Context.trim().toUpperCase() : '';
          // const requiredFlag = item.requiredForLOValidation ? item.requiredForLOValidation.trim().toUpperCase() : '';
          // const inventoryOrg = item.inventoryOrg ? item.inventoryOrg.trim() : '';
          const validationParts = item.validationOptions ? item.validationOptions.split('|') : [];
            // const requiredFlag = item.validationOptions ? item.validationOptions.split('|')[0].trim().toUpperCase() : '';
            const requiredFlag = validationParts.length > 2 ? validationParts[2].trim().toUpperCase() : '';
            console.log('++++++++++++++++++++requiredFlag++++++++++++++++++++'+requiredFlag);
          const inventoryOrg = item.inventoryOrg ? item.inventoryOrg.split('|')[0].trim() : '';
          console.log('++++++++++++++++++++inventoryOrg++++++++++++++++++++'+inventoryOrg);
          if (
            flexContext === 'STP_CMN_PURDOCATTRXREF_DFF' &&
            requiredFlag === 'Y' &&
            inventoryOrg !== ''
          ) {
            seen.add(inventoryOrg);
          }
        });
      }
    });
    const orgToCheck = Org ? Org.trim().toUpperCase() : '';
    const uppercaseSeen = new Set([...seen].map(org => org.toUpperCase()));
    return uppercaseSeen.has(orgToCheck);
  };
  
  return PageModule;
});
