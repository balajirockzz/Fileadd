define(["oj-c/select-multiple"], () => {
  'use strict';

  class PageModule {
  }
  
  return PageModule;
});
