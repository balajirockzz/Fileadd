define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class pageLoadChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await $application.functions.openSpinnerDialog();

      const response = await Actions.callRest(context, {
        endpoint: 'ords_conn/getDocumentStyle',
      });

      let styleArray =[];
      let postyleArray =[];
      let bpastyleArray = [];

      if (response.ok) {
        const results = await ActionUtils.forEach(response.body.items, async (item, index) => {
         styleArray.push(item.style_id);
          if(item.display_name && item.display_name.includes('Dell')){
          if(item.display_name.includes('Blanket Purchase'))
          bpastyleArray.push(item.style_id);
          else if(item.display_name.includes('Purchase Order') && ! (item.display_name.includes('Blanket')))
          postyleArray.push(item.style_id);
          }
         
         
        }, { mode: 'parallel' });
        $variables.selectedPoStyle = new Set(postyleArray);
        $variables.selectedBpoStyle = new Set(bpastyleArray);


     


        console.log($variables.selectedPoStyle );

            
  
      }

      await $application.functions.closeSpinnerDialog();
    }
  }

  return pageLoadChain;
});
