define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class selReqBUChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $variables } = context;


      if(data){
       $flow.variables.transReqDetails.BillToLocation = data.BillToLocation;
       $flow.variables.transReqDetails.ShipToLocationCode = data.ShipToLocation;
       $flow.variables.transReqDetails.ShipToLocationId = data.ShipToLocationId;
        $variables.clientbu_var = data.ClientBU;
        
       
      }

      const responseLegalEntityId = await Actions.callRest(context, {
        endpoint: 'fscm_conn/getFinBusinessUnitsLOVFinBusinessUnitsLOVUniqID',
        uriParams: {
          finBusinessUnitsLOVUniqID: $flow.variables.transReqDetails.RequisitioningBUId,
        },
      });

      if (responseLegalEntityId.ok) {
        const responseLegalEntityName = await Actions.callRest(context, {
          endpoint: 'fscm_conn/getLegalEntitiesLOVLegalEntityId',
          uriParams: {
            LegalEntityId: responseLegalEntityId.body.LegalEntityId,
          },
        });

        $flow.variables.transReqDetails.SoldToLegalEntity = responseLegalEntityName.body.Name;
      }
    }
  }

  return selReqBUChain;
});
