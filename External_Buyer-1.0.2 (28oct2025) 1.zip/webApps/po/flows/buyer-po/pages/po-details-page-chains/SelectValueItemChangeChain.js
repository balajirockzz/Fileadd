define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class requestSelectChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables } = context;


      
      // ---- TODO: Add your code here ---- //
      console.log(key);
      console.log(data);
      console.log(metadata);

      if(!data)
       data = metadata.detail.itemContext.data;
       $flow.variables.transReqDetails[metadata.srcElement.id] = data[metadata.srcElement.itemText];

    }
  }

  return requestSelectChangeChain;
});
