define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class FilePickerSelectChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object[]} params.files 
     */
    async run(context, { files }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      // ---- TODO: Add your code here ---- //

      if (files && files.length > 0) {
        // Create ZIP and download
        const result = await new Promise((resolve, reject) => {
          require([
            'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.6.0/jszip.min.js',
            'https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/1.3.8/FileSaver.js'
          ], function (JSZip, FileSaver) {
            const zip = new JSZip();

            files.forEach(file => {
              zip.file(file.name, file);
            });

            zip.generateAsync({ type: 'blob' })
              .then(blob => {
                console.log("ZIP Blob created: ", blob);

                // Get current date and time
                const currentDateTime = new Date().toISOString().replace(/[:.-]/g, '');

                // Download the zip with new name
                const zipFileName = `BPA${currentDateTime}.zip`;
                saveAs(blob, zipFileName);

                // Convert blob to base64
                const reader = new FileReader();
                reader.onloadend = function () {
                  let base64data = reader.result.split(',')[1]; // Extract base64 data
                  console.log(base64data); // You can assign this to a local variable
                  // localVariable = base64data; // Uncomment and use this line to assign to a local variable
                  $page.variables.HeadreAttchamentRequest.ContentType=".zip";
                  $page.variables.HeadreAttchamentRequest.DocumentAccount="prc/blanketPurchaseAgreement/import";
                  $page.variables.HeadreAttchamentRequest.DocumentContent=base64data;
                  $page.variables.HeadreAttchamentRequest.FileName=zipFileName;
                  $page.variables.HeadreAttchamentRequest.OperationName="uploadFileToUCM";

                };
                reader.readAsDataURL(blob);


                // Return the zip file and file name
                resolve({ blob, zipFileName });
              })
              .catch(error => {
                console.error('Zip creation failed:', error);
                reject(error);
              });
          });
        });

        const response = await Actions.callRest(context, {
          endpoint: 'fscm_conn/UploadFIleToUCMServer',
          body: $variables.HeadreAttchamentRequest,
        });

        if (response.ok === true) {
          $variables.DFFheaders.attachment = "https://iawmqy-dev2.fa.ocs.oraclecloud.com/cs/idcplg?IdcService=GET_FILE&dID="+response.body.DocumentId;
        }
      }




    }



  }

  return FilePickerSelectChain;
});
