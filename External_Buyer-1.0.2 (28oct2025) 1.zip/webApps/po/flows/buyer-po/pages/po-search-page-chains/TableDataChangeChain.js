define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableDataChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.data 
     */
    async run(context, { data }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if ($flow.variables.searchFilter.text && true) {
        await Actions.fireNotificationEvent(context, {
          summary: data,
        });
      }
    }
  }

  return TableDataChangeChain;
});
