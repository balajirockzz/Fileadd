define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class pageLoadChain extends ActionChain {

    /**
     * @param {Object} context
     * @return {{cancelled:boolean}} 
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await $application.functions.openSpinnerDialog();

      let buyerGroups =[];
      let buyerOrgs =[];
      $flow.variables.transReqDetails = {};
      $flow.variables.transReqDetails.buyer_name = $application.user.username;
      $flow.variables.transReqDetails.ENABLED_FLAG = true;

      if($variables.headerId){

       let response = await Actions.callRest(context, {
         endpoint: 'ords_conn/getBuyerGroupDetails',
         uriParams: {
           id: $variables.headerId,
         },
       });

        if (response.ok) {
          // assignPOdetails
          $flow.variables.transReqDetails = response.body;
          $page.variables.AddBuyerADP.data = response.body.BUYERS ? response.body.BUYERS : [];
          $page.variables.mappingDetailsADP.data = response.body.ASSOCIATIONS ? response.body.ASSOCIATIONS : [];
          // $variables.lineDetails = response.body.ASSOCIATIONS[0];

          
        } else {
          await Actions.fireNotificationEvent(context, {
            summary: 'API error',
          });
        }
        
      }

  

      await $application.functions.closeSpinnerDialog();

      // Navigation to this page can be canceled by returning an object with the property cancelled set to true. This is useful if the user does not have permission to view this page.
      return { cancelled: false };
    }
  }

  return pageLoadChain;
});
