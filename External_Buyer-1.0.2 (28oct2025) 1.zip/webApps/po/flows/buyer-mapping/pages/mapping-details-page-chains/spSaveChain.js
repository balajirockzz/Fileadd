/* Copyright (c) 2024, Oracle and/or its affiliates */

define(['knockout',
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ko,
  ActionChain,
  Actions
) => {
  'use strict';

  class spSaveChain extends ActionChain {

    /**
     * Submit form data
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.submit 
     */
    async run(context, { submit = 'N' }) {
      const { $page, $flow, $variables, $application } = context;

      await $application.functions.openSpinnerDialog();

      // await $application.functions.isFormValid('hdr_form');
       let lines = $page.variables.AddBuyerADP.data;
       let assoc = $page.variables.mappingDetailsADP.data;
       let isFailed = false;
      if ($application.functions.isFormValid('hdr_form') && lines.length >0 && assoc.length >0) {
         $flow.variables.transReqDetails.BUYERS = lines;
         $flow.variables.transReqDetails.ASSOCIATIONS = assoc;
         $flow.variables.transReqDetails.CREATED_BY = $application.user.username;
         $flow.variables.transReqDetails.po_status = (submit ==='N'?'DRAFT':'SUBMIT');
        

        const response = await Actions.callRest(context, {
          endpoint: 'ords_conn/postBuyerGroup',
          body: ko.toJSON( $flow.variables.transReqDetails)
        });

        if (!response.ok) {
           isFailed =true;
          await Actions.fireNotificationEvent(context, {
            summary: 'Rest API Error',
          });
        } else {

          if(response.body.X_RETURN_CODE === 'ERROR'){
             isFailed =true;
                await Actions.fireNotificationEvent(context, {
                  summary: 'Configuration Saved Failed',
                  displayMode: 'transient',
                  type: 'error',
                });

          }
          
          
          else{

            await Actions.fireNotificationEvent(context, {
              summary: 'Configuration Saved',
              displayMode: 'transient',
              type: 'confirmation',
            });

          }
         
        }
        
        if(!isFailed)
        await Actions.callChain(context, {
          chain: 'spCancelChain',
        });
      
      }
       else {
        await Actions.fireNotificationEvent(context, {
          displayMode: 'transient',
          summary: 'Missing required fields'+(lines.length < 1? ': Atleast One Item Details is mandatory':''),
        });
        
      }

      await $application.functions.closeSpinnerDialog();

    }
  }

  return spSaveChain;
});
