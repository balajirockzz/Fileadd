define([
  'vb/action/actionChai{
  endpoint: 'hcm_conn/get',
}
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectValueItemChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables, $eq } = context;

      // ASSINING BUYER DETAILS
      $variables.lineDetails.PERSON_NUMBER = data.PERSON_NUMBER;
      $variables.lineDetails.DISPLAY_NAME = data.DISPLAY_NAME;
      $variables.lineDetails.PERSON_ID = data.PERSON_ID;
      $variables.lineDetails.EMAIL = data.EMAIL_ADDRESS;
      $variables.lineDetails.ENABLED_FLAG = true;
      $variables.lineDetails.BUYER_CODE = data.BUYER_CODE;

    }}   
     

  return SelectValueItemChangeChain;
});
