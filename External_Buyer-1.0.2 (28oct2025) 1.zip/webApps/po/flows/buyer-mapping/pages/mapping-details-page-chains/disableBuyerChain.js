define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class disableBuyerChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.row 
     * @param {boolean} params.value 
     */
    async run(context, { row, value }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const currentdateandtime = await $functions.currentdateandtime();

      $variables.lineDetails = row;
      $variables.lineDetails.ENABLED_FLAG = value;
      $variables.lineDetails.CREATED_BY = $application.user.username;

      if (value === false) {
        $variables.lineDetails.DISABLED_DATE = currentdateandtime;
      }
      else {
         $variables.lineDetails.DISABLED_DATE = '';
      }

      await Actions.callChain(context, {
        chain: 'buyerDetailSaveChain',
        params: {
          details: $variables.lineDetails,
        },
      });

      await Actions.fireDataProviderEvent(context, {
        target: $variables.AddBuyerADP,
        refresh: null,
      });
    }
  }

  return disableBuyerChain;
});
