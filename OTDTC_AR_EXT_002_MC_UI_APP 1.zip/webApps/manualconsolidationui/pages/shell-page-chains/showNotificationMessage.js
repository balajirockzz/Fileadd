/* Copyright (c) 2024, Oracle and/or its affiliates */
 
define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
) => {
  'use strict';
 
  class showNotificationMessage extends ActionChain {
 
    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{summary:string,message:string,displayMode:string,type:string,key:string,target:string}} params.event
     */
    async run(context, { event }) {
      const { $page } = context;
 
      console.log('Event received:', event);
      console.log('Current message ID:', $page.variables.messageId);
 
      let msg = {
        messageType: event.type === "confirmation" ? "general-success" : "general-" + event.type,
        primaryText: event.summary,
        secondaryText: event.message,
        id: $page.variables.messageId
      };
      console.log('Constructed message:', msg);
 
      $page.variables.messageId++;
      console.log('Updated message ID:', $page.variables.messageId);
 
      try {
        console.log('Adding message to DataProvider...');
        await Actions.fireDataProviderEvent(context, {
          target: $page.variables.messagesBannerADP,
          add: {
            data: msg,
          },
        });
        console.log('Message added successfully.');
      } catch (error) {
        console.error('Error adding message to DataProvider:', error);
      }
 
      if (event.displayMode === "transient") {
        console.log('Transient display mode detected. Setting timeout to remove message...');
        setTimeout(async () => {
          try {
            console.log('Removing message with ID:', msg.id);
            await Actions.fireDataProviderEvent(context, {
              target: $page.variables.messagesBannerADP,
              remove: {
                keys: [msg.id],
              },
            });
            console.log('Message removed successfully.');
          } catch (error) {
            console.error('Error removing message from DataProvider:', error);
          }
        }, 5000);
      }
    }
  }
 
  return showNotificationMessage;
});