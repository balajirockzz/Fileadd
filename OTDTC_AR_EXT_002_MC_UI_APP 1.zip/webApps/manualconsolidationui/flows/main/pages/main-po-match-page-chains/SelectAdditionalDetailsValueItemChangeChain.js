define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectAdditionalDetailsValueItemChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     * @param {number} params.index 
     * @param {any} params.current 
     * @param {any} params.SDPKey 
     */
    async run(context, { key, data, metadata, index, current, SDPKey }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // ---- TODO: Add your code here ---- //
      // debugger;
      // console.log("Action Chain Triggered")
      // console.log(SDPKey);
      // console.log(key);
      // console.log(data);
      // console.log(data.value);

      $variables.rowEditObj.additional_details = SDPKey.key;
    }
  }

  return SelectAdditionalDetailsValueItemChangeChain;
});
