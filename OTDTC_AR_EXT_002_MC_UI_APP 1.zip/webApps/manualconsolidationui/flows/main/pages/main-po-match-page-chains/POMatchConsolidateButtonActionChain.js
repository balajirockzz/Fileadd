define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class POMatchConsolidateButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const ojDialog19531737751Open = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-1953173775-1',
        method: 'open',
      });

      // debugger;
      console.log("Before Array Flatten", $variables.poMatchSelectedRowADP.data);

      const flattenNestedArrayField = await $functions.flattenNestedArrayField($variables.poMatchSelectedRowADP.data, 'additional_details');

      // ---- TODO: Add your code here ---- //
      console.log("Array after Flattened");
      console.log(flattenNestedArrayField);
      console.log(flattenNestedArrayField[0].bu_name);
      const validateFields = await $functions.validateFields(flattenNestedArrayField, flattenNestedArrayField[0].bu_name);

      if (!validateFields.valid) {

        console.log("Validate Value: ", validateFields.valid);
        console.log("Validate Message: ", validateFields.message);
        await Actions.fireNotificationEvent(context, {
          summary: validateFields.message
        });

        const ojDialog19531737751Close3 = await Actions.callComponentMethod(context, {
          selector: '#oj-dialog-1953173775-1',
          method: 'close',
        });

        return;
      }
      else {

        const constructPayload = await $flow.functions.constructPayload($application.user.username, $variables.searchObjectVarFromMain, flattenNestedArrayField);

        // ---- TODO: Add your code here ---- //
        console.log("Constructed Payload");
        console.log(constructPayload);

        const syncLineFieldsFromFirstLine = await $functions.syncLineFieldsFromFirstLine(constructPayload);

        // ---- TODO: Add your code here ---- //
        console.log("SyncLineFieldsFromFirstLine")
          ;
        console.log(syncLineFieldsFromFirstLine);

        const response = await Actions.callRest(context, {
          endpoint: 'OIC_CONN/postIcApiIntegrationV1FlowsRestOTDT_AR_EXT_002_AR_INVO_BATC_PRO1_0Invoice',
          body: syncLineFieldsFromFirstLine,
        });

        if (response.body.status === "SUCCESS") {
          await Actions.fireNotificationEvent(context, {
            summary: 'Status',
            message: response.body.message,
            displayMode: 'persist',
            type: 'confirmation',
          });

          await Actions.resetVariables(context, {
            variables: [
              '$page.variables.rowData',
              '$page.variables.searchObjectVarFromMain',
              '$page.variables.poMatchSelectedRowADP',
              '$page.variables.orderDetailsPoMatchADP',
              '$page.variables.enableQbliColumnFlag',
              '$page.variables.enableSpecialDateColumnFlag',
              '$page.variables.enableAdditionalDetailsColumnFlag',
            ],
          });

          const ojDialog19531737751Close = await Actions.callComponentMethod(context, {
            selector: '#oj-dialog-1953173775-1',
            method: 'close',
          });

          return;
        } else {
          await Actions.fireNotificationEvent(context, {
            summary: 'Invoice Creation Failed',
          });

          await Actions.resetVariables(context, {
            variables: [
              '$page.variables.rowData',
              '$page.variables.searchObjectVarFromMain',
              '$page.variables.poMatchSelectedRowADP',
              '$page.variables.orderDetailsPoMatchADP',
              '$page.variables.enableQbliColumnFlag',
              '$page.variables.enableSpecialDateColumnFlag',
              '$page.variables.enableAdditionalDetailsColumnFlag',
            ],
          });

          const ojDialog19531737751Close2 = await Actions.callComponentMethod(context, {
            selector: '#oj-dialog-1953173775-1',
            method: 'close',
          });
        }
      }
    }
  }

  return POMatchConsolidateButtonActionChain;
});
