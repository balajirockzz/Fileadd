define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class POMatchQuantityInputNumberValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { value, key, index, current }) {
      const { $page, $flow, $application, $constants, $variables } = context;
            // ---- TODO: Add your code here ---- //
      console.log("After key",key);
      console.log("After value",value);
      console.log("Current",current);

      // $variables.rowEditObj.po_total_matched_price = $variables.rowEditObj.po_match_quantity * $variables.rowEditObj.po_match_unit_price;


      // if ($variables.rowEditObj.po_match_quantity && $variables.rowEditObj.po_match_unit_price) {
      //   $variables.rowEditObj.po_total_matched_price = $variables.rowEditObj.po_match_quantity * $variables.rowEditObj.po_match_unit_price;
      // } else if ($variables.rowEditObj.po_match_unit_price === '' || $variables.rowEditObj.po_match_unit_price === undefined) {
      //      $variables.rowEditObj.po_total_matched_price = 0;
      // } else if ($variables.rowEditObj.po_match_quantity === '' || $variables.rowEditObj.po_match_quantity === undefined) {
      //      $variables.rowEditObj.po_total_matched_price = 0;
      // } else {
      //      $variables.rowEditObj.po_total_matched_price = '';
      // }
      // debugger;
      if ($variables.rowEditObj.po_match_quantity && $variables.rowEditObj.po_match_unit_price) {
            $variables.rowEditObj.po_total_matched_price = $variables.rowEditObj.po_match_quantity * $variables.rowEditObj.po_match_unit_price;
      } else if ($variables.rowEditObj.po_match_quantity === null && $variables.rowEditObj.po_match_unit_price === null) {
            $variables.rowEditObj.po_total_matched_price = null;
      } else {
            $variables.rowEditObj.po_total_matched_price = null;
      }
    }
  }
 
  return POMatchQuantityInputNumberValueChangeChain;
});
