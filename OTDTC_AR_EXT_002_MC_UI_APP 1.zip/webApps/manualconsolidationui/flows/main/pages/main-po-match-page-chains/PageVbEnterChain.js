define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      
      const ojDialog19531737751Open = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-1953173775-1',
        method: 'open',
      });

       //debugger;
       
       console.log("Data Passed to PO Match Page");
       console.log($variables.selectedLinesFromMainPageArray);
      const enableDisableColumnFlags = await $functions.enableDisableColumnFlags($variables.selectedLinesFromMainPageArray);
      
      console.log("Flag Function Output");
      console.log(enableDisableColumnFlags);

      $variables.enableQbliColumnFlag = enableDisableColumnFlags.enableQbliColumnFlag;
      $variables.enableSpecialDateColumnFlag = enableDisableColumnFlags.enableSpecialDateColumnFlag;
      $variables.enableAdditionalDetailsColumnFlag = enableDisableColumnFlags.enableAdditionalDetailsColumnFlag;
      $variables.enableSpecialInstructionsColumnFlag = enableDisableColumnFlags.enableSpecialInstructionsColumnFlag;

      $variables.orderDetailsPoMatchADP.data = $variables.selectedLinesFromMainPageArray;

      // debugger;
      console.log("Lines", $variables.orderDetailsPoMatchADP);
      // console.log("search Object Details", $variables.searchObjectVarFromMain);
      
      // const response2 = await Actions.callRest(context, {
      //   endpoint: 'ords/getOTDTC_EXTOTDTC_AR_EXT_002OnPoMatch',
      //   uriParams: {
      //     limit: '500',
      //     'p_order_number': $variables.searchObjectVarFromMain.p_source_order_number ? $variables.searchObjectVarFromMain.p_source_order_number : '',
      //     'p_customer_account_number': $variables.searchObjectVarFromMain.p_account_number ? $variables.searchObjectVarFromMain.p_account_number : '',
      //     'p_business_unit_name': $variables.searchObjectVarFromMain.p_bu_name ? $variables.searchObjectVarFromMain.p_bu_name : '',
      //     'p_from_date': $variables.searchObjectVarFromMain.p_from_date ? $variables.searchObjectVarFromMain.p_from_date : '',
      //     'p_po_number': $variables.searchObjectVarFromMain.p_po_number ? $variables.searchObjectVarFromMain.p_po_number : '',
      //     'p_to_date': $variables.searchObjectVarFromMain.p_to_date ? $variables.searchObjectVarFromMain.p_to_date : '',
      //   },
      // });
      
      // if (!response2.ok) {
      
      //   await Actions.fireNotificationEvent(context, {
      //     summary: 'Status',
      //     message: 'No Data Found',
      //     displayMode: 'transient',
      //     type: 'info',
      //   });
      
      //   const ojDialog19531737751Close = await Actions.callComponentMethod(context, {
      //     selector: '#oj-dialog-1953173775-1',
      //     method: 'close',
      //   });
      
      //   return;
      // } else {
      //   const addUniqueSeqToRecords = await $flow.functions.addUniqueSeqToRecords(response2.body.items);
      
      //     $variables.orderDetailsPoMatchADP.data = addUniqueSeqToRecords;
      
      //   const ojDialog19531737751Close2 = await Actions.callComponentMethod(context, {
      //     selector: '#oj-dialog-1953173775-1',
      //     method: 'close',
      //   });
      // }

      const ojDialog19531737751Close3 = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-1953173775-1',
        method: 'close',
      });

    }
  }

  return PageVbEnterChain;
});
