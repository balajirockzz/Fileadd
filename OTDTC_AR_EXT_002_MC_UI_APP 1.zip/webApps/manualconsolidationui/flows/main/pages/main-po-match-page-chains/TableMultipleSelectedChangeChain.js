define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableMultipleSelectedChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any[]} params.keys 
     * @param {any} params.selected 
     */
    async run(context, { keys, selected }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      // debugger;
      const selectedCheck = await $functions.selectedCheck($variables.orderDetailsPoMatchADP.data, selected);

      $variables.poMatchSelectedRowADP.data = selectedCheck;

      // ---- TODO: Add your code here ---- //
      // console.log("Table Multi Select Got Triggered", selected);
      // console.log("Table Multi Select Got Triggered", keys);  
      
      // console.log("Values()", selected.row.values());
      // console.log("Values().size", selected.row.values().size);
      
      // console.log("SelectedCheck", selectedCheck);
      
      // console.log("Seelected Row ADP", $variables.poMatchSelectedRowADP.data);
    }
  }

  return TableMultipleSelectedChangeChain;
});
