define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectSpecialHandlingValueItemChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     * @param {number} params.index 
     * @param {any} params.current 
     * @param {string} params.SDPKey 
     */
    async run(context, { key, data, metadata, index, current, SDPKey }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // ---- TODO: Add your code here ---- //
      // debugger;
      // console.log("Value Changed Triggered");
      // console.log(key);
      // console.log(SDPKey);

      $variables.rowEditObj.special_handling = SDPKey.key;
    }
  }

  return SelectSpecialHandlingValueItemChangeChain;
});
