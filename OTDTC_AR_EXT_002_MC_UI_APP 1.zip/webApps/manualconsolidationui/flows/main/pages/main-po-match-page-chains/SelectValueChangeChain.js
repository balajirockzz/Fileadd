define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any[]} params.value 
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { value, key, index, current }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // debugger;
      console.log("Multi Select Action Chain Triggered")
      // console.log(SDPKey);
      console.log(key);
      console.log(current);
      console.log(value);

      $variables.rowEditObj.additional_details = value;
      // SDPKey.key;

      // ---- TODO: Add your code here ---- //
      console.log("Additional Details Assigned");
      console.log($variables.rowEditObj.additional_details);
    }
  }

  return SelectValueChangeChain;
});
