define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableBeforeRowEditEndChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.cancelEdit 
     * @param {any} params.rowKey 
     * @param {number} params.rowIndex 
     * @param {any} params.rowData 
     */
    async run(context, { cancelEdit, rowKey, rowIndex, rowData }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.fireDataProviderEvent(context, {
        target: $variables.orderDetailsPoMatchADP,
        update: {
          data: $variables.rowEditObj,
          keys: $variables.rowEditObj.seq_id,
        },
      });
      console.log("Selected Row ADP", $variables.poMatchSelectedRowADP);

      await Actions.fireDataProviderEvent(context, {
        target: $variables.poMatchSelectedRowADP,
        update: {
          data: $variables.rowEditObj,
          keys: $variables.rowEditObj.seq_id,
        },
      });

      // ---- TODO: Add your code here ---- //
      console.log("After Update Selected Row ADP", $variables.poMatchSelectedRowADP);
    }
  }

  return TableBeforeRowEditEndChain;
});
