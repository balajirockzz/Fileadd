define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class OrderNumberMultiSelectValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any[]} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // ---- TODO: Add your code here ---- //
      //debugger;
      // console.log("Multi Select", value);

      // $variables.searchObjectVar.p_source_order_number = value.join(',');

          await Actions.resetVariables(context, {
            variables: [
        '$page.variables.paginationObject',
        '$page.variables.isPrevious',
        '$page.variables.isNext',
      ],
          });

      // ---- TODO: Add your code here ---- //
      // console.log("After Assign", $variables.searchObjectVar.p_source_order_number);

      // console.log("After Assign", $variables.searchObjectVar);

    }
  }

  return OrderNumberMultiSelectValueChangeChain;
});
