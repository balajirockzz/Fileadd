define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class onSearchClickSearchButtonActionChainOLD extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
// debugger;
      if ($variables.searchObjectVar.p_bu_name && $variables.searchObjectVar.p_source_order_number) {
        //debugger;

        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.orderDetailsADP',
            '$page.variables.orderDetailsADP.data',
            '$page.variables.selectedRowArray',
            '$page.variables.selectedRowADP',
            '$page.variables.selectedRowADP.data',
            ],
        });

        const response = await Actions.callRest(context, {
          endpoint: 'ORDS_CONN/getOTDTC_EXTAR_EXT_002OnSearch',
          uriParams: {
            'p_from_date': $variables.searchObjectVar.p_from_date ? $variables.searchObjectVar.p_from_date : '',
            'p_to_date': $variables.searchObjectVar.p_to_date ? $variables.searchObjectVar.p_to_date : '',
            'p_order_number': $variables.searchObjectVar.p_source_order_number ? $variables.searchObjectVar.p_source_order_number : '',
            'p_po_number': $variables.searchObjectVar.p_po_number ? $variables.searchObjectVar.p_po_number : '',
            'p_business_unit_name': $variables.searchObjectVar.p_bu_name ? $variables.searchObjectVar.p_bu_name : '',
            'p_customer_account_number': $variables.searchObjectVar.p_account_number ? $variables.searchObjectVar.p_account_number : '',
            limit: '500'
          },
        });

        console.log("DATA FROM PAAS DB", JSON.stringify(response,null,2));

        if (!response.ok) {

          await Actions.fireNotificationEvent(context, {
            summary: 'Error',
            displayMode: 'transient',
          });

          return;
        } else {

          // if (!($variables.searchObjectVar.p_po_number || $variables.searchObjectVar.p_from_date || $variables.searchObjectVar.p_to_date)) {
          //   $variables.searchObjectVar.p_po_number = '';
          //   $variables.searchObjectVar.p_from_date = '';
          //   $variables.searchObjectVar.p_to_date = '';
            const response2 = await Actions.callRest(context, {
              endpoint: 'ics/postIcApiIntegrationV1FlowsRestOTD_AR_EXT_002_FET_OM__SM_LIN1_0Fetch_lines',
              uriParams: {
                'p_bu_name': $variables.searchObjectVar.p_bu_name ? $variables.searchObjectVar.p_bu_name : '',
                'p_from_date': $variables.searchObjectVar.p_from_date ? $variables.searchObjectVar.p_from_date : '',
                'p_po_number': $variables.searchObjectVar.p_po_number ? $variables.searchObjectVar.p_po_number : '',
                'p_source_order_number': $variables.searchObjectVar.p_source_order_number ?  $variables.searchObjectVar.p_source_order_number : '',
                'p_to_date': $variables.searchObjectVar.p_to_date ?  $variables.searchObjectVar.p_to_date : '',
                'p_account_number': $variables.searchObjectVar.p_account_number ? $variables.searchObjectVar.p_account_number : '',
              },
            });

            $variables.ordersDetailsDBData =  response.body.items;
            $variables.ordersDetailsFusionData =  response2.body.items;

            console.log("DB DATA", JSON.stringify($variables.ordersDetailsDBData,null,2));
            console.log("FUSION DATA", JSON.stringify($variables.ordersDetailsFusionData,null,2));

            const assignDataToColumns = await $functions.assignDataToColumns($variables.ordersDetailsDBData, $variables.ordersDetailsFusionData);

            const addUniqueSeqToRecords = await $functions.addUniqueSeqToRecords(assignDataToColumns);

            // ---- TODO: Add your code here ---- //
            //console.log("Function Called", $variables.orderDetailsADP.data);

           $variables.orderDetailsADP.data = addUniqueSeqToRecords;

  //           if($variables.selectedRowArray.length > 0) {
  //           await Actions.resetVariables(context, {
  //             variables: [
  //   '$variables.selectedRowArray',
  //   '$variables.orderDetailsADP'
  // ],
  //           });
  //           }

            console.log("ADP DATA", JSON.stringify($variables.orderDetailsADP.data,null,2));

          // }
        }
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Please Select BU Name and Order Number',
          displayMode: 'transient',
          type: 'warning',
        });
      }
    }
  }

  return onSearchClickSearchButtonActionChainOLD;
});
