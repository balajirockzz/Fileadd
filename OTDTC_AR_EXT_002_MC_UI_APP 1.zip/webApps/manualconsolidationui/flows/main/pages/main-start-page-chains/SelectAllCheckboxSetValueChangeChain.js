define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectAllCheckboxSetValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any[]} params.value 
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { value, key, index, current }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      const ojDialog2267987401Open = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog--226798740-1',
        method: 'open',
      });
      //debugger;
      // ---- TODO: Add your code here ---- //
      console.log("Selected ALll Rows", $variables.selectAllRows);

      const updateADP = await $functions.updateADP($variables.orderDetailsADP.data, $variables.selectAllRows, 'rowSelected', '');

      // ---- TODO: Add your code here ---- //
      console.log(updateADP);

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.orderDetailsADP',
  ],
      });

      $variables.orderDetailsADP.data = updateADP;

      if ($page.variables.selectAllRows) {

        $variables.rowData = [];
        const results = await ActionUtils.forEach($variables.orderDetailsADP.data, async (item, index) => {
              let obj = {};
          if ($page.variables.orderDetailsADP.data[index].order_status === 'READY TO INVOICE' || $page.variables.orderDetailsADP.data[index].order_status === 'REPROCESS') {
              obj.seq_id = $page.variables.orderDetailsADP.data[index].seq_id;
              $page.variables.orderDetailsADP.data[index].rowSelected = true;
              $page.variables.rowData.push(obj);
          } else {
              $page.variables.orderDetailsADP.data[index].rowSelected = false;
              // $page.variables.rowData.push(obj);
          }
        }, { mode: 'parallel' });

        console.log("Checking RowData", $variables.rowData);
        //debugger;
        //console.log("Inside the Select All Action Chain and Data is : " , $page.variables.rowData);
        
        // const selectedRowData = await $functions.getSelectedRowData($variables.rowData, $variables.orderDetailsADP.data);
        
        // $variables.selectedRowADP.data = selectedRowData;
        // console.log("Selected Row ADP data : ", JSON.stringify($variables.selectedRowADP.data,null,2));

        const ojDialog2267987401Close = await Actions.callComponentMethod(context, {
          selector: '#oj-dialog--226798740-1',
          method: 'close',
        });
      } else {
        $variables.rowData = [];
        console.log("Checking RowData", $variables.rowData);
        // const selectedRowData = await $functions.getSelectedRowData($variables.rowData, $variables.orderDetailsADP.data);
        
        // $variables.selectedRowADP.data = selectedRowData;
        // console.log("Selected Row ADP data : ", JSON.stringify($variables.selectedRowADP.data,null,2));

        const ojDialog2267987401Close2 = await Actions.callComponentMethod(context, {
          selector: '#oj-dialog--226798740-1',
          method: 'close',
        });
      }
    }
  }

  return SelectAllCheckboxSetValueChangeChain;
});
