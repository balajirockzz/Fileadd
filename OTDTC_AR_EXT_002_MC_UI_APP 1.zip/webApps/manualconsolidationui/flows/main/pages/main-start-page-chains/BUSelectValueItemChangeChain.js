define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class BUSelectValueItemChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if (key) {

        //debugger;

        const ojDialog2267987401Open = await Actions.callComponentMethod(context, {
          selector: '#oj-dialog--226798740-1',
          method: 'open',
        });

        await Actions.resetVariables(context, {
          variables: [
    '$page.variables.searchObjectVar.p_account_number',
    '$page.variables.searchObjectVar.p_po_number',
    '$page.variables.searchObjectVar.p_source_order_number',
    '$page.variables.searchObjectVar.p_account_name',
    '$page.variables.paginationObject',
    '$page.variables.isNext',
    '$page.variables.isPrevious',
  ],
        });

        const response3 = await Actions.callRest(context, {
          endpoint: 'ORDS_CONN/getOTDTC_EXTAR_EXT_002GetCustAccNumberLOV',
          uriParams: {
            'p_business_unit_name': $variables.searchObjectVar.p_bu_name,
            limit: '100',
          },
        });
            
            if (!response3.ok) {
              const ojDialog2267987401Close4 = await Actions.callComponentMethod(context, {
                selector: '#oj-dialog--226798740-1',
                method: 'close',
              });
            
              return;
            } else {
          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.custAccNumberLOVADP',
  ],
          });

              $variables.custAccNumberLOVADP.data = response3.body.items;
            }

        const ojDialog2267987401Close = await Actions.callComponentMethod(context, {
          selector: '#oj-dialog--226798740-1',
          method: 'close',
        });
      }
    }
  }

  return BUSelectValueItemChangeChain;
});
