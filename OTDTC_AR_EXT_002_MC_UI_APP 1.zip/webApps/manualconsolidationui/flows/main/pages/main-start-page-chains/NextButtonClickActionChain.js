define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class NextButtonClickActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // ---- TODO: Add your code here ---- //
      // debugger;
      // console.log("Limit Before",$variables.paginationObject.limit);
      // console.log("Offset Before",$variables.paginationObject.offset);

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.selectAllRows',
    '$page.variables.rowData',
    '$page.variables.selectedRowADP',
  ],
      });

      $variables.paginationObject.offset = Number($variables.paginationObject.offset) + Number($variables.paginationObject.limit);

      // ---- TODO: Add your code here ---- //
            // console.log("Limit After",$variables.paginationObject.limit);
            // console.log("Offset After",$variables.paginationObject.offset);

      await Actions.callChain(context, {
        chain: 'ClickSearchButtonActionChain',
      });
    }
  }

  return NextButtonClickActionChain;
});
