define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class CustomerNumberSelectValueItemChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if (key) {

        const ojDialog2267987401Open = await Actions.callComponentMethod(context, {
          selector: '#oj-dialog--226798740-1',
          method: 'open',
        });

        $variables.searchObjectVar.p_account_name = data.customer_account_name;

        await Actions.resetVariables(context, {
          variables: [
    '$page.variables.searchObjectVar.p_source_order_number',
    '$page.variables.searchObjectVar.p_po_number',
    '$page.variables.paginationObject',
    '$page.variables.isNext',
    '$page.variables.isPrevious',
  ],
        });

        const results = await Promise.all([
          async () => {

            const response = await Actions.callRest(context, {
              endpoint: 'ORDS_CONN/getOTDTC_EXTAR_EXT_002GetOrderNumberLOV',
              uriParams: {
                'p_business_unit_name': $variables.searchObjectVar.p_bu_name,
                'p_customer_account_number': $variables.searchObjectVar.p_account_number,
                limit: '500',
              },
            });

            if (!response.ok) {
            
              const ojDialog2267987401Close = await Actions.callComponentMethod(context, {
                selector: '#oj-dialog--226798740-1',
                method: 'close',
              });

              return;
            } else {
              $variables.orderNumberLOVADP.data = response.body.items;
            }
          },
          async () => {

            const response2 = await Actions.callRest(context, {
              endpoint: 'ORDS_CONN/getOTDTC_EXTAR_EXT_002GetPONumberLOV2',
              uriParams: {
                limit: '100',
                'p_business_unit_name': $variables.searchObjectVar.p_bu_name,
                'p_customer_account_number': $variables.searchObjectVar.p_account_number,
              },
            });

            if (!response2.ok) {
              const ojDialog2267987401Close2 = await Actions.callComponentMethod(context, {
                selector: '#oj-dialog--226798740-1',
                method: 'close',
              });

                 return;
               } else {
                $variables.poNumberLOVADP.data = response2.body.items;
               }
          },
        ].map(sequence => sequence()));
        const ojDialog2267987401Close3 = await Actions.callComponentMethod(context, {
          selector: '#oj-dialog--226798740-1',
          method: 'close',
        });
      }

    }
  }

  return CustomerNumberSelectValueItemChangeChain;
});
