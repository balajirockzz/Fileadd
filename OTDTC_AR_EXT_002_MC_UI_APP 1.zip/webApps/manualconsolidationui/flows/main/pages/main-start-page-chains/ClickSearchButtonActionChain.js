define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ClickSearchButtonActionChain extends ActionChain {

    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const ojDialog2267987401Open = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog--226798740-1',
        method: 'open',
      });

      if (!($variables.searchObjectVar.p_bu_name && $variables.searchObjectVar.p_account_number)) {
          await Actions.fireNotificationEvent(context, {
          summary: 'Please Select BU Name, Order Number and Customer Account Number',
          displayMode: 'transient',
          type: 'warning',
        });

        const ojDialog2267987401Close = await Actions.callComponentMethod(context, {
          selector: '#oj-dialog--226798740-1',
          method: 'close',
        });
      } else {

          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.orderDetailsADP',
    '$page.variables.orderDetailsADP.data',
    '$page.variables.selectedRowArray',
    '$page.variables.selectedRowADP',
    '$page.variables.selectedRowADP.data',
  ],
          });

            // ---- TODO: Add your code here ---- //
            // debugger;

            const response = await Actions.callRest(context, {
              endpoint: 'ORDS_CONN/getOTDTC_EXTAR_EXT_002OnSearch',
              uriParams: {
                        'p_from_date': $variables.searchObjectVar.p_from_date ? $variables.searchObjectVar.p_from_date : '',
                        'p_to_date': $variables.searchObjectVar.p_to_date ? $variables.searchObjectVar.p_to_date : '',
                        'p_order_number': $variables.searchObjectVar.p_source_order_number ? $variables.searchObjectVar.p_source_order_number : '',
                        'p_po_number': $variables.searchObjectVar.p_po_number ? $variables.searchObjectVar.p_po_number : '',
                        'p_business_unit_name': $variables.searchObjectVar.p_bu_name ? $variables.searchObjectVar.p_bu_name : '',
                        'p_customer_account_number': $variables.searchObjectVar.p_account_number ? $variables.searchObjectVar.p_account_number : '',
              },
            });

        if (!response.body.hasMore) {
          $variables.isNext = true;
        } else {
          $variables.isNext = false;
        }

        if ($variables.paginationObject.offset !== 0) {
          $variables.isPrevious = false;
        } else {
          $variables.isPrevious = true;
        }

            console.log("DATA FROM PAAS DB", response);

            if (!response.ok) {

              await Actions.fireNotificationEvent(context, {
                summary: 'No Data Found',
                displayMode: 'transient',
                type: 'info',
              });

              const ojDialog2267987401Close2 = await Actions.callComponentMethod(context, {
                selector: '#oj-dialog--226798740-1',
                method: 'close',
              });

              return;
            } else {
              $variables.ordersDetailsDBData = response.body.items;

          // ---- TODO: Add your code here ---- //
          // debugger;

                const procesArray = await $functions.processArray($variables.ordersDetailsDBData);
              $variables.processObject = procesArray;

              const response2 = await Actions.callRest(context, {
                endpoint: 'OIC_CONN/getIcApiIntegrationV1FlowsRestOTD_AR_EXT_002_FET_OM_SM_EXC_LIN1_0Fetch_lines2',
                uriParams: {
                  'p_bill_line_ids': procesArray.bill_line_ids,
                  'p_subscription_numbers': procesArray.subscription_number,
                  'p_line_ids': procesArray.line_ids,
                  'p_order_numbers': procesArray.order_number,
                },
              });

              console.log("Data from Fusion ",response2);

              if (!response2.ok) {
              
                await Actions.fireNotificationEvent(context, {
                  displayMode: 'transient',
                  summary: 'No Data Found',
                  type: 'info',
                });

                const ojDialog2267987401Close3 = await Actions.callComponentMethod(context, {
                  selector: '#oj-dialog--226798740-1',
                  method: 'close',
                });

                return;
              } else {
                   $variables.ordersDetailsFusionData = response2.body.items;
                  //  let obj = {};
                  //  obj.LINE_TYPE = "OM";
                  //  $variables.ordersDetailsFusionData.push(obj);

                  console.log("FUSION DATA", JSON.stringify($variables.ordersDetailsFusionData,null,2));
              }
                const assignDataToColumns = await $functions.assignDataToColumns($variables.ordersDetailsDBData, $variables.ordersDetailsFusionData);

                const addUniqueSeqToRecords = await $functions.addUniqueSeqToRecords(assignDataToColumns);

               $variables.orderDetailsADP.data = addUniqueSeqToRecords;

                console.log("ADP DATA : ",$variables.orderDetailsADP.data);

              const ojDialog2267987401Close4 = await Actions.callComponentMethod(context, {
                selector: '#oj-dialog--226798740-1',
                method: 'close',
              });
            }
      }

      const ojDialog2267987401Close5 = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog--226798740-1',
        method: 'close',
      });
    }
  }

  return ClickSearchButtonActionChain;
});
