define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ClickPOMatchButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      let selectedRowData = await $functions.getSelectedRowData($variables.rowData, $variables.orderDetailsADP.data);

      $flow.variables.redirectionFlag = 'po';

      $variables.selectedRowADP.data = selectedRowData;

      const toMainPoMatch = await Actions.navigateToPage(context, {
        page: 'main-po-match',
        params: {
          searchObjectVarFromMain: $variables.searchObjectVar,
          selectedLinesFromMainPageArray: $variables.selectedRowADP.data,
        },
      });
    }
  }

  return ClickPOMatchButtonActionChain;
});
