define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableBeforeRowEditEndChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.cancelEdit 
     * @param {any} params.rowKey 
     * @param {number} params.rowIndex 
     * @param {any} params.rowData 
     */
    async run(context, { cancelEdit, rowKey, rowIndex, rowData }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await Actions.fireDataProviderEvent(context, {
        target: $variables.orderDetailsADP,
        update: {
          data: $variables.rowEditObj,
          keys: $variables.rowEditObj.seq_id,
        },
      });

      // ---- TODO: Add your code here ---- //
      //debugger;

      const updateDateInAllObject = await $functions.updateDateInAllObject($variables.orderDetailsADP.data, 'special_date', $variables.rowEditObj.special_date);

      $variables.orderDetailsADP.data = updateDateInAllObject;

      // await Actions.fireDataProviderEvent(context, {
      //   target: $variables.orderDetailsADP,
      //   refresh: null,
      // });
    }
  }

  return TableBeforeRowEditEndChain;
});
