define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojarraydataprovider'
], (
  ActionChain,
  Actions,
  ActionUtils,
  ArrayDataProvider
) => {
  'use strict';

  class TableSelectedChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any[]} params.keys 
     * @param {any} params.selected 
     */

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.selected 
     */
    async run(context, {keys, selected }) {
      console.log("keys", JSON.stringify(selected,null,2));
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      // debugger;
      
      //Previous Approach
      const selectedCheck = await $functions.selectedCheck($variables.orderDetailsADP.data, selected);
      console.log("Selected Check - ",selected);
      $variables.selectedRowADP.data = selectedCheck;
      console.log("Selected Row ADP data", JSON.stringify($variables.selectedRowADP.data, null, 2));

      console.log("Variables.variable1", $variables.variable1);


      // console.log("Selected", JSON.stringify(selected,null,2));
      // let myObj = {};
      // selected.row.keys.keys.forEach(value => {
      //   myObj[value] = true;
      //   console.log(value);
      // });
      // $variables.variable1 = myObj;
      // console.log("$variables.variable1",JSON.stringify($variables.variable1,null,2));

      // $variables.selectedRowArray = document.getElementById('orderDetails').data.data.filter((item, index) => $variables.variable1[index]);
      // console.log("Selected Row Array", JSON.stringify($variables.selectedRowArray, null, 2));

      // $variables.selectedRowADP.data =  $variables.selectedRowArray;
      // console.log("Selected Row ADP data", JSON.stringify($variables.selectedRowADP.data, null, 2));
      
    }
  }

  return TableSelectedChangeChain;
});
