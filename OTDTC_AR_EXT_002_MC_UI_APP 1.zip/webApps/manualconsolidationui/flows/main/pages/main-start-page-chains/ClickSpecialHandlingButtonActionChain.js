define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ClickSpecialHandlingButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const selectedRowData = await $functions.getSelectedRowData($variables.rowData, $variables.orderDetailsADP.data);

      // ---- TODO: Add your code here ---- //
      console.log("Special Handling: ", selectedRowData);

      $flow.variables.redirectionFlag = 'sh';

      $variables.selectedRowADP.data = selectedRowData;

      const toMainPoMatch = await Actions.navigateToPage(context, {
        page: 'main-po-match',
        params: {
          searchObjectVarFromMain: $variables.searchObjectVar,
          selectedLinesFromMainPageArray: $variables.selectedRowADP.data,
        },
      });
    }
  }

  return ClickSpecialHandlingButtonActionChain;
});
