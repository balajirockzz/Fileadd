define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const results = await Promise.all([
        async () => {

          try {
            const response3 = await Actions.callRest(context, {
              endpoint: 'ORDS_CONN/getOTDTC_EXTAR_EXT_002GetBuNameLOV',
            });

            if (response3.body.items) {
              $variables.buNameLOVADP.data = response3.body.items;
            } else {
              $variables.buNameLOVADP.data = [];
            }
          } catch (error) {
            await Actions.fireNotificationEvent(context, {
              displayMode: 'transient',
              type: 'error',
              summary: "Error while fetching Business Unit Names",
            });
          }

          const response4 = await Actions.callRest(context, {
            endpoint: 'TEST_ORDS/getTest_oauthGetTestData',
          });

          const response = await Actions.callRest(context, {
            endpoint: 'TEST_JJM/getGetTestData',
          });

          if (!response.ok) {
             // ---- TODO: Add your code here ---- //
             console.log("Error");
          
            return;
          } else {
            // ---- TODO: Add your code here ---- //
            console.log("data :");
            console.log(response);
          }

        },
        // async () => {

        //   const response2 = await Actions.callRest(context, {
        //     endpoint: 'ords/getOTDTC_EXTAR_EXT_002OnSearch',
        //     uriParams: {
        //       limit: '500',
        //     },
        //   });

        //   await $functions.createADP(response2.body.items, 'index');
        // },
      ].map(sequence => sequence()));
    }
  }

  return PageVbEnterChain;
});
