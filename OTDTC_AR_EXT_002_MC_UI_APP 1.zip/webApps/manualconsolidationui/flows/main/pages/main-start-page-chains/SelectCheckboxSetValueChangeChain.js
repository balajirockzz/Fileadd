define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectCheckboxSetValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any[]} params.value 
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { value, key, index, current }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      // debugger;
      
      // console.log("current - ", current);
      // console.log("current value - ", value);

      // // $variables.keyTempArray.push(current.item.data);
      // const checkDuplicateskeyTempArray = await $functions.checkDuplicates($variables.keyTempArray, current.item.data);
      

      // // const keyTempArray = await $functions.keyTempArray($variables.orderDetailsADP.data, $variables.keyTempArray);

      // const keyTempArray = await $functions.keyTempArray($variables.orderDetailsADP.data, checkDuplicateskeyTempArray);

      // // $variables.keyTempArray.push(100);

      // // $variables.keyTempArray.push(current.item.data.seq_id);
      // $variables.selectedRowADP.data = keyTempArray;

      // console.log("selected row data - ", $variables.selectedRowADP.data);

      //debugger;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.rowEditObj',
  ],
      });

      console.log("current", current);
      console.log("Value", value);

      $variables.rowEditObj = current.row;
      $variables.rowEditObj.rowSelected = value;

      console.log("RowEditObj rowSelected",  $variables.rowEditObj.rowSelected)
      
      await Actions.fireDataProviderEvent(context, {
        target: $variables.orderDetailsADP,
        update: {
          data: $variables.rowEditObj,
          keys: key,
        },
      });

      if (value) {
        let obj = {};
        obj.seq_id = key;
        $page.variables.rowData.push(obj);

        // ---- TODO: Add your code here ---- //
        console.log("Checking RowData", $variables.rowData);
        //debugger;
        
        // const selectedRowData = await $functions.getSelectedRowData($variables.rowData, $variables.orderDetailsADP.data);
        
        // $variables.selectedRowADP.data = selectedRowData;
        // console.log("Selected Row ADP data : ", JSON.stringify($variables.selectedRowADP.data,null,2));
      }
      else {
        const callFunctionResult = await $page.functions.deselectRowKey($page.variables.rowData, key);
        console.log("Checking RowData", $variables.rowData);
        // const selectedRowData = await $functions.getSelectedRowData($variables.rowData, $variables.orderDetailsADP.data);
        
        // $variables.selectedRowADP.data = selectedRowData;
        // console.log("Selected Row ADP data : ", JSON.stringify($variables.selectedRowADP.data,null,2));
      }
    }
  }

  return SelectCheckboxSetValueChangeChain;
});
