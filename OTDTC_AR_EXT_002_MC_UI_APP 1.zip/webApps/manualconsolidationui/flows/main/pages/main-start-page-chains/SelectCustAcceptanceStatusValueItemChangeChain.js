define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectCustAcceptanceStatusValueItemChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, data, metadata, index, current }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // ---- TODO: Add your code here ---- //
      console.log("Key", key);
      // console.log("Value", value);
      console.log("Current", current);
      
  
      if ($variables.rowEditObj.customer_acceptance_status) {
        $variables.rowEditObj.acceptance_status_username = $application.user.username;
        $variables.rowEditObj.customer_acceptance_date = new Date().toISOString().split('T')[0];
      } else if ($variables.rowEditObj.customer_acceptance_status === null) {
        $variables.rowEditObj.customer_acceptance_date = null;
      } else {
        $variables.rowEditObj.customer_acceptance_date = null;
      }

    }
  }

  return SelectCustAcceptanceStatusValueItemChangeChain;
});
