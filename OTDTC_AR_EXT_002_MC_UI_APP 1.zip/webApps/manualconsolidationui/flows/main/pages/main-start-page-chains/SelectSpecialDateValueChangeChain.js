define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectSpecialDateValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { value, key, index, current }) {
      const { $page, $flow, $application, $constants, $variables, $current, $functions } = context;

      // ---- TODO: Add your code here ---- //
      // console.log("Special date change event raised", current);
      // console.log("Current Row ", current.row);
      // console.log("selected date ", current.row.special_date);
      debugger;
      
      $variables.rowObj = current.row;

      const updateDateInObject = await $functions.updateDateInObject($variables.rowObj, "special_date", $variables.specialDateVar);

      await Actions.fireDataProviderEvent(context, {
        target: $variables.orderDetailsADP,
        update: {
          data: updateDateInObject,
          keys: $variables.rowObj.seq_id,
        },
      });
    }
  }

  return SelectSpecialDateValueChangeChain;
});
