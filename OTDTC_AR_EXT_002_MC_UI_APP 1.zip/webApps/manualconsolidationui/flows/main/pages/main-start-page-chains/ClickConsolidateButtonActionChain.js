define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ClickConsolidateButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      // ---- TODO: Add your code here ---- //

      //arr = document.getElementById('orderDetails').data.data;


      //filteredArray = arr.filter((obj,index) => $variables.variable1.hasOwnProperty(index.toString()));

      //filteredArray = arr.filter((obj,index) => obj.seq_id==index);

      // console.log("Filtered Array", JSON.stringify(filteredArray,null,2));


      // await Actions.callRest(context, {
      //   endpoint: 'ics/postIcApiIntegrationV1FlowsRestOTDT_AR_EXT_002_AR_INVO_CREA1_0Invoice',
      //              'OIC_CONN/postIcApiIntegrationV1FlowsRestOTDT_AR_EXT_002_AR_INVO_BATC_PRO1_0Invoice'
      // });

      // console.log("$variables.variable1", JSON.stringify($variables.variable1,null,2));

      const ojDialog2267987401Open = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog--226798740-1',
        method: 'open',
      });

      const selectedRowData = await $functions.getSelectedRowData($variables.rowData, $variables.orderDetailsADP.data);

      $variables.selectedRowADP.data = selectedRowData;

      const validateFields = await $functions.validateFields(selectedRowData);

      if (!validateFields.valid) {

        console.log("Validate Value: ", validateFields.valid);
        console.log("Validate Message: ", validateFields.message);
        await Actions.fireNotificationEvent(context, {
          summary: validateFields.message
        });

        const ojDialog2267987401Close3 = await Actions.callComponentMethod(context, {
          selector: '#oj-dialog--226798740-1',
          method: 'close',
        });

        return;
      } else {

        // ---- TODO: Add your code here ---- //
        console.log("New Selected Row ADP Data", $variables.selectedRowADP.data);

        let arr = [];
        let filteredArray = [];

        const constructPayload = await $functions.constructPayload($variables.searchObjectVar, $variables.selectedRowADP.data);

        const response2 = await Actions.callRest(context, {
          endpoint: 'OIC_CONN/postIcApiIntegrationV1FlowsRestOTDT_AR_EXT_002_AR_INVO_BATC_PRO1_0Invoice',
          body: constructPayload,
        });

        if (response2.body.status === "SUCCESS") {
          //debugger;
          
          await Actions.fireNotificationEvent(context, {
            displayMode: 'transient',
            type: 'confirmation',
            message: response2.body.message,
            summary: 'Status',
          });

          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.orderDetailsADP',
    '$page.variables.selectedRowADP',
    '$page.variables.searchObjectVar',
    '$page.variables.rowData',
  ],
          });

          const ojDialog2267987401Close = await Actions.callComponentMethod(context, {
            selector: '#oj-dialog--226798740-1',
            method: 'close',
          });

          return;
        } else {

          await Actions.fireNotificationEvent(context, {
            summary: 'Invoice Creation Failed',
          });

          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.orderDetailsADP',
    '$page.variables.selectedRowADP',
    '$page.variables.searchObjectVar',
    '$page.variables.rowData',
  ],
          });

          const ojDialog2267987401Close2 = await Actions.callComponentMethod(context, {
            selector: '#oj-dialog--226798740-1',
            method: 'close',
          });

          return;
        }
      }

    }
  }

  return ClickConsolidateButtonActionChain;
});
