define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ClickResetButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // console.log("rowData before reset", $page.variables.rowData);

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.searchObjectVar',
    '$page.variables.orderDetailsADP',
    '$page.variables.selectedRowADP',
    '$page.variables.selectedRowArray',
    '$page.variables.rowData',
    '$page.variables.paginationObject',
    '$page.variables.isNext',
    '$page.variables.isPrevious',
  ],
      });

       console.log("rowData after reset",$page.variables.searchObjectVar);
    }
  }

  return ClickResetButtonActionChain;
});
