define(['ojs/ojarraydataprovider'], (ArrayDataProvider) => {
  'use strict';

  class PageModule {
  }

  // PageModule.prototype.getColor = function(source_table) {
  //   if(source_table === 'SALES-F'|| source_table === 'SUBSCRIPTION-F') {
  //       return "red";
  //     }
  //     else {
  //       return "blue";
  //     }
  // };

    PageModule.prototype.getColor = function (status) {
      // console.log("Source_table value:", status);
    if ((String(status).trim().toUpperCase() !== "READY TO INVOICE") && (String(status).trim().toUpperCase() !== "REPROCESS")) {
       return "grey"; 
    }
    return "black";
  };

  PageModule.prototype.updateDateInAllObject = function (arr, fieldName, newValue) {
      return arr.map(item => {
        if((item.source_table === 'SALES' || item.source_table === 'SUBSCRIPTIONS') && item.order_status === 'READY TO INVOICE') {
             return {...item, [fieldName]: newValue};
        } else {
          return item;
        }
      });
  };

  PageModule.prototype.processArray = function(arrInput) {

    let output = {
      order_number : "",
      line_ids : "",
      subscription_number : "",
      bill_line_ids : ""
    };

    let orderLines = {};
    let subscriptionLines = {};

    arrInput.forEach(item => {
    if(item.source_table === "SALES" && item.sales_or_subsc_no) {
      if(!orderLines[item.sales_or_subsc_no]) {
        orderLines[item.sales_or_subsc_no] = [];
      }
      orderLines[item.sales_or_subsc_no].push(item.line_id);
    } else if (item.source_table === "SUBSCRIPTIONS" && item.sales_or_subsc_no) {
      if(!subscriptionLines[item.sales_or_subsc_no]) {
        subscriptionLines[item.sales_or_subsc_no] = [];
      }
      subscriptionLines[item.sales_or_subsc_no].push(item.line_id);
    }
  });

    output.order_number = Object.keys(orderLines).join(",");
    output.line_ids = Object.values(orderLines).map(lines => lines.join(",")).join(",");
    output.subscription_number = Object.keys(subscriptionLines).join(",");
    output.bill_line_ids = Object.values(subscriptionLines).map(lines => lines.join(",")).join(",");

    console.log("Output from ProcessArray Function : ", output);

    return output;
  };
  

  PageModule.prototype.deselectRowKey = function (array, key) {
    const index = array.findIndex(obj => obj.seq_id === key);
    if (index !== -1) {
      array.splice(index, 1);
    }
    return array;
  };

  PageModule.prototype.updateADP = function (arr, value, field, key) {
    return arr.map(obj => ({ ...obj, ['rowSelected']: value }));
  };


  PageModule.prototype.getSelectedRowData = function (rowData, data) {
    //Extracting Unique seq_ids from first array
    const seq_ids = rowData.map(item => item.seq_id);
    //Filtering the second array based on seq_ids from first array
    const filteredArray = data.filter(item => seq_ids.includes(item.seq_id));
    console.log("Filtered Array", filteredArray);
    return filteredArray;
  };

  PageModule.prototype.addUniqueSeqToRecords = function (recordsArr) {
    return recordsArr.map((record, index) => ({
        ...record,
        seq_id: index + 1
      }));
  };

  PageModule.prototype.checkDuplicates = function (mainArray, value) {
    //debugger;
    console.log("mainArray - ", mainArray);
    console.log("value - ", value);
    let itemSeqIds = -1;
    // mainArray.forEach((item, i) => { 
    for (let i = 0; i < mainArray.length; i++) {
      if (mainArray[i].seq_id === value.seq_id) {
        itemSeqIds = i;
      }
    }
    if (itemSeqIds === -1) {
      mainArray.push(value);
    } else {
      mainArray.splice(itemSeqIds, 1);
    }
    return mainArray;
  };


  PageModule.prototype.keyTempArray = function (mainArray, items) {
    // debugger;
    const itemSeqIds = items.map(item => item.seq_id);
    const res = mainArray.filter(main => itemSeqIds.includes(main.seq_id));
    return res;
  };


  PageModule.prototype.handleSelectionChanged = function (event, dataADP) {
    const selectedRowKeys = event.detail.value;
    const tableData = dataADP;

  };

  PageModule.prototype.selectedCheck = function (arr, selected) {
    let iterator = selected.row.addAll();
    let newArr;

    if (selected.row.isAddAll()) {
      let itrtDel = selected.row.deletedValues();
      let deSel = [];
      let ob = {};
      itrtDel.forEach(index => {
        ob = index;
        deSel.push(index); //composite key
      });
      let deletedSet = new Set(deSel);
      newArr = arr.filter((ele, index) => !deletedSet.has(index));
    }
    else {
      let sel = [];
      if (selected.row.values().size > 0) {
        selected.row.values().forEach(index => {
          sel.push(index); //composite key
        });
      }
      let selectSet = new Set(sel);
      newArr = arr.filter((ele, index) => selectSet.has(index));
    }
    return newArr;
  };

  PageModule.prototype.constructPayload = function (searchObj, selectedLinesArray) {
    const p_bu_name = searchObj.p_bu_name;
    const p_order_number = searchObj.p_source_order_number;
    const p_customer_account_number = searchObj.p_account_number;
    const p_po_number = searchObj.p_po_number;
    const p_from_date = searchObj.p_from_date;
    const p_to_date = searchObj.p_to_date;

    const p_lines_arr = selectedLinesArray;

    const payload = {
      bu_name: p_bu_name,
      order_number: p_order_number,
      customer_account_number: p_customer_account_number,
      po_number: p_po_number,
      from_date: p_from_date,
      to_date: p_to_date,
      lines: p_lines_arr
    };
    console.log("construct Payload Response-Consolidation Object", payload);
    return payload;

  };


  PageModule.prototype.assignDataToColumns = function (items, response) {
    // debugger;
    const newArray = [];

    items.forEach(item => {
      const newItem = {
        source_table: item.source_table || '',
        bu_name: item.bu_name || '',
        line_number: item.line_number || 0,
        order_status: item.order_status || '',
        order_number: item.order_number || '',
        line_amount: item.line_amount || '',
        tax_amount: item.tax_amount || '',
        total_amount: item.total_amount || '',
        fx_rate: item.fx_rate || '',
        bill_to_customer_name: item.bill_to_customer_name || '',
        bill_to_customer_number: item.bill_to_customer_number || '',
        vat_id: item.vat_id || '',
        line_id: item.line_id || '',
        quantity: item.quantity || '',
        unit_selling_price: item.unit_selling_price || '',
        description: item.description || '',
        product_type: item.product_type || '',
        unit_of_measure: item.unit_of_measure || '',
        invoice_number: item.invoice_number || '',
        consolidation_method: item.consolidation_method || '',
        e_invoicing_flag: item.e_invoicing_flag || '',
        custom_invoicing_flag: item.custom_invoicing_flag || '',
        date_filter_param: item.date_filter_param || '',
        tax_classification_code: item.tax_classification_code || '',
        item_number: item.item_number || '',
        trx_business_category: item.trx_business_category || '',
        remit_number: item.remit_number || '',
        igst: item.igst || '',
        special_date : item.special_date || '',
        bu_id : item.bu_id || '',
        transaction_type : item.transaction_type || '',
        transaction_source : item.transaction_source || '',
        bill_to_customer_site : item.bill_to_customer_site || '',
        ship_to_customer_number : item.ship_to_customer_number || '',
        ship_to_customer_site :item.ship_to_customer_site || '',
        payment_term : item.payment_term || '',
        invoice_currency_code : item.invoice_currency_code || '',
        interface_line_attribute1 : item.interface_line_attribute1 || '',
        interface_line_attribute2 : item.interface_line_attribute2 || '',
        interface_line_attribute3 : item.interface_line_attribute3 || '',
        interface_line_attribute4 : item.interface_line_attribute4 || '',
        interface_line_attribute5 : item.interface_line_attribute5 || '',
        interface_line_attribute6 : item.interface_line_attribute6 || '',
        interface_line_attribute7 : item.interface_line_attribute7 || '',
        interface_line_attribute8 : item.interface_line_attribute8 || '',
        interface_line_attribute9 : item.interface_line_attribute9 || '',
        interface_line_attribute10 : item.interface_line_attribute10 || '',
        interface_line_attribute11 : item.interface_line_attribute11 || '',
        interface_line_attribute12 : item.interface_line_attribute12 || '',
        interface_line_attribute13 : item.interface_line_attribute13 || '',
        interface_line_attribute14 : item.interface_line_attribute14 || '',
        qbli_flag_d : item.qbli_flag_d || '',
        special_date_flag_d : item.special_date_flag_d || '',
        additional_details_flag_d : item.additional_details_flag_d || '',
        special_instructions_flag_d : item.special_instructions_flag_d || '',
        conditional_sales_hold : item.conditional_sales_hold || '',
        customer_acceptance_status : item.customer_acceptance_status || '',
        customer_acceptance_date : item.customer_acceptance_date || '',
        acceptance_status_username : item.acceptance_status_username || '',
        pedimento_number : item.pedimento_number || '',
        pedimento_date : item.pedimento_date || '',
        consporate_type_number1 : item.consporate_type_number1 || '',
        consporate_type_number2 : item.consporate_type_number2 || ''
      };
      newArray.push(newItem);
    });


    response.forEach(item => {
        const newItem = {
          source_table: item.SOURCE_TABLE || '',
          bu_name: item.BUSINESS_UNIT_NAME || '',
          line_number: item.LINE_NUMBER || 0,
          order_status: item.STATUS || '',
          order_number: item.ORDER_NUMBER || '',
          line_amount: item.LINE_AMOUNT || '',
          tax_amount: item.TAX_AMOUNT || '',
          total_amount: item.TOTAL_AMOUNT || '',
          fx_rate: item.FX_RATE || '',
          bill_to_customer_name: item.BILL_TO_CUSTOMER_NAME || '',
          bill_to_customer_number: item.BILL_TO_CUSTOMER_NUMBER || '',
          vat_id: item.VAT_ID || '',
          line_id: item.BILL_LINE_ID || '',
          quantity: item.QUANTITY || '',
          unit_selling_price: item.UNIT_SELLING_PRICE || '',
          description: item.DESCRIPTION || '',
          product_type: item.PRODUCT_TYPE || '',
          unit_of_measure: item.UNIT_OF_MEASURE || '',
          invoice_number: item.INVOICE_NUMBER || '',
          consolidation_method: item.CONSOLIDATION_METHOD || '',
          e_invoicing_flag: item.E_INVOICING_FLAG || '',
          custom_invoicing_flag: item.CUSTOM_INVOICING_FLAG || '',
          date_filter_param: item.DATE_FILTER_PARAM || '',
          tax_classification_code: item.TAX_CLASSIFICATION_CODE || '',
          item_number: item.ITEM_NUMBER || '',
          trx_business_category: item.TRX_BUSINESS_CATEGORY || '',
          remit_number: item.REMIT_NUMBER || '',
          igst: item.IGST || '',
          special_date : item.SPECIAL_DATE || '',
          bu_id : item.BU_ID || '',
          transaction_type : item.TRANSACTION_TYPE || '',
          transaction_source : item.TRANSACTION_SOURCE || '',
          bill_to_customer_site : item.BILL_TO_CUSTOMER_SITE || '',
          ship_to_customer_number : item.SHIP_TO_CUSTOMER_NUMBER || '',
          ship_to_customer_site :item.SHIP_TO_CUSTOMER_SITE || '',
          payment_term : item.PAYMENT_TERM || '',
          invoice_currency_code : item.INVOICE_CURRENCY_CODE || '',
          interface_line_attribute1 : item.INTERFACE_LINE_ATTRIBUTE1 || '',
        interface_line_attribute2 : item.INTERFACE_LINE_ATTRIBUTE2 || '',
        interface_line_attribute3 : item.INTERFACE_LINE_ATTRIBUTE3 || '',
        interface_line_attribute4 : item.INTERFACE_LINE_ATTRIBUTE4 || '',
        interface_line_attribute5 : item.INTERFACE_LINE_ATTRIBUTE5 || '',
        interface_line_attribute6 : item.INTERFACE_LINE_ATTRIBUTE6 || '',
        interface_line_attribute7 : item.INTERFACE_LINE_ATTRIBUTE7 || '',
        interface_line_attribute8 : item.INTERFACE_LINE_ATTRIBUTE8 || '',
        interface_line_attribute9 : item.INTERFACE_LINE_ATTRIBUTE9 || '',
        interface_line_attribute10 : item.INTERFACE_LINE_ATTRIBUTE10 || '',
        interface_line_attribute11 : item.INTERFACE_LINE_ATTRIBUTE11 || '',
        interface_line_attribute12 : item.INTERFACE_LINE_ATTRIBUTE12 || '',
        interface_line_attribute13 : item.INTERFACE_LINE_ATTRIBUTE13 || '',
        interface_line_attribute14 : item.INTERFACE_LINE_ATTRIBUTE14 || '',
        qbli_flag_d : item.QBLI_FLAG_D || '',
        special_date_flag_d : item.SPECIAL_DATE_FLAG_D || '',
        additional_details_flag_d : item.ADDITIONAL_DETAILS_FLAG_D || '',
        special_instructions_flag_d : item.SPECIAL_INSTRUCTIONS_FLAG_D || '',
        conditional_sales_hold : item.CONDITIONAL_SALES_HOLD || '',
        customer_acceptance_status : item.CUSTOMER_ACCEPTANCE_STATUS || '',
        customer_acceptance_date : item.CUSTOMER_ACCEPTANCE_DATE || '',
        acceptance_status_username : item.ACCEPTANCE_STATUS_USERNAME || '',
        pedimento_number : item.PEDIMENTO_NUMBER || '',
        pedimento_date : item.PEDIMENTO_DATE || '',
        consporate_type_number1 : item.CONSPORATE_TYPE_NUMBER1 || '',
        consporate_type_number2 : item.CONSPORATE_TYPE_NUMBER2 || ''
        };

        newArray.push(newItem);

    });


    return newArray;
  };



  // PageModule.prototype.selectedCheck = function (arr, selected) {
  //          debugger;
  //   let iterator = selected.row.addAll();
  //   let newArr;
  //   if(selected.row.isAddAll()) {
  //     let itrtDel = selected.row.deletedValues();
  //     let deSel = [];
  //     let ob = {};
  //     itrtDel.forEach(key => {
  //       ob = key;
  //       let compositeKey = `${key.order_number}-${key.line_number}`
  //       deSel.push(compositeKey); //composite key
  //     });
  //     let deletedSet = new Set(deSel);
  //     newArr = arr.filter(ele => {
  //         let compositeKey = `${ele.order_number}-${ele.line_number}`;
  //         return !deletedSet.has(compositeKey);
  //       });
  //   }
  //   else {
  //     let sel = [];
  //     if(selected.row.values().size > 0){
  //       selected.row.values().forEach(key => {
  //         let compositeKey = `${key.order_number}-${key.line_number}`;
  //         sel.push(compositeKey); //composite key
  //       });
  //     }
  //     let selectSet = new Set(sel);
  //     newArr = arr.filter(ele => {
  //       let compositeKey = `${ele.order_number}-${ele.line_number}`;
  //       return selectSet.has(compositeKey);
  //     });
  //   }
  //   return newArr;
  // };



  PageModule.prototype.createADP = function (data, key) {
    let table = document.getElementById('orderDetails');
    table.data = new ArrayDataProvider(data, { keyAttributes: "@index" });
    console.log("Create ADP function is called");
    console.log("Data which are being assigned to table is", JSON.stringify(table.data, null, 2));
  };

  PageModule.prototype.filterArray = function (arr, fieldToFilter) {
    let distinct = [];
    let unique = [];
    for (let i = 0; i < arr.length; i++) {
      if (!unique[arr[i][fieldToFilter]]) {
        distinct.push(arr[i]);
        unique[arr[i][fieldToFilter]] = 1;
      }
    }
    return distinct;
  };
  PageModule.prototype.getColor=function(status){
    switch(status){
      case 'COMPLETED':
        return {"background-color":"grey"};
    }
  };

  PageModule.prototype.validateFields = function(selectedRowsArr) {
    const requiredFields = ['customer_acceptance_status','customer_acceptance_date'];
    const invalidRows = [];

    selectedRowsArr.forEach((row) => {
      const hasMissing = requiredFields.some(field => {
        return !row[field] || row[field].toString().trim() === '';
      });
      if(hasMissing) {
        invalidRows.push(row.line_id || 'UNKNOWN');
      }
    });
    if(invalidRows.length > 0) {
      if(invalidRows.length > 5) {
        return {
          valid: false,
          message: `5 or more lines are missing required fields. Please update before invoice creation.`
        };
      } else {
        return {
          valid: false,
          message: `Please fill all required fields in row(s): ${invalidRows.join(', ')}`
        };
      }
    }
    return {
      valid: true,
      message: ''
    };
  }

  PageModule.prototype.isAcceptanceEditable = function(row) {
    // debugger;
    // console.log("isAcceptanceEditable Function Call: ",row);
    if(!row) return false;

    const orderStatus = (row.order_status || '').toUpperCase().trim();
    const holdStatus = (row.conditional_sales_hold || '').toUpperCase().trim();
    return (
      (orderStatus === 'READY TO INVOICE' || orderStatus === 'REPROCESS') && 
      (holdStatus === 'BB' || holdStatus === 'RBB')
      );
  };

  return PageModule;
});
