define([], () => {
  'use strict';

  class PageModule {
  }

  PageModule.prototype.selectedCheck = function (arr, selected) {
    let iterator = selected.row.addAll();
    let newArr;

    if (selected.row.isAddAll()) {
      let iteratorDel = selected.row.deletedValues();
      let deSelected = [];
      let ob = {};
      iteratorDel.forEach(key => {
        ob = key;
        deSelected.push(key); //composite key
      });
      let deletedSet = new Set(deSelected);
      newArr = arr.filter(ele => {
        return !deletedSet.has(ele.seq_id);
      });
    } else {
      let selectedArray = [];
      if (selected.row.values().size > 0) {
        selected.row.values().forEach(key => {
          selectedArray.push(key); //composite key
        });
      }
      let selectSet = new Set(selectedArray);
      newArr = arr.filter(ele => { 
          return selectSet.has(ele.seq_id);
      });
    }
    return newArr;
  };

  PageModule.prototype.enableDisableColumnFlags = function(dataArray) {
    let hasQbliValue = true;
    let hasSpecialDateValue = true;
    let hasAdditionalDetailsValue = true;
    let hasSpecialInstructionsValue = true;

    for (const item of dataArray) {
      if(item.qbli_flag_d == null || item.qbli_flag_d === '') {
          hasQbliValue = false;
      }
      if(item.special_date_flag_d == null || item.special_date_flag_d === '') {
          hasSpecialDateValue = false;
      }
      if(item.additional_details_flag_d == null || item.additional_details_flag_d === '') {
          hasAdditionalDetailsValue = false;
      }
      if(item.special_instructions_flag_d == null || item.special_instructions_flag_d === '') {
          hasSpecialInstructionsValue = false;
      }
    }

    const enableQbliColumnFlag = hasQbliValue;
    const enableSpecialDateColumnFlag = hasSpecialDateValue;
    const enableAdditionalDetailsColumnFlag = hasAdditionalDetailsValue;
    const enableSpecialInstructionsColumnFlag = hasSpecialInstructionsValue;
    
    return {
      enableQbliColumnFlag,
      enableSpecialDateColumnFlag,
      enableAdditionalDetailsColumnFlag,
      enableSpecialInstructionsColumnFlag
    };
  };

  PageModule.prototype.flattenNestedArrayField = function(dataArray, targetField) {
    return dataArray.map(item => {
      const newItem = { ...item };

      if(Array.isArray(newItem[targetField])) {
        newItem[targetField] = newItem[targetField].join(' ');
      }
      return newItem;
    });
  };

    PageModule.prototype.updateSelectedValueInAllRow = function (arr, fieldName, newValue) {
      return arr.map(item => {
        if(item.source_table === 'SALES' || item.source_table === 'SUBSCRIPTIONS') {
             return {...item, [fieldName]: newValue};
        } else {
          return item;
        }
      });
  };

  PageModule.prototype.syncLineFieldsFromFirstLine = function(data) {
    const fieldsToSync = ["special_date_po_match", "special_instruction", "additional_details"];

    //Get the reference values from the first line(if available)
    const firstLine = data.lines && data.lines[0];
    if(!firstLine) return data;

    const referenceValues = {};

    fieldsToSync.forEach(field => {
      const value = firstLine[field];
      if(value !== undefined && value !== "") {
        referenceValues[field] = value;
      }
    });
    //Apply values to all lines(starting from 1 since 0 is already correct)
    data.lines = data.lines.map((line, index) => {
      if(index === 0) return line; //leave the first line as is

      const updateLine = { ...line };
      for (const field of fieldsToSync) {
        if(updateLine[field] === undefined || updateLine[field] === "") {
          updateLine[field] = referenceValues[field];
        }
      }
      return updateLine;
    });
  return data;
  };

  // PageModule.prototype.isFieldEditable = function(row, fieldName) {
  //   if(!row || !fieldName) return false;

  //   const bu = (row.bu_name || '').toUpperCase().trim();

  //   //rules - US_PL_USD_BU, MX_PL_MXN_BU, AR_PL_USD_BU, CL_PL_CLP_BU, CO_PL_COP_BU
  //   const rules = {
  //     MX_PL_MXN_BU: ['pedimento_number','pedimento_date'],
  //     AR_PL_USD_BU: ['consporate_type_number1','consporate_type_number2'],
  //     CL_PL_CLP_BU: ['consporate_type_number1','consporate_type_number2'],
  //     CO_PL_COP_BU: ['consporate_type_number1','consporate_type_number2']
  //   };

  //   const editableFouBU = rules[bu] || [];
  //   return editableFouBU.includes(fieldName);
  // };

  PageModule.prototype.isFieldEditable = function(row, fieldName) {
    if(!row || !fieldName) return false;

    const bu = (row.bu_name || '').toUpperCase().trim();

    //rules now include "fields" and "requireEmpty" flags
    const rules = {
      MX_PL_MXN_BU: {
			fields : ['pedimento_number','pedimento_date'],
			requireEmpty : true //editable only when field is empty
	  },
	  AR_PL_USD_BU: {
			fields : ['consporate_type_number1','consporate_type_number2'],
			requireEmpty : false //always editable
	  },
	  CL_PL_CLP_BU: {
			fields : ['consporate_type_number1','consporate_type_number2'],
			requireEmpty : false
	  },
	  CO_PL_COP_BU: {
			fields : ['consporate_type_number1','consporate_type_number2'],
			requireEmpty : false
	  }
	};
	  
	const buRule = rules[bu];
	if(!buRule) return false;
	
	const { fields, requireEmpty } = buRule;
	
	if(!fields.includes(fieldName)) return false;
	
	//If requireEmpty is true -> allow editing only if current value is empty
	if(requireEmpty) {
		const currentValue = row[fieldName];
		return !currentValue; //editable only if empty
	}

    return true; // editable if matched and no restriction
  };




  // PageModule.prototype.validateFields = function(selectedRowsArr) {
  //   const requiredFields = ['pedimento_number','pedimento_date','consporate_type_number1','consporate_type_number2'];
  //   const invalidRows = [];

  //   selectedRowsArr.forEach((row) => {
  //     const hasMissing = requiredFields.some(field => {
  //       return !row[field] || row[field].toString().trim() === '';
  //   });
  //     if(hasMissing) {
  //       invalidRows.push(row.line_id || 'UNKNOWN');
  //     }
  //   });
  //   if(invalidRows.length > 0) {
  //     if(invalidRows.length > 5) {
  //       return {
  //         valid: false,
  //         message: `5 or more lines are missing required fields. Please update before invoice creation.`
  //       };
  //     } else {
  //       return {
  //         valid: false,
  //         message: `Please fill all required fields in row(s): ${invalidRows.join(', ')}`
  //       };
  //     }
  //   }
  //   return {
  //     valid: true,
  //     message: ''
  //   };
  // }

   PageModule.prototype.validateFields = function (selectedRowsArr, buName) {
    const BU_REQUIRED_FIELDS = {
      MX_PL_MXN_BU: ['pedimento_number', 'pedimento_date'],
      AR_PL_USD_BU: ['consporate_type_number1', 'consporate_type_number2'],
      CL_PL_CLP_BU: ['consporate_type_number1', 'consporate_type_number2'],
      CO_PL_COP_BU: ['consporate_type_number1', 'consporate_type_number2']
    };

    // Default to empty array if BU not found
    const requiredFields = BU_REQUIRED_FIELDS[buName] || [];

    const invalidRows = [];

    selectedRowsArr.forEach((row) => {
      const hasMissing = requiredFields.some(field => {
        return !row[field] || row[field].toString().trim() === '';
      });

      if (hasMissing) {
        invalidRows.push(row.line_id || 'UNKNOWN');
      }
    });

    if (invalidRows.length > 0) {
      if (invalidRows.length > 5) {
        return {
          valid: false,
          message: `5 or more lines are missing required fields for ${buName}. Please update before invoice creation.`
        };
      } else {
        return {
          valid: false,
          message: `Please fill all required fields in row(s): ${invalidRows.join(', ')} for ${buName}`
        };
      }
    }

    return {
      valid: true,
      message: ''
    };
  };

  
  return PageModule;
});
