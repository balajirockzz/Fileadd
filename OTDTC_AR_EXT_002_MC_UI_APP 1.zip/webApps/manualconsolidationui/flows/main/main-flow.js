/* Copyright (c) 2024, Oracle and/or its affiliates */

define([], function() {
  'use strict';

  class FlowModule {
  }

  FlowModule.prototype.addUniqueSeqToRecords = function (recordsArr) {
    return recordsArr.map((record, index) => ({
        ...record,
        seq_id: index
      }));
  };

  FlowModule.prototype.constructPayload = function (userid,searchObj, selectedLinesArray) {
    const p_bu_name = searchObj.p_bu_name;
    const p_order_number = searchObj.p_source_order_number;
    const p_customer_account_number = searchObj.p_account_number;
    const p_po_number = searchObj.p_po_number;
    const p_from_date = searchObj.p_from_date;
    const p_to_date = searchObj.p_to_date;
    const p_user_id = userid;

    const p_lines_arr = selectedLinesArray;

    const payload = {
      bu_name: p_bu_name,
      order_number: p_order_number,
      customer_account_number: p_customer_account_number,
      po_number: p_po_number,
      from_date: p_from_date,
      to_date: p_to_date,
      user_id: p_user_id,
      lines: p_lines_arr
    };
    console.log("construct Payload Response-Consolidation Object", payload);
    return payload;

  };

  return FlowModule;
});
