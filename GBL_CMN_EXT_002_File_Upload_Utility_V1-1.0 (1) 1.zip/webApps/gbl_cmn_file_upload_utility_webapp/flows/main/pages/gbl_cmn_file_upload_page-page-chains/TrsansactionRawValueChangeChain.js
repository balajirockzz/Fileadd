define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TrsansactionRawValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.rawValue 
     */
    async run(context, { rawValue }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.searchParam_Var.transactionID = rawValuerawValue;
    }
  }

  return TrsansactionRawValueChangeChain;
});
