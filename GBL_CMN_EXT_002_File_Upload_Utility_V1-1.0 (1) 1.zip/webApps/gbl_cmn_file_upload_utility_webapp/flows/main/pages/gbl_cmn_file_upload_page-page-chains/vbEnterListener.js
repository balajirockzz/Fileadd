define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const rolesADP = await Actions.callRest(context, {
        endpoint: 'ORDS_CONN/geRolesfromATP',
      });

      if (rolesADP.ok === true) {

        $variables.ExtensionBasedRolesADP.data = rolesADP.body.items;
           const filterbaseonrole= await $functions.filterExtensionBaseOnroles($variables.ExtensionBasedRolesADP.data, $application.user.roles);

        $variables.ExtensionBasedRolesADP.data = filterbaseonrole;

        const filterlifeCycleBaseOnroles = await $functions.filterlifeCycleBaseOnroles($variables.ExtensionBasedRolesADP.data);

        $variables.RoleBasedLifecyclesADP.data = filterlifeCycleBaseOnroles;
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Error occurred while fetching roles.',
          displayMode: 'transient',
        });
      }

      const getWorkers = await Actions.callRest(context, {
        endpoint: 'hcm_conn/getWorkers',
        uriParams: {
          q: "PersonNumber=" + $application.user.username,
        },
      });

      if (getWorkers.ok === true) {
        $variables.ExternalIdentifiersADP.data = getWorkers.body.items[0].externalIdentifiers;

        const externalIdentifierNumber = await $functions.getExternalIdentifierNumber($variables.ExternalIdentifiersADP.data, 'Legacy Dell NT Domain\\User');

        // ---- TODO: Add your code here ---- //
        console.log("externalIdentifierNumber-"+externalIdentifierNumber);

        $variables.MainIntegrationRequest.NT_USER_NAME = externalIdentifierNumber;
      }

    }
  }

  return vbEnterListener;
});
