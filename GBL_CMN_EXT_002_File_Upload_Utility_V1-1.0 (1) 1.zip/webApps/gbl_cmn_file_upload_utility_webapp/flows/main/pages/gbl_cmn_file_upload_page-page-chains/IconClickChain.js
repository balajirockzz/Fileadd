define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class IconClickChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $application.functions.openSpinnerDialog();

      $variables.OICLookupIntReq.RICEFID = current.row.rice_id;

      const response3 = await Actions.callRest(context, {
        endpoint: 'OIC_CONN/postIcApiIntegrationV1FlowsRestGBL_CMN_FILE_UPLOAD_INT1_0GetLookupValue',
        body: $variables.OICLookupIntReq,
      });

      const response = await Actions.callRest(context, {
        endpoint: 'OCIObjectStorage_CONN/getObjectStorageFile',
         uriParams: {
          objectName: current.row.file_name,
          namespaceName: response3.body.Namespace,
          bucketName: response3.body.Storage_Bucket,
          'ocs_path': response3.body.Error_Path,
          'rice_id': response3.body.RICEFID,
        },
        responseBodyFormat: 'blob',
      });

      if (response.ok === true) {

        await $functions.downloadFile(response.body, response.body.type, current.row.file_name);
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'The error file is not available.',
          displayMode: 'transient',
          type: 'info',
        });
      }

      await $application.functions.closeSpinnerDialog();
    }
  }

  return IconClickChain;
});
