define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ExtensionValueItemChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
     // const { $flow, $application, $constants, $variables, $functions } = context;
      $variables.UploadVar.bucketPath = key;
      $variables.OICLookupIntReq.RICEFID = key;
      $variables.BulkUpldMetadataReqPayload.RICE_ID = key;
      $variables.UploadVar.Description = data.description;
      $variables.RiceIDComm = key;

      const atp_metadata_response = await Actions.callRest(context, {
        endpoint: 'ORDS_CONN/getGBL_CMN_BULK_UPLD_METADATA_T',
        uriParams: {
          'LIFE_CYCLE': $variables.BulkUpldMetadataReqPayload.LIFE_CYCLE,
          'RICE_ID': $variables.BulkUpldMetadataReqPayload.RICE_ID,
        },
      });

      $variables.ExtensionMetadataDtlADP.data = atp_metadata_response.body.items;
    }
  }

  return ExtensionValueItemChangeChain;
});
