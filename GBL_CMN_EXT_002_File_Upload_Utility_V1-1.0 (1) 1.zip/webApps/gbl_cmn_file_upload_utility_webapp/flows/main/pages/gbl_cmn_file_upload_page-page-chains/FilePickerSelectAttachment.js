define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class FilePickerSelectAttachment extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object[]} params.files 
     */
    async run(context, { files }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      $variables.FileArrayAttachment = files;

      const fileNamesArray = await $functions.getFileNamesArray(files);

      $variables.AttachmentFIleNamesAll.data = fileNamesArray;

      await Actions.fireNotificationEvent(context, {
        summary: $variables.FileArrayAttachment.length  +" -Files has been selected.",
        type: 'confirmation',
        displayMode: 'transient',
      });
    }
  }

  return FilePickerSelectAttachment;
});
