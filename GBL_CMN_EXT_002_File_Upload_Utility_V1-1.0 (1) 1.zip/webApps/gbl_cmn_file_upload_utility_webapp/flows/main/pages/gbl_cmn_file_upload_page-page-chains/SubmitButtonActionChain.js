define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SubmitButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions, $generateTransactionNUmber, $current } = context;

      await $application.functions.openSpinnerDialog();

      const response3 = await Actions.callRest(context, {
        endpoint: 'ORDS_CONN/getNextSequence',
      });

      $variables.NextSeqNumber = response3.body.nextval;

      const TransactionNUmber = await $functions.generateTransactionNUmber($variables.UploadVar.lifecycle, $variables.NextSeqNumber);


      if ($variables.FileArrayAttachment.length !== 0) {
        const AttachmentUploadChainResult = await Actions.callChain(context, {
          chain: 'UploadAttachemntsChain',
          params: {
            TransactionNUmber: TransactionNUmber,
          },
        });

        $flow.variables.AttachmentCheckFlow = AttachmentUploadChainResult;
      }

      $variables.TransactionNumberSeq = TransactionNUmber;

      if ($variables.FileArrayAttachment.length !== 0 && $flow.variables.AttchmentUploadFlowCheck ===false) {
        await $application.functions.closeSpinnerDialog();
      } else {
         $variables.OICLookupIntReq.RICEFID = $variables.UploadVar.extension;

         const responseInt = await Actions.callRest(context, {
        endpoint: 'OIC_CONN/postIcApiIntegrationV1FlowsRestGBL_CMN_FILE_UPLOAD_INT1_0GetLookupValue',
        body: $variables.OICLookupIntReq,
      });
      
      $variables.OICUtilityLookupsResponseData = responseInt.body;

      const results = await ActionUtils.forEach($variables.FileArray, async (item, index) => {

        const response2 = await Actions.callRest(context, {
          endpoint: 'OCIObjectStorage_CONN/putNNamespaceNameBBucketNameOObjectName',
          body: $variables.FileArray[index],
          uriParams: {
            bucketName: $variables.OICUtilityLookupsResponseData.Storage_Bucket,
            namespaceName: $variables.OICUtilityLookupsResponseData.Namespace,
            'ocs_path': $variables.OICUtilityLookupsResponseData.OCS_Path,
            'rice_id': $variables.OICUtilityLookupsResponseData.RICEFID,
            objectName: $functions.generateFilename($variables.FileArray[index].name,$variables.NextSeqNumber ),
          },
        }, { id: 'uploadtoBucket' });

        if (response2.ok === true) {

          await Actions.fireNotificationEvent(context, {
            type: 'confirmation',
            displayMode: 'transient',
            message: $variables.FileArray[index].name +' has been loaded',
            summary: 'Request Number-'+ $variables.TransactionNumberSeq,
          });

          $variables.MainIntegrationRequest.LIFE_CYCLE = $variables.UploadVar.lifecycle;
          $variables.MainIntegrationRequest.EXTENSION_NAME=$variables.UploadVar.Description;
          $variables.MainIntegrationRequest.RICEF_ID=$variables.OICLookupIntReq.RICEFID;
          $variables.MainIntegrationRequest.User_Name = $application.user.username;
          $variables.MainIntegrationRequest.File_Name=await $functions.generateFilename($variables.FileArray[index].name, $variables.NextSeqNumber);
          $variables.MainIntegrationRequest.EXECUTION_MODE="IMMEDIATE";
          $variables.MainIntegrationRequest.User_Email = $application.user.email;
          $variables.MainIntegrationRequest.TRANSACTION_NUMBER = $variables.TransactionNumberSeq;

          $variables.PostFileUploadDtlDB.FILE_NAME = await $functions.generateFilename($variables.FileArray[index].name, $variables.NextSeqNumber);
          $variables.PostFileUploadDtlDB.LIFE_CYCLE = $variables.UploadVar.lifecycle;
          $variables.PostFileUploadDtlDB.RICE_ID = $variables.OICLookupIntReq.RICEFID;
          $variables.PostFileUploadDtlDB.RICEF_DESC = $variables.UploadVar.Description;
          $variables.PostFileUploadDtlDB.STATUS = 'New';
          $variables.PostFileUploadDtlDB.TRANSACTION_NUMBER = $variables.TransactionNumberSeq;
          $variables.PostFileUploadDtlDB.CREATED_BY = $application.user.username;
          $variables.PostFileUploadDtlDB.P_TABLE_NAME = $variables.ExtensionMetadataDtlADP.data[0].interface_table;
          $variables.PostFileUploadDtlDB.CREATION_DATE = $functions.getCurrentDateTime(); 
          $variables.PostFileUploadDtlDB.UCM_ATTACHMENT_IDS = $variables.TempAttachmentUCMIDS;
          const atpPostResult = await Actions.callRest(context, {
            endpoint: 'ORDS_CONN/postTransactiondtltoATP',
            body: $variables.PostFileUploadDtlDB,
          });
        }
        
        
         if(response2.ok !== true) {
          await Actions.fireNotificationEvent(context, {
            summary: 'An error occurred while uploading the file.',
            displayMode: 'transient',
          });

          $variables.ValidateIntegrationtoSubmit = false;
        }
      }, { mode: 'serial' });

      const generateFileNamesforOIC = await $functions.generateFileNamesforOIC($variables.FileArray, $variables.NextSeqNumber);

      $variables.MainIntegrationRequest.File_Name = generateFileNamesforOIC;

      if ($variables.ValidateIntegrationtoSubmit === true) {
        const response = await Actions.callRest(context, {
          endpoint: 'OIC_CONN/GBL_CMN_EXT_002_BULK_UTIL_WRAP',
          body: $variables.MainIntegrationRequest,
        });

          $variables.MainIntegrationRsponse = response.body;

        if ( $variables.MainIntegrationRsponse.Response === 'E') {
          await Actions.fireNotificationEvent(context, {
            summary: 'An error occurred while calling the integration.',
            displayMode: 'transient',
          });
        }
      }

      }


      
      await $application.functions.closeSpinnerDialog();


    }
  }

  return SubmitButtonActionChain;
});
