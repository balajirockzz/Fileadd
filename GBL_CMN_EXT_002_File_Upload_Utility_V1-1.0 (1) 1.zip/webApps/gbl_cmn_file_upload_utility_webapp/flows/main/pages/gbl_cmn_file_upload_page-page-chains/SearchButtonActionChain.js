define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SearchButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $application.functions.openSpinnerDialog();

      await Actions.fireDataProviderEvent(context, {
        target: $variables.getBulkUploadTableDataListSDP,
        refresh: null,
      });

      await $application.functions.closeSpinnerDialog();
    }
  }

  return SearchButtonActionChain;
});
