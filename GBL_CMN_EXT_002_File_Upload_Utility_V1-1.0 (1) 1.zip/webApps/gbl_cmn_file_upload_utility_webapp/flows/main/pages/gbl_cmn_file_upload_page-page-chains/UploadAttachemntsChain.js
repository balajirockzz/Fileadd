define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class UploadAttachemntsChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.TransactionNUmber 
     * @return {boolean} 
     */
    async run(context, { TransactionNUmber }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const convertFilesToBase64 = await $functions.convertFilesToBase64($variables.FileArrayAttachment, $variables.UploadVar.extension);

      $variables.BASE64FileArray = convertFilesToBase64;

      $flow.variables.AttchmentUploadFlowCheck = true;

      const results = await ActionUtils.forEach($variables.BASE64FileArray, async (item, index) => {

      

        const response = await Actions.callRest(context, {
          endpoint: 'fscm_conn/UploadFIleToUCMServer',
          body: $variables.BASE64FileArray[index],
        });
        if (response.ok === true) {
        //  $variables.AttachmentsPostRequest.DocumentId = response.body.DocumentId;
          $variables.AttachmentsPostRequest.FILE_NAME= $variables.BASE64FileArray[index].FileName;
          $variables.AttachmentsPostRequest.STATUS="New";
          $variables.AttachmentsPostRequest.RICE_ID= $variables.UploadVar.extension;
          $variables.AttachmentsPostRequest.TRANSACTION_NUMBER=TransactionNUmber;
          $variables.AttachmentsPostRequest.UCM_ID=response.body.DocumentId;

          const response2 = await Actions.callRest(context, {
            endpoint: 'ORDS_CONN/POSTATTACHMNETTODB',
            body: $variables.AttachmentsPostRequest,
          });

          $variables.TempAttachmentUCMIDS = $variables.TempAttachmentUCMIDS ?$variables.TempAttachmentUCMIDS +',' +response.body.DocumentId : response.body.DocumentId;
        } else {
          await Actions.fireNotificationEvent(context, {
            summary: "Errored occurred while uploading file to UCM-" +$variables.BASE64FileArray[index].filename,
            displayMode: 'transient',
            type: 'error',
          });

          $flow.variables.AttchmentUploadFlowCheck = false;

          return false;
        }
      }, { mode: 'parallel' });

      if ($flow.variables.AttchmentUploadFlowCheck === true) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Attachments has been uploaded successfully.',
          type: 'confirmation',
          displayMode: 'transient',
        });

        // ---- TODO: Add your code here ---- //
        console.log("UCM-" +$variables.TempAttachmentUCMIDS);

        return true;
      }
    }
  }

  return UploadAttachemntsChain;
});


   