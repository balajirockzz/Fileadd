define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ClearButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.PostFileUploadDtlDB',
    '$page.variables.UploadVar',
    '$page.variables.OICLookupIntReq',
    '$page.variables.TempLifecycle',
    '$page.variables.BulkUpldMetadataReqPayload',
    '$page.variables.FileArray',
    '$page.variables.FIleNameConcaAll',
    '$flow.variables.AttchmentUploadFlowCheck',
    '$page.variables.BASE64FileArray',
    '$page.variables.FileArrayAttachment',
    '$page.variables.HasAttachment',
    '$page.variables.TempAttachmentUCMIDS',
    '$page.variables.AttachmentFIleNamesAll',
  ],
      });
    }
  }

  return ClearButtonActionChain;
});
