define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class FilePickerSelectChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object[]} params.files 
     */
    async run(context, { files }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $application.functions.openSpinnerDialog();

      const fileNames = await $functions.getFileNames(files);

      $variables.UploadVar.fileName = files[0].name;
      $variables.UploadVar.fileContent = files[0];
      $variables.FIleNameConcaAll = fileNames;

      $variables.FileArray = files;

      const validateFile = await $functions.validateFile(files, $variables.ExtensionMetadataDtlADP.data[0]);

      if (validateFile === true) {
        $variables.FileValidationCheck = true;

        await Actions.fireNotificationEvent(context, {
          summary: 'The file has been validated successfully.',
          type: 'confirmation',
          displayMode: 'transient',
        });
      } else {

        $variables.FileValidationCheck = false;
        $variables.FileValiErrorMessagesADP.data = validateFile;

        const errorDailogOpen = await Actions.callComponentMethod(context, {
          selector: '#errorDailog',
          method: 'open',
        });
      }
const fileName = files[0].name.toLowerCase();
if (fileName.endsWith('.xlsx') || fileName.endsWith('.csv') || fileName.endsWith('.xls')) {
  const convertXlsxToCSV = await $functions.convertXlsxToCSV(files);
  $variables.FileArray = convertXlsxToCSV;
  console.log('convertion happened to csv');
} else {
  $variables.FileArray = files;
}


      await $application.functions.closeSpinnerDialog();
    }
  }

  return FilePickerSelectChain;
});
