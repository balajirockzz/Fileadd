define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TemplateButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      $variables.OICLookupIntReq.RICEFID = $variables.RiceIDComm;

      const response = await Actions.callRest(context, {
        endpoint: 'OIC_CONN/postIcApiIntegrationV1FlowsRestGBL_CMN_FILE_UPLOAD_INT1_0GetLookupValue',
        body: $variables.OICLookupIntReq,
      });

      if (response.ok === true) {

        const response2 = await Actions.callRest(context, {
          endpoint: 'OCIObjectStorage_CONN/getTemplate',
          uriParams: {
            'backet_name': response.body.Storage_Bucket,
            namespce: response.body.Namespace,
            path: response.body.Template_Path,
            'rice_id': response.body.RICEFID,
            'template_name': response.body.Template_Name,
          },
          responseType: 'any',
          responseBodyFormat: 'blob',
        });
          if (response2.ok === true) {
            await $functions.downloadFile(response2.body, response2.body.type, response.body.Template_Name);
          } else {
            await Actions.fireNotificationEvent(context, {
              summary: 'The template is not available to download.',
              type: 'info',
              displayMode: 'transient',
            });
          }
      }

    }
  }

  return TemplateButtonActionChain;
});
