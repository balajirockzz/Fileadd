define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ResetButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.searchParam_Var.startDate',
    '$page.variables.searchParam_Var.status',
    '$page.variables.searchParam_Var.toDate',
    '$page.variables.searchParam_Var.transactionID',
  
    '$page.variables.TempTransactionNum',
  ],
      });

      $variables.seachReportTable_ADP.data = $variables.seachReportTable_MASTER_ADP.data;

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.seachReportTable_ADP,
      });
    }
  }

  return ResetButtonActionChain;
});
