define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableFirstSelectedRowChangeChain1 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.rowKey 
     * @param {any} params.rowData 
     */
    async run(context, { rowKey, rowData }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // ---- TODO: Add your code here ---- //
      console.log("Test-")

      await Actions.callChain(context, {
        chain: 'ExtensionValueItemChangeChain',
        params: {
          data: rowData,
          key: rowKey,
        },
      });
    }
  }

  return TableFirstSelectedRowChangeChain1;
});
