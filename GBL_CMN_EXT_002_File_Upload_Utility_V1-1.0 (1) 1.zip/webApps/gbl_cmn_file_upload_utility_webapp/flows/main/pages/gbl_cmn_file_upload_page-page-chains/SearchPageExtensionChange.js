define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SearchPageExtensionChange extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      

      if ($variables.searchParam_Var.searchExtDescri !== undefined) {
      

          await $application.functions.openSpinnerDialog();

        $variables.searchParam_Var.seachExtension = data.rice_id;

        const response2 = await Actions.callRest(context, {
          endpoint: 'ORDS_CONN/getGBL_CMN_BULK_UPLD_METADATA_T',
          uriParams: {
            'RICE_ID': $variables.searchParam_Var.seachExtension,
            'LIFE_CYCLE': $variables.searchParam_Var.searchLifeCycle,
          },
        });

        $variables.searchParam_Var.tableName = response2.body.items[0].interface_table;

        await $application.functions.closeSpinnerDialog();

        $variables.CollpaseCheck = true;
      }
    }
  }

  return SearchPageExtensionChange;
});
