define(['xlsx'], (XLSX)  => {
  'use strict';

  class PageModule {

    /**
     * JS filter for filterning the Meaning and description
     * @param {String} arg1
     * @return {String}
     */
    filterMeaning(data, varTag){
       console.log("varTag");
            console.log(varTag);
    return data.filter(item => item.Tag === varTag).map(item => ({ Meaning: item.Meaning,Description: item.Description}));
}
/**
     *
     * @param {String} arg1
     * @return {String}
     */
    getDescription(data, varTag){
      console.log("varTag2");
            console.log(varTag);
    for (let i = 0; i < data.length; i++) {
        if (data[i].rice_id === varTag) {
            return data[i].description;
        }
    }
    return null; // Return null if no match is found
}
   
       /**
     *
     * @param {String} externalIdentifierNumber_ADP
     * @return {String}Type ExternalIdentifierType
     */
    getExternalIdentifierNumber(externalIdentifierNumber_ADP, externalIdentifierTypeSeach){

     
     for (let i = 0; i < externalIdentifierNumber_ADP.length; i++) 
     { if (externalIdentifierNumber_ADP[i].ExternalIdentifierType === externalIdentifierTypeSeach) 
         {  
          return externalIdentifierNumber_ADP[i].ExternalIdentifierNumber; 
        }    
       
     }
     return null;
}
/**
     *
     * @param {String} arg1
     * @return {String}
     */
generateFilename(filename, userName) {
    // Extract the base name and extension from the filename
    const [baseName, extension] = filename.split('.');

    // Concatenate the base name, user name, and extension
    const newFilename = `${baseName}_${userName}.${extension}`;
    console.log("newFilename-" +newFilename);
    return newFilename;
}

/**
     *JS function for generating the request/transaction number
     * @param {String} ext
     * @return {String} eeq
     */
generateTransactionNUmber(lifecyle, seq) {
    // Extract the base name and extension from the filename
   
     const transactionname = `${lifecyle}_${seq}`;
     console.log("TransactionNumber-" +transactionname);
    return transactionname;
}

    /**
     * JS fun for concatenating the uploaded filesname
     * @param {String} arg1
     * @return {String}
     */
getFileNames(files) {
    return files.map(file => file.name).join(', ');
}



getFileNamesArray(files) {
   return files.map(file => ({ FileName: file.name }));
}

    /**
     * This function return file names for oic param
     * @param {String} arg1
     * @return {String}
     */


 generateFileNamesforOIC(files, transaction_number) {
    return files.map(file => {
  const baseName = file.name.split('.').slice(0, -1).join('.');
  if (file.name.toLowerCase().endsWith('.zip')) {
    return `${baseName}_${transaction_number}.zip`;
  } else {
    return `${baseName}_${transaction_number}.csv`;
  }
}).join(',');
}

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
//     filterLifecycle(data) {
//     const uniqueTags = new Set();
//     const result = [];

//     data.forEach(item => {
//         if (item.Tag !== null && !uniqueTags.has(item.Tag)) {
//             uniqueTags.add(item.Tag);
//             result.push({ Tag: item.Tag });
//             console.log("result-");
//             console.log(result);
//         }
//     });

//     return result;
// }

  
 filterLifecycle(data, validateArray) {

    console.log("Tag-" +data[0].Tag);
    console.log("validateArray-" +validateArray[0]);
    
  const filteredArray = data.filter(item => validateArray.includes(item.Tag));
  
  
   // Remove duplicates based on the 'Tag' property
  const uniqueTags = new Set();
  const uniqueArray = filteredArray.filter(item => {
    if (!uniqueTags.has(item.Tag)) {
      uniqueTags.add(item.Tag);
      return true;
    }
    return false;
  });
  
  return uniqueArray;
}



    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    filterExtension(data) {
    const uniqueExt = new Set();
    const resultExt = [];

    data.forEach(item => {
        if (item.Meaning !== null && !uniqueExt.has(item.Meaning)) {
            uniqueExt.add(item.Meaning);
            resultExt.push({ Meaning: item.Meaning });
        }
    });

    return resultExt;
}

//new filter based on roles

filterExtensionBaseOnroles(data, validateArray) {

    console.log("erp_shell_role-" +data[0].erp_shell_role);
    console.log("validateArray-" +validateArray[0]);
    
  const filteredArray = data.filter(item => validateArray.includes(item.erp_shell_role));
  return filteredArray;
}

 filterlifeCycleBaseOnroles(data) {

   // Remove duplicates based on the 'Tag' property
   console.log("life_cycle-" +data[0].life_cycle);
  const uniqueTags = new Set();
  const uniqueArray = data.filter(item => {
    if (!uniqueTags.has(item.life_cycle)) {
      uniqueTags.add(item.life_cycle);
      return true;
    }
    return false;
  });
  
  return uniqueArray;
}


 filterArray(masterArray, validateArray) {
  return masterArray.filter(item => validateArray.includes(item.tag));
}



    /**
     *Validation of the file uploaded based on metadata infomation
     * @param {String} files
     * @param {String} obj
     * @return {String}
     */
async validateFile(files, validateObj) {
    console.log("Validation_start-");
    console.log("validateObj-" + validateObj.file_name_convention);
    let errors = [];

    // Check if files is an array
    if (!Array.isArray(files)) {
        return { status: 'error', message: 'Files should be an array' };
    }

    // Check if the number of files meets the mandatory requirement-- validateObj.no_of_header_cols != null &&
    if ( validateObj.no_of_mandatory_file !== null && files.length !== validateObj.no_of_mandatory_file) {
        console.log("actual-"+ typeof files.length);
        console.log("Allowed-"+ typeof validateObj.no_of_mandatory_file);
        errors.push({ Error: `The number of files should match the allowed number- ${validateObj.no_of_mandatory_file}` });
    }

    // Iterate through each file and validate
    for (let file of files) {
        // Check file extension
        if (validateObj.file_extn_type !== null && !file.name.endsWith(validateObj.file_extn_type)) {
            errors.push({ Error: `File ${file.name} does not have the correct extension ${validateObj.file_extn_type}` });
        }
        // Check file name convention
        if (validateObj.file_name_convention !== null && !file.name.includes(validateObj.file_name_convention)) {
            errors.push({ Error: `File ${file.name} does not contain the required name convention ${validateObj.file_name_convention}` });
        }
        
        // Additional validation for zip files
            if (file.name.toLowerCase().endsWith('.zip') || file.type === 'application/x-zip-compressed') {
      console.log(`Skipping validation for ZIP file: ${file.name}`);
      return true; // ✅ Bypass validation rules for ZIP
    }

        // Additional validation for Excel files
        if (validateObj.no_of_file_rows !== null && (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel')) {
            let numberOfRows = await getNumberOfRowsInExcel(file);
            console.log("FILEROWCOUNT",+numberOfRows);
            if (numberOfRows > validateObj.no_of_file_rows) {
                
                errors.push({ Error: `File ${file.name} should not exceed the allowed file records limit - ${validateObj.no_of_file_rows}` });
            }
              if (numberOfRows < 1) {
                console.log("FILEROWCOUNT1",+numberOfRows)
                errors.push({ Error: `File ${file.name} should not be empty.` });
            }
        }
         if (validateObj.no_of_file_rows !== null && file.type === 'text/csv') {
            let numberOfRows = await countCSVRows(file);
            if (numberOfRows  > validateObj.no_of_file_rows  ) {
                
                errors.push({ Error: `File ${file.name} should not exceed the allowed file records limit  - ${validateObj.no_of_file_rows}` });
            }
        }
         let numberOfclmn = await getFilesHeaderCount(file);
         if (validateObj.no_of_header_cols !== null && numberOfclmn > validateObj.no_of_header_cols) { 
               
                 errors.push({ Error: `File ${file.name} should not exceed the allowed header columns limit  - ${validateObj.no_of_header_cols}` });
            }
        }
    

    async function getNumberOfRowsInExcel(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsArrayBuffer(file);
        reader.onload = function(event) {
            const data = new Uint8Array(event.target.result);
            const workbook = XLSX.read(data, { type: 'array' });
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const range = XLSX.utils.decode_range(worksheet['!ref']);
            let rowCount = 0;

            for (let row = range.s.r; row <= range.e.r; row++) {
                let hasValue = false;
                for (let col = range.s.c; col <= range.e.c; col++) {
                    const cellAddress = XLSX.utils.encode_cell({ r: row, c: col });
                    const cell = worksheet[cellAddress];
                    if (cell && cell.v !== undefined && cell.v !== null && cell.v !== '') {
                        hasValue = true;
                        break;
                    }
                }
                if (hasValue) {
                    rowCount++;
                }
            }
            console.log("rowCount-", +rowCount);
            resolve(rowCount-1);
        };
        reader.onerror = function(error) {
            reject(error);
        };
    });
}

    function countCSVRows(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsText(file);
            reader.onload = function(event) {
                const text = event.target.result;
                const rows = text.split('\n');
                const rowCount = rows.length - 1; // Subtract 1 to exclude the header row
                resolve(rowCount-1);
            };
            reader.onerror = function(error) {
                reject(error);
            };
        });
    }

   function  getFilesHeaderCount(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = function(event) {
            try {
                const data = new Uint8Array(event.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                const firstSheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[firstSheetName];
                const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

                if (jsonData.length > 0) {
                    const columnCount = jsonData[0].length;
                    resolve(columnCount);
                } else {
                    reject('The file is empty or does not contain a valid header.');
                }
            } catch (error) {
                reject(`Error reading the file: ${error.message}`);
            }
        };
        reader.readAsArrayBuffer(file);
    });
}

    console.log("Validation_end");
    console.log("Validation_errors_two" + errors);

    // Return success if no errors, otherwise return error details
    if (errors.length === 0) {
        console.log("True-length" + errors.length);
        return true;
    } else {
        console.log("false-length" + errors.length);
        const Error = errors.map((error, index) => `${index + 1}- ${error.Error}`).join('\n');
        console.log("Error" + Error);
        return errors;
    }
}



    /**
     * Function  date
     */
getCurrentDateTime() {
   const now = new Date();
    
    const padZero = (num) => (num < 10 ? '0' + num : num);

    const year = now.getFullYear();
    const month = padZero(now.getMonth() + 1); // Months are zero-based
    const day = padZero(now.getDate());
    
    const hours = padZero(now.getHours());
    const minutes = padZero(now.getMinutes());
    const seconds = padZero(now.getSeconds());

    const formattedDate = `${year}/${month}/${day}`;
    const formattedTime = `${hours}:${minutes}:${seconds}`;

    return `${formattedDate}`;

    
}

    /**
     * Function for disableing the past date
     */
disablePastDate() {
    let today = new Date();
    today.setDate(today.getDate() - 90);
    return today;
}

getUniqueTransactions(masterADP) {
     const uniqueTransactions = {};
    
    masterADP.forEach(item => {
        uniqueTransactions[item.transaction_number] = item;
    });

    return Object.values(uniqueTransactions);

}
   /**
     *
     * @param {String} files
     * @param {String} obj
     * @return {String}
     */

getXlsxHeaderLength(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = function(event) {
            try {
                const data = new Uint8Array(event.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                const firstSheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[firstSheetName];
                const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

                if (jsonData.length > 0) {
                    const columnCount = jsonData[0].length;
                    resolve(columnCount);
                } else {
                    reject('The file is empty or does not contain a valid header.');
                }
            } catch (error) {
                reject(`Error reading the file: ${error.message}`);
            }
        };
        reader.readAsArrayBuffer(file);
    });
}

   /**
     * 
     * @param {String} files
     * @param {String} obj
     * @return {String}
     */

searchResult(data, life_cycle, rice_id, transaction_number, fromDate, toDate,status) {
  console.log("Search-"+data[0].creation_date);
  console.log("life_cycle-"+life_cycle);
  console.log("rice_id-"+rice_id);
  console.log("transaction_number-"+transaction_number);
  console.log("fromDate-"+fromDate);
  console.log("toDate-"+toDate);
 return data.filter(item => {
        return (!life_cycle || item.life_cycle === life_cycle) &&
               (!rice_id || item.rice_id === rice_id) &&
               (!status || item.status === status) &&
               (!transaction_number || item.transaction_number === transaction_number) &&
               (!fromDate || new Date(item.creation_date) >= new Date(fromDate)) &&
               (!toDate || new Date(item.creation_date) <= new Date(toDate));
    });
}

searchonInitialData(data, life_cycle, rice_id, ) {
  console.log("Search-"+data[0].creation_date);
  console.log("life_cycle-"+life_cycle);
  console.log("rice_id-"+rice_id);

 return data.filter(item => {
        return (!life_cycle || item.life_cycle === life_cycle) &&
               (!rice_id || item.rice_id === rice_id);
    });
}


  /* Function for converting file to csv old
     */

convertXlsxToCsvOld(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                
                // Get the first worksheet
                const sheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[sheetName];
                
                // Convert the worksheet to CSV
                const csv = XLSX.utils.sheet_to_csv(worksheet);
                
                resolve(csv);
            };
            
            reader.onerror = function(error) {
                reject(error);
            };
            
            reader.readAsArrayBuffer(file);
        });
    }



  /* Function for dowonloading objectstorage file to system
     */

downloadFile (data, mimeType, filename) {

const blob = data;
// IE/Edge

if (window.navigator && window.navigator.msSaveOrOpenBlob) {

window.navigator.msSaveOrOpenBlob(blob);

return;

}

var link = document.createElement('a');

link.href = URL.createObjectURL(blob);

link.download = filename;

link.click();

// Firefox: delay revoking the ObjectURL

setTimeout(function() {

URL.revokeObjectURL(blob);

}, 1000);

}


  /* Function for downloading objectstorage file 
     */

downloadFileJS(content, fileName) {
  const blob = new Blob([content], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}




  /* Function for converting file to csv new
     */
convertXlsxFilesToCsvMutilple(importFiles) {
    const csvFiles = [];

    importFiles.forEach(file => {
        // Read the Excel file
        const workbook = XLSX.read(file, { type: 'buffer' });

        // Convert each sheet to CSV
        workbook.SheetNames.forEach(sheetName => {
            const worksheet = workbook.Sheets[sheetName];
            const csv = XLSX.utils.sheet_to_csv(worksheet);
            csvFiles.push({ fileName: file.name, sheetName, csv });
        });
    });

    return csvFiles;
}


  /**
     *js function to convert xlxs file to csv
     * @param {String} file

  */


convertXlsxToCSV(fileArray) {
    return new Promise((resolve, reject) => {
        const updatedFileArray = [];
        const promises = fileArray.map(file => {
            return new Promise((fileResolve, fileReject) => {
                if (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel') {
                    const reader = new FileReader();
                    reader.onload = function(event) {
                        const data = event.target.result;
                        const workbook = XLSX.read(data, { type: 'binary' });

                        // Convert the first sheet to CSV
                        const sheetName = workbook.SheetNames[0];
                        const worksheet = workbook.Sheets[sheetName];
                        let csv = XLSX.utils.sheet_to_csv(worksheet, { FS: ',', RS: '\n', blankrows: false });

                        // Preserve original date values in the CSV
                        csv = csv.replace(/(\d{2})-(\d{2})-(\d{4})(?=\D|$)/g, (match, p1, p2, p3) => {
                            return `${p1}-${p2}-${p3}`;
                        }).replace(/(\d{2})\/(\d{2})\/(\d{4})(?=\D|$)/g, (match, p1, p2, p3) => {
                            return `${p1}/${p2}/${p3}`;
                        });
                        csv = csv.replace(
                            /\b(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2})(?=\D|$)/g,
                            (match, p1, p2, p3) => {
                                let year = parseInt(p3, 10);
                                year += (year < 50) ? 2000 : 1900; // adjust as needed
                                return `${p1}/${p2}/${year}`;
                            }
                        );

                        // Create a new file name with a .csv extension
                        const originalFileName = file.name;
                        const name = originalFileName.replace(/\.xlsx$/, '.csv');

                        // Create a Blob with the CSV data
                        const csvBlob = new Blob([csv], { type: 'text/csv' });

                        // Create a File object with the new file name
                        const csvFile = new File([csvBlob], name, { type: 'text/csv' });

                        // Add the new CSV file to the updated file array
                        updatedFileArray.push(csvFile);
                        fileResolve();
                    };
                    reader.onerror = function(error) {
                        fileReject(error);
                    };
                    reader.readAsBinaryString(file);
                } else {
                    // If the file is not an Excel file, add it to the updated file array as is
                    updatedFileArray.push(file);
                    fileResolve();
                }
            });
        });

        Promise.all(promises)
            .then(() => resolve(updatedFileArray))
            .catch(error => reject(error));
    });
}





  /* JS Function for converting the files to base64 format 
     */

async convertFilesToBase64(files,extensionID) {
    const fileDataArray = [];
    let tempDocumentAccount;
    if(extensionID==="STP_PROC_EXT_020_BPO_CREATE" || extensionID==="STP_PROC_EXT_020_BPO_UPDATE" )
    {
       tempDocumentAccount="prc/blanketPurchaseAgreement/import";
    }
    else{
      tempDocumentAccount="prc/purchaseOrder/import";
    }

    for (const file of files) {
        const base64String = await new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result.split(',')[1]);
            reader.onerror = error => reject(error);
        });
       
        fileDataArray.push({
        ContentType: file.type,
        DocumentAccount: tempDocumentAccount,
        DocumentContent: base64String,
        FileName: file.name,
        OperationName: "uploadFileToUCM"
        });
    }
   console.log("Attachments-", fileDataArray);
    return fileDataArray;
}


  

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    getAttachmentsUCMIDS(array) {
    console.log("responseADP", +toString(array));
    console.log("UCMIDS-", +(item => item[0]).join(','));
    return array.map(item => item[0]).join(',');
    }




  }
  return PageModule;
});
