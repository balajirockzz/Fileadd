/* Copyright (c) 2024, Oracle and/or its affiliates */

define(['oj-sp/spectra-shell/config/config'], function(config) {
  'use strict';

  class AppModule {
  }

      // OPEN LOADING SYMBOL
    AppModule.prototype.openSpinnerDialog = function () {
      document.getElementById("loading").style.display = "block";
    };

    // CLOSE LOADING SYMBOL
    AppModule.prototype.closeSpinnerDialog = function () {
      document.getElementById("loading").style.display = "none";
    };


    

  return AppModule;
});
