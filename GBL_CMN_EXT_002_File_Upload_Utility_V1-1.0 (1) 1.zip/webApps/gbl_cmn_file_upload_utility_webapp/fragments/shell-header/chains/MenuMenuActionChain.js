define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class MenuMenuActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.menuId 
     */
    async run(context, { menuId }) {
      const { $fragment, $application, $constants, $variables } = context;

      if (menuId === 'Sign Out') {
        await Actions.openUrl(context, {
          url: 'https://idcs-09b68ff6f5a84782934af375c162ed01.identity.oraclecloud.com/oauth2/v1/userlogout',
        });
      }
    }
  }

  return MenuMenuActionChain;
});
