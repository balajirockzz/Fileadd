define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class searchActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await $application.functions.openSpinnerDialog();

      $page.variables.filterObject = $flow.variables.searchFilter;

      let filterdate='';
      if($flow.variables.searchFilter.fromDate  &&  $flow.variables.searchFilter.toDate){
        filterdate = 'CreationDate  >='+  "'"+$flow.variables.searchFilter.fromDate+"'" +'and CreationDate <=' +"'"+$flow.variables.searchFilter.toDate+"'";

      }
      else{
        filterdate='';
      }

      let sText ='';
  

      if($variables.filterObject.text){
          sText = 'LIKE' + "'%"+$variables.filterObject.text.toUpperCase()+"%'";

        const inClause2 = await $application.functions.getInClause($application.variables.POPageDocumentStyleADP.data, 'display_name');

        // ---- TODO: Add your code here ---- //
        console.log('newlogsettingsssss'+inClause2);

        
        $page.variables.qParameterForBPO = 'DocumentStyle in '+$application.functions.getInClause($application.variables.POPageDocumentStyleADP.data, 'display_name');
        // $page.variables.qParameterForBPO ='';
      }
      else{
        sText = 'LIKE' +"'%%'";

        $variables.qParameterForBPO = 'BuyerDisplayName=' +"'"+ $application.user.fullName+"'"+'';

      }
 
      if($flow.variables.searchFilter.request_id){

        $page.variables.qParameterForBPO = '';
        if($flow.variables.searchFilter.status){
          if($flow.variables.searchFilter.buyer){
                      $page.variables.qParameterForBPO = 'OrderNumber=' +"'"+ $flow.variables.searchFilter.request_id+"'" +' and StatusCode='+"'"+$flow.variables.searchFilter.status+"'" + ' and BuyerId='+"'"+$flow.variables.searchFilter.buyer +"'"+filterdate;
            
          }
          else {
                      $page.variables.qParameterForBPO = 'OrderNumber=' +"'"+ $flow.variables.searchFilter.request_id+"'" +' and StatusCode='+"'"+$flow.variables.searchFilter.status+"'"+filterdate ;

          }

        }
        else{
                                $page.variables.qParameterForBPO= 'OrderNumber=' +"'"+ $flow.variables.searchFilter.request_id+"'"+filterdate ;

        }
      
      
      
      
    
      }
      else if ($flow.variables.searchFilter.status){

        $page.variables.qParameterForBPO = '';
          if($flow.variables.searchFilter.buyer){
                              $page.variables.qParameterForBPO = 'StatusCode='+"'"+$flow.variables.searchFilter.status+"'" + ' and BuyerId='+"'"+$flow.variables.searchFilter.buyer +"'"+filterdate;
          }
          else {
                              $page.variables.qParameterForBPO ='StatusCode='+"'"+$flow.variables.searchFilter.status+"'"+filterdate;

      }
        
      }
      else if ($flow.variables.searchFilter.buyer){

        $page.variables.qParameterForBPO = '';
                                      $page.variables.qParameterForBPO = 'BuyerId='+"'"+$flow.variables.searchFilter.buyer +"'"+filterdate;

      }
      else if ( $flow.variables.searchFilter.fromDate && $flow.variables.searchFilter.toDate){

        $page.variables.qParameterForBPO = '';
                               $page.variables.qParameterForBPO = filterdate;


      }
      else{

  

    
      
      }

       $flow.variables.showFilter = false;

            let inClause = 'SupplierSiteId in ' +
       $application.functions.getInClause( $application.functions.getADPData($application.variables.buyerAssoc.ASSOCIATIONS,'SUPPLIER_SITE_ID'),'SUPPLIER_SITE_ID') + ' and '
      
      // $page.variables.qParameterForBPO = (inClause)+ ($page.variables.qParameterForBPO ? $page.variables.qParameterForBPO  +" and ":'')  +' ((UPPER(Buyer)'+sText+ ') or (UPPER(ProcurementBU)' +sText+') or (UPPER(OrderNumber) '+sText+') or (UPPER(Status)'+sText+ ') or (UPPER(Supplier)'+sText+'))';
$page.variables.qParameterForBPO = (inClause)+ ($page.variables.qParameterForBPO ? $page.variables.qParameterForBPO  +" and ":'')  +' ((UPPER(Buyer)'+sText+ ') or (UPPER(ProcurementBU)' +sText+') or (UPPER(OrderNumber) '+sText+') or (UPPER(Status)'+sText+ '))';

      
     

      await $application.functions.closeSpinnerDialog();
    }
  }

  

  return searchActionChain;
});
