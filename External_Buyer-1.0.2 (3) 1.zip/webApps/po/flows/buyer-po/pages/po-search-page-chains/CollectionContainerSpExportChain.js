define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class CollectionContainerSpExportChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

 if (!$flow.variables.searchFilter.request_id && !$flow.variables.searchFilter.buyer && !$flow.variables.searchFilter.status && (!$flow.variables.searchFilter.toDate && !$flow.variables.searchFilter.fromDate)) {

        await Actions.fireNotificationEvent(context, {
          summary: 'Select Any of the Values in the Advance Filter to Export the Purchase Order Data',
          displayMode: 'persist',
          type: 'warning',
        });
        
      }
        else{
        await $functions.downloadExcel();



        }    }
  }

  return CollectionContainerSpExportChain;
});
