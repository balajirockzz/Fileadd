define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navPoDetails extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.row 
     */
    async run(context, { row }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$flow.variables.transReqDetails',
  ],
      });

      $flow.variables.transReqDetails.BuyerId= $application.user.fullName;

      const toBugetTranferDetails = await Actions.navigateToPage(context, {
        page: 'po-details',
        params: {
          headerId: row && row.POHeaderId  ? row.POHeaderId :'',
        },
      });
    }
  }

  return navPoDetails;
});
