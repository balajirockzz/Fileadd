define([], () => {
  'use strict';

  class PageModule {

    generateBIPReportREqPayload(po_number) {
      let payload = `<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:pub="http://xmlns.oracle.com/oxp/service/PublicReportService">
   <soap:Header/>
   <soap:Body>
      <pub:runReport>
         <pub:reportRequest>
            <pub:attributeFormat>csv</pub:attributeFormat>
            <pub:parameterNameValues>
               <pub:item>
                  <pub:name>p_po_number</pub:name>
                  <pub:values>
                     <pub:item>`+ po_number + `</pub:item>
                  </pub:values>
               </pub:item>
            </pub:parameterNameValues>
            <pub:reportAbsolutePath>/Custom/Extension/STP/STP_PROC_EXT_005_External_Buyer_PO_ActionHistory_Report.xdo</pub:reportAbsolutePath>
            <pub:sizeOfDataChunkDownload>-1</pub:sizeOfDataChunkDownload>
         </pub:reportRequest>
      </pub:runReport>
   </soap:Body>
</soap:Envelope>`;

      return payload;

    }
 /**
     *
     * @param {String} externalIdentifierNumber_ADP
     * @return {String}Type ExternalIdentifierType
     */
    getExternalIdentifierNumber(externalIdentifierNumber_ADP, externalIdentifierTypeSeach){

     
     for (let i = 0; i < externalIdentifierNumber_ADP.length; i++) 
     { if (externalIdentifierNumber_ADP[i].ExternalIdentifierType === externalIdentifierTypeSeach) 
         {  
          return externalIdentifierNumber_ADP[i].ExternalIdentifierNumber; 
        }    
       
     }
     return null;
}



  }



  PageModule.prototype.isTotalAmountUnderLimit = function (data, limit = 25000,attachment) {
  // Sum all the Amount values from the array
  if(attachment)
  {
    return true;
  }
  else{
  const totalAmount = data.reduce((sum, item) => sum + (item.Price * item.Quantity) , 0);
  // Return true if total is less than the limit
  return totalAmount < limit;
  }
}

PageModule.prototype.manualPriceCheckfunc = function (data, attachment) {
 
  if (attachment) {
    return true;
  }

  for (let i = 0; i < data.length; i++) {
    const line = data[i]; 
    if (line.DFF && Array.isArray(line.DFF.items)) {
      for (let j = 0; j < line.DFF.items.length; j++) {
        const item = line.DFF.items[j];
        if (item.priceType === 'MN') {
          return false;
        }
      }
    }
  }

  return true;
}



  PageModule.prototype.allHaveSameSourceAgreementNumber = function (data) {
  if (!data.length) return false;

  const allHaveNumber = data.every(item => item.SourceAgreementNumber);
  const noneHaveNumber = data.every(item => !item.SourceAgreementNumber);

  if (allHaveNumber) {
    const firstNumber = data[0].SourceAgreementNumber;
    return data.every(item => item.SourceAgreementNumber === firstNumber);
  }

  return noneHaveNumber;
}


PageModule.prototype.extractEXTIdentifierNumber = function (dataArray) {
  if (!Array.isArray(dataArray)) return [];

  return dataArray
    .map(item => {
      try {
        const extId = typeof item.getEXT_IDENTIFIER_NUMBER === 'function'
          ? item.getEXT_IDENTIFIER_NUMBER()
          : item.EXT_IDENTIFIER_NUMBER;
        
        return extId != null ? { EXT_IDENTIFIER_NUMBER: extId } : null;
      } catch (e) {
        return null;
      }
    })
    .filter(obj => obj !== null);
};



// PageModule.prototype.selec=function (dataArray) {
//   if (!Array.isArray(dataArray)) {
//     console.error("Input must be an array of objects.");
//     return [];
//   }

//   return dataArray
//     .filter(item => item.hasOwnProperty("EXT_IDENTIFIER_NUMBER"))
//     .map(item => item.EXT_IDENTIFIER_NUMBER);
// }

  PageModule.prototype.filterADPData = function (arrayList, attrs, vals) {
    let returnVal = [];
    let arrayItem = [];

    if (!attrs || attrs.length < 1)
      returnVal = arrayList;
    else {
      arrayList.forEach((item) => {
        let isMatched = false;
        attrs.forEach((attr, i) => {
          if (item[attr] === vals[i])
            isMatched = true;
        });
        if (isMatched)
          returnVal.push(item);
      }
      );
    }
    return returnVal;
  };

  PageModule.prototype.isCrossDivision = function (linesData) {
    let returnVal = 'Y';
    linesData.forEach(element => {
      if (element.from_division !== element.to_division) {
        returnVal = 'N';
      }
    });
    return returnVal;
  };

  PageModule.prototype.getSysDate = function () {
    const today = new Date();
    const day = String(today.getDate()).padStart(2, '0');
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const year = today.getFullYear();

    return `${year}-${month}-${day}`;
  };

  PageModule.prototype.checkItemsPOline = function (reqLinesADP, lineDetails) {
    for (let i = 0; i < reqLinesADP.length; i++) {
      if (reqLinesADP[i].Status !== 'Canceled') {
        if (reqLinesADP[i].Item === lineDetails.Item) {
          return { success: true, message: 'Same item cannot exist at more than one PO line' };
        }
        const shipToOrgCode = reqLinesADP[i].schedules?.items?.[0]?.ShipToOrganizationCode;
        const orgCode = reqLinesADP[i].OrganizationCode;
        const existingOrgCode = shipToOrgCode || orgCode;
        const newOrgCode = lineDetails.OrganizationCode;

        if (existingOrgCode && newOrgCode && existingOrgCode !== newOrgCode) {
          return {
            success: true,
            message: 'Purchase Order cannot have more than one Inventory Organization for multiple lines. Kindly update Purchase Order to have same Inventory Org across lines'
          };
        }
      }
    }
    return { success: false };
  };


  PageModule.prototype.createPayload = function (data, LineADP, LineTypeInvMatch, DFFheaders, lineDFF) {
    console.log("LineADP data:", JSON.stringify(LineADP));
  const date=new Date().toISOString().split('T')[0];
 let InspectReqFlag, RecReqFlag;
 
	if (LineTypeInvMatch.DefaultMatchApprovalLevelCode.includes('2')) {
		InspectReqFlag = false;
		RecReqFlag = false;
	} else if (LineTypeInvMatch.DefaultMatchApprovalLevelCode.includes('3')) {
		InspectReqFlag = false;
		RecReqFlag = true;
	} else if (LineTypeInvMatch.DefaultMatchApprovalLevelCode.includes('4')) {
		InspectReqFlag = true;
		RecReqFlag = true;
	}

    const lines = LineADP.map((line) => {
   
      return {

        LineNumber: line.LineNumber,
        LineType: "Goods",
        Item: line.Item,
        Category: "Goods",
        Description: line.Description || "Peripherals_Type_Docking Stations",
        Quantity: line.Quantity,
        SourceAgreementNumber: line.SourceAgreementNumber,
        SourceAgreementLine: line.SourceAgreementLine,
        SourceAgreementProcurementBUId: data.ProcurementBUId,
        Price: line.Price,
        UOM: line.UOM,
        "DFF": [
          Object.assign({}, line.DFF.items[0], lineDFF)
        ],
        schedules: [
          {
            ScheduleNumber: line.LineNumber,
            Quantity: line.Quantity,
            ShipToLocation: data.ShipToLocationCode,
            ShipToOrganizationCode: line.OrganizationCode,
            ReceiptCloseTolerancePercent: 0,
            InvoiceMatchOptionCode: LineTypeInvMatch.DefaultInvoiceMatchOptionCode,
            MatchApprovalLevelCode: LineTypeInvMatch.DefaultMatchApprovalLevelCode,
            MatchApprovalLevel:  LineTypeInvMatch.DefaultMatchApprovalLevel,
            RequestedDeliveryDate: line.RequestedDeliveryDate,
            PromisedDeliveryDate: line.PromisedDeliveryDate,
            // EarlyReceiptToleranceDays: 0,  
            InvoiceCloseTolerancePercent: 0,
            // LateReceiptToleranceDays: 0,  
            // AccrueAtReceiptFlag: true,  
            InspectionRequiredFlag: InspectReqFlag,
            ReceiptRequiredFlag: RecReqFlag,
            ReceiptRoutingId: 3,
            //DestinationTypeCode: "INVENTORY",  
            //Carrier: null,  
            // RequestedDeliveryDate: "",  
            distributions: [
              {
                DistributionNumber: line.LineNumber,
                DeliverToLocation: data.ShipToLocationCode,
                Quantity: line.Quantity,
              }
            ]
          }
        ]
      };

    });

    // old code starts
  //   let first = data.ShippingMethod.indexOf("-");
  // let last = data.ShippingMethod.lastIndexOf("-");
  // console.log('first+++++++++++++++++++++++++++++'+first+data.ShippingMethod);
  // console.log('first+++++++++++++++++++++++++++++'+last);

  // let part1 = data.ShippingMethod.substring(0, first);//0
  // let part2 = data.ShippingMethod.substring(first + 1, last);//1
  // let part3 = data.ShippingMethod.substring(last + 1);//2
// old code ends

let shippingmethod = data.ShippingMethod;
let normalized = shippingmethod.replace(/_/g,"-");
let parts = normalized.split("-");
let part1 = parts[0];
let part2 = "";
let part3 = "";
if(parts.length >= 4){
  part3 = parts.slice(-3).join("-");
  part2 = parts.slice(1, parts.length -3).join("");
}
else{
  part2 = parts[1];
  part3 = parts[2];
}

console.log('part1+++++++++++++++++++++++++++++'+part1+'shipping++++++++++++++++++++'+data.ShippingMethod);
  console.log('part2+++++++++++++++++++++++++++++'+part2);
    console.log('part3+++++++++++++++++++++++++++++'+part3);
    // full payload structure
    return {

      ProcurementBUId: data.ProcurementBUId,
      RequisitioningBUId: data.RequisitioningBUId,
      BuyerId: data.BuyerId,
      Supplier: data.Supplier,
      Currency: data.Currency || "USD",
      DocumentStyleId: data.DocumentStyleId,
      SupplierSiteId: data.SupplierSiteId,
      DocumentCreationMethod: "ENTER_PO",
      BillToLocation: data.BillToLocation,
      // SoldToLegalEntity : "Dell Products L.P.",
      SoldToLegalEntity: data.SoldToLegalEntity,
      DefaultShipToLocation: data.ShipToLocationCode,
      RequiredAcknowledgment: data.RequiredAcknowledgment || "None",
      Description: data.Description || null,
      SupplierCommunicationMethod: data.SupplierCommunicationMethodCode,
      SupplierEmailAddress: data.SupplierEmailAddress,
      SupplierContact: data.SupplierContact,
      // SupplierContactId: data.SupplierContactId,
      BuyerManagedTransportFlag: data.BuyerManagedTransportFlag || false,
      PayOnReceiptFlag: data.PayOnReceiptFlag || false,
      PaymentTerms: data.PaymentTerms,
      ConversionRateType: "Corporate",
      ConversionRateDate : date,
      // ShippingMethod: data.ShippingMethod || "",
      Carrier: part1,
      ServiceLevel: part3,
      ModeOfTransport: part2,
      FreightTermsCode: data.FreightTermsCode || null,
      FOBCode: data.FOBCode || null,
      NoteToReceiver: data.NoteToReceiver || "",
      NoteToSupplier: data.NoteToSupplier || "",
      "DFF": [
        DFFheaders
      ],
      lines: lines // Dynamically created lines based on LineADP
    };
  };




  PageModule.prototype.createchangeOrderPayload = function (data, LineADP, comments, DFFheaders, lineDFF) {
    console.log("LineADP data:", JSON.stringify(LineADP));

    //  const filteredLines = LineADP.filter(line => line.POLineId);
    //   const lines = filteredLines.map((line) => {
    //     return {
    //       POLineId: line.POLineId,
    //       LineNumber: line.LineNumber, 
    //       LineType:  "Goods", 
    //       Item: line.Item , 
    //       Category: "Goods", 
    //       Description: line.Description || "Peripherals_Type_Docking Stations",
    //       Quantity: line.Quantity,
    //       Price: line.Price,
    //       UOM: line.UOM 
    //     };

    //   });


    const lines = LineADP.map((line) => {
      if (line.POLineId && line.StatusCode !== 'CANCELED') {
        if (line.CancelFlag === 'true') {
          return {
            POLineId: line.POLineId,
            CancelFlag: true,
            CancelReason: "cancel line",
            CancelUnfulfilledDemandFlag: "false"
          };
        } else if (!line.CancelFlag) {
          return {
            POLineId: line.POLineId,
            LineNumber: line.LineNumber,
            LineType: "Goods",
            Item: line.Item,
            Category: "Goods",
            Description: line.Description || "Peripherals_Type_Docking Stations",
            Quantity: line.Quantity,
            Price: line.Price,
            SourceAgreementNumber: line.SourceAgreementNumber,
            SourceAgreementLine: line.SourceAgreementLine,
            SourceAgreementProcurementBUId: data.ProcurementBUId,
            UOM: line.UOM, 
            "DFF": [
              Object.assign({}, line.DFF.items[0], lineDFF)
            ],
              schedules: [
          {        
            LineLocationId:  line.schedules.items[0].LineLocationId,
            RequestedDeliveryDate: line.RequestedDeliveryDate,
            PromisedDeliveryDate: line.PromisedDeliveryDate
          }
        ]
          };
        }
      }
    }).filter(Boolean);
 // old code starts
// let first = data.ShippingMethod.indexOf("-");
//   let last = data.ShippingMethod.lastIndexOf("-");

//   let part1 = data.ShippingMethod.substring(0, first);//0
//   let part2 = data.ShippingMethod.substring(first + 1, last);//1
//   let part3 = data.ShippingMethod.substring(last + 1);//2
 // old code ends

let shippingmethod = data.ShippingMethod;
let normalized = shippingmethod.replace(/_/g,"-");
let parts = normalized.split("-");
let part1 = parts[0];
let part2 = "";
let part3 = "";
if(parts.length >= 4){
  part3 = parts.slice(-3).join("-");
  part2 = parts.slice(1, parts.length -3).join("");
}
else{
  part2 = parts[1];
  part3 = parts[2];
}

console.log('part1+++++++++++++++++++++++++++++'+part1+'shipping++++++++++++++++++++'+data.ShippingMethod);
  console.log('part2+++++++++++++++++++++++++++++'+part2);
    console.log('part3+++++++++++++++++++++++++++++'+part3);
    // full payload structure
    return {

      ProcurementBUId: data.ProcurementBUId,
      RequisitioningBUId: data.RequisitioningBUId,
      BuyerId: data.BuyerId,
      Supplier: data.Supplier,
      Currency: data.Currency || "USD",
      DocumentStyleId: data.DocumentStyleId,
      SupplierSiteId: data.SupplierSiteId,
      BillToLocation: data.BillToLocation,
      DefaultShipToLocation: data.ShipToLocationCode,
      RequiredAcknowledgment: data.RequiredAcknowledgment || "None",
      Description: data.Description || null,
      SupplierCommunicationMethod: data.SupplierCommunicationMethodCode,
      SupplierEmailAddress: data.SupplierEmailAddress,
      SupplierContact: data.SupplierContact,
      // SupplierContactId : data.SupplierContactId,
      ChangeOrderDescription: comments,
      ChangeOrderInitiatingParty: "BUYER",
      BuyerManagedTransportFlag: data.BuyerManagedTransportFlag || false,
      PayOnReceiptFlag: data.PayOnReceiptFlag || false,
      PaymentTerms: data.PaymentTerms,
      // ShippingMethod: data.ShippingMethod || "",
        Carrier: part1,
      ServiceLevel: part3,
      ModeOfTransport: part2,
      FreightTermsCode: data.FreightTermsCode || null,
      FOBCode: data.FOBCode || null,
      NoteToReceiver: data.NoteToReceiver || "",
      NoteToSupplier: data.NoteToSupplier || "",
      "DFF": [
        DFFheaders
      ],
      lines: lines // Dynamically created lines based on LineADP
    };
  };

  PageModule.prototype.createlinePayload = function (data, LineADP, LineTypeInvMatch, lineDFF) {
    console.log("LineADP data:", JSON.stringify(LineADP));
  
   let InspectReqFlag, RecReqFlag;
    if (LineTypeInvMatch.DefaultMatchApprovalLevelCode.includes('2')) {
		InspectReqFlag = false;
		RecReqFlag = false;
	} else if (LineTypeInvMatch.DefaultMatchApprovalLevelCode.includes('3')) {
		InspectReqFlag = false;
		RecReqFlag = true;
	} else if (LineTypeInvMatch.DefaultMatchApprovalLevelCode.includes('4')) {
		InspectReqFlag = true;
		RecReqFlag = true;
	}


    const filteredLines = LineADP.filter(line => !line.StatusCode);

    const lines = filteredLines.map((line) => {
      return {
        LineNumber: line.LineNumber,
        LineType: "Goods",
        Item: line.Item,
        Category: "Goods",
        Description: line.Description || "Peripherals_Type_Docking Stations",
        Quantity: line.Quantity,
        Price: line.Price,
        UOM: line.UOM,
        SourceAgreementNumber: line.SourceAgreementNumber,
        SourceAgreementLine: line.SourceAgreementLine,
        SourceAgreementProcurementBUId: data.ProcurementBUId,
        "DFF": [
          Object.assign({}, line.DFF.items[0], lineDFF)
        ],
        schedules: [
          {
            ScheduleNumber: line.LineNumber,
            Quantity: line.Quantity,
            ShipToLocation: data.ShipToLocationCode,
            ShipToOrganizationCode: line.OrganizationCode,
            ReceiptCloseTolerancePercent: 0,
            // InvoiceMatchOptionCode: "P",
            InvoiceMatchOptionCode: LineTypeInvMatch.DefaultInvoiceMatchOptionCode,
            MatchApprovalLevelCode: LineTypeInvMatch.DefaultMatchApprovalLevelCode,
             MatchApprovalLevel:  LineTypeInvMatch.DefaultMatchApprovalLevel,
            RequestedDeliveryDate: line.RequestedDeliveryDate,
            PromisedDeliveryDate: line.PromisedDeliveryDate,
            InvoiceCloseTolerancePercent: 0,
           InspectionRequiredFlag: InspectReqFlag,
            ReceiptRequiredFlag: RecReqFlag,
            ReceiptRoutingId: 3,
            distributions: [
              {
                DistributionNumber: line.LineNumber,
                DeliverToLocation: data.ShipToLocationCode,
                Quantity: line.Quantity,
              }
            ]
          }
        ]
      };
    });

    return {
      lines: lines
    };
  };


  // PageModule.prototype.createlinePayload = function (data, LineADP) {
  //   console.log("LineADP data:", JSON.stringify(LineADP));


  //   const lines = LineADP.map((line) => {
  //     if(!line.POLineId){
  //     return {

  //       LineNumber: line.LineNumber, 
  //       LineType:  "Goods", 
  //       Item: line.Item , 
  //       Category: "Goods", 
  //       Description: line.Description || "Peripherals_Type_Docking Stations",
  //       Quantity: line.Quantity,
  //       Price: line.Price,
  //       UOM: line.UOM , 
  //       schedules: [
  //         {
  //           ScheduleNumber: line.LineNumber, 
  //           Quantity: line.Quantity, 
  //           ShipToLocation: data.ShipToLocationCode , 
  //           ShipToOrganizationCode: line.OrganizationCode, 
  //           ReceiptCloseTolerancePercent: 0, 
  //           InvoiceMatchOptionCode: "P", 
  //           RequestedDeliveryDate: line.RequestedDeliveryDate,
  //           PromisedDeliveryDate: line.PromisedDeliveryDate,
  //          // EarlyReceiptToleranceDays: 0,  
  //           InvoiceCloseTolerancePercent: 0,  
  //          // LateReceiptToleranceDays: 0,  
  //          // AccrueAtReceiptFlag: true,  
  //           InspectionRequiredFlag: true,  
  //           ReceiptRequiredFlag: false,  
  //           ReceiptRoutingId: 3,
  //           //DestinationTypeCode: "INVENTORY",  
  //           //Carrier: null,  
  //          // RequestedDeliveryDate: "",  
  //           distributions: [
  //             {
  //               DistributionNumber: line.LineNumber, 
  //               DeliverToLocation: data.ShipToLocationCode, 
  //               Quantity: line.Quantity, 
  //             }
  //           ]
  //         }
  //       ]
  //     };
  //   }
  //   });

  //   // full payload structure
  //   return {

  //     lines: lines // Dynamically created lines based on LineADP
  //   };
  // };

  PageModule.prototype.isSameReviewer = function (linesData) {
    let returnVal = 'Y';
    let from_reviewer = null;
    let to_reviewer = null;
    linesData.forEach(element => {
      if (element.from_reviewer !== element.to_reviewer) {
        returnVal = 'N';
      }
      if (from_reviewer && element.from_reviewer !== from_reviewer) {
        returnVal = 'FROM';
      }
      if (to_reviewer && element.from_reviewer !== to_reviewer) {
        returnVal = 'TO';
      }
      from_reviewer = element.from_reviewer;
      to_reviewer = element.to_reviewer;
    });
    return returnVal;
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */

  PageModule.prototype.cancelPOLine = function (data) {
    //   return  {
    // //   "ChangeOrderDescription": "Change order",
    // //   "ChangeOrderInitiatingParty":"BUYER",
    //   "lines" : [
    //   {
    //     "POLineId":data? data: '',
    //     "CancelFlag": true,
    //     "CancelReason": "cancel line",
    //     "CancelUnfulfilledDemandFlag": "false"
    //   }
    //   ]
    // }

    return [
      {
        "POLineId": data ? data : '',
        "CancelFlag": true,
        "CancelReason": "cancel line",
        "CancelUnfulfilledDemandFlag": "false",
        "LineNumber": '',
        "LineType": ''
        // Item: line.Item,
        //       Category: "Goods",
        //       Description: line.Description || "Peripherals_Type_Docking Stations",
        //       Quantity: line.Quantity,
        //       Price: line.Price,
        //       UOM: line.UOM

      }
    ];
  };


PageModule.prototype.getStatusText = function(statusCode) {
  const codeMap = {
    200: "Ok",
    400: "Bad Request",
    401: "Unauthorized",
    402: "Payment Required",
    403: "Forbidden",
    404: "(Not Found), This action cannot be done on this Purchase Order",
    405: "Method Not Allowed",
    406: "Not Acceptable",
    407: "Proxy Authentication Required",
    408: "Request Timeout",
    409: "Conflict",
    410: "Gone",
    411: "Length Required",
    412: "Precondition Failed",
    413: "Payload Too Large",
    414: "URI Too Long",
    415: "Unsupported Media Type",
    416: "Range Not Satisfiable",
    417: "Expectation Failed",
    421: "Misdirected Request",
    422: "Unprocessable Entity",
    423: "Locked",
    424: "Failed Dependency",
    425: "Too Early",
    426: "Upgrade Required",
    428: "Precondition Required",
    429: "Too Many Requests",
    431: "Request Header Fields Too Large",
    451: "Unavailable For Legal Reasons",
    500: "Internal Server Error",
    501: "Not Implemented",
    502: "Bad Gateway",
    503: "Service Unavailable",
    504: "Gateway Timeout",
    505: "HTTP Version Not Supported",
    506: "Variant Also Negotiates",
    507: "Insufficient Storage",
    508: "Loop Detected",
    510: "Not Extended",
    511: "Network Authentication Required",
     555 : "User Defined Error"
    
  };

let result =  codeMap[statusCode] || "Unknown Status Code";
  return result;
};


PageModule.prototype.checkCountry = function (country1,country2) {
  console.log('++++++++country1+++++++'+country1);
  console.log('++++++++country2+++++++'+country2);
     let result;
      if (country1 === country2) {
        result = 'true';
        console.log('========='+1+result);
      }
      
      else {
        result = 'False';
        console.log('========='+2+result);
      }

      console.log("result+++++++++++++"+result);
      return result;
      
    };



PageModule.prototype.checkStatus = function (count,county,hnesc) {
  console.log('++++++++hnesc+++++++'+hnesc);
     let result;
      if (count === 1 && county === 'true' && hnesc !== null) {
        result = 'true';
        console.log('========='+1);
      }
      
      else if (count === 1 && county === 'true' && hnesc === null) {
        result = 'False';
        console.log('========='+2+hnesc+result);
      }
       else if (count === 0 || count === null || count === undefined ) {
        result= 'true';
        console.log('========='+3);
      }
      console.log("result+++++++++++++"+result);
      return result;
      
    };



// PageModule.prototype.polovalidation = function (loCode, buLocalCurrency, poCurrency) {
//   let result;
//   console.log('=====locode==========='+loCode);
//    console.log('=====buLocalCurrency==========='+buLocalCurrency);
//     console.log('=====poCurrency==========='+poCurrency);
//   if (loCode === 'L') {
//     if (poCurrency === buLocalCurrency) {
//       result = "true";
//       console.log("=====l 1=====");
//     } else {
//       result = "False";
//     }
//     console.log("=====l 2=====");
//   }

//   if (loCode === 'O') {
//     if (poCurrency !== buLocalCurrency) {
//       result = "true";
//       console.log("=====O 1=====");
//     } else {
//       result = "False";
//       console.log("=====O 2=====");
//     }
//   }

//   if (loCode === 'X') {
//     result = "true";
//     console.log("=====x=====");
//   }

//   if (loCode === null || loCode === undefined || loCode === '') {
//     result = "False";
//     console.log("=====no lo code=====");
//   }

//   if (loCode !== 'L' && loCode !== 'O' && loCode === 'X' && loCode !== null && loCode !== undefined && loCode !== ''){
//   result = "true";
//   }
//   console.log("+++++result+++++"+result);
//   return result;

// };



PageModule.prototype.polovalidation = function (loCode, buLocalCurrency, poCurrency) {
  let result;

  console.log("==== loCode ====", loCode);
  console.log("==== buLocalCurrency ====", buLocalCurrency);
  console.log("==== poCurrency ====", poCurrency);

  if (loCode === 'L') {
    result = (poCurrency === buLocalCurrency) ? "true" : "falsepolo";
    console.log('=====1====');
  } 
  else if (loCode === 'O') {
    result = (poCurrency !== buLocalCurrency) ? "true" : "falsepolo";
     console.log('=====2====');
  } 
  else if (loCode === 'X') {
     console.log('=====3====');
    result = "true";
  } 
  else if (loCode === null || loCode === undefined || loCode === '') {
     console.log('=====4====');
    result = "falsepolo";
  } 
  else {
     console.log('=====5====');
    // Any other value
    result = "true";
  }

  console.log("==== result ====", result);
  return result;
};





// PageModule.prototype.getRequiredForLOValidationABCD = function(apiResponse, inventoryOrg) {
//   let result;
//     let items = apiResponse.items;

//     for (let item of items) {
//       const lookupData = item.lookupsDFF.items[0]; // Assumes only one item in lookupsDFF

//       if (lookupData.inventoryOrg === inventoryOrg) {
//         result = lookupData.requiredForLOValidation;
//         return result;
//       }
//     }

//     return 'error';
// };



PageModule.prototype.getRequiredForLOValidationABCD = function(apiResponse, inventoryOrg) {
  let apiresult;
    try {
        let data = apiResponse;
       
        // Handle VB REST response wrapping
        if (apiResponse && apiResponse.body) {
            data = apiResponse.body;
        } else if (apiResponse && apiResponse.result) {
            data = apiResponse.result;
        } else if (apiResponse && apiResponse.data) {
            data = apiResponse.data;
        }
       
        // Check if data has items array
        if (!data || !data.items || !Array.isArray(data.items)) {
            console.error("No items array found in response");
             apiresult = 'Error'; // Not found
        return apiresult;
        }
       
        // Search through items
        for (let i = 0; i < data.items.length; i++) {
            const item = data.items[i];
           
            if (item && item.lookupsDFF && item.lookupsDFF.items &&
                Array.isArray(item.lookupsDFF.items) && item.lookupsDFF.items.length > 0) {
               
                const lookupData = item.lookupsDFF.items[0];
               
                if (lookupData && lookupData.inventoryOrg === inventoryOrg) {
                    apiresult = lookupData.requiredForLOValidation;
                    console.log('=======================api result ==============='+apiresult);
                    return apiresult;
                }
            }
        }
       
        // apiresult = null; // Not found
        // return apiresult;
       
    } catch (error) {
        console.error("Error:", error);
         apiresult = 'Error'; // Not found
        return apiresult;
    }
    return apiresult;
};

//  PageModule.prototype.filterOrgs = function (lookupdata, Org) {
//     const seen = new Set();
//     lookupdata.forEach(entry => {
//       if (entry.lookupsDFF && Array.isArray(entry.lookupsDFF.items)) {
//         entry.lookupsDFF.items.forEach(item => {
//           const flexContext = item.__FLEX_Context ? item.__FLEX_Context.trim().toUpperCase() : '';
//           const requiredFlag = item.requiredForLOValidation ? item.requiredForLOValidation.trim().toUpperCase() : '';
//           const inventoryOrg = item.inventoryOrg ? item.inventoryOrg.trim() : '';
//           if (
//             flexContext === 'STP_CMN_PURDOCATTRXREF_LKP' &&
//             requiredFlag === "YES" &&
//             inventoryOrg !== ''
//           ) {
//             seen.add(inventoryOrg);
//           }
//         });
//       }
//     });
//     const orgToCheck = Org ? Org.trim().toUpperCase() : '';
//     const uppercaseSeen = new Set([...seen].map(org => org.toUpperCase()));
//     return uppercaseSeen.has(orgToCheck);
//   };

  PageModule.prototype.filterOrgs = function (lookupdata, Org) {
    const seen = new Set();
    lookupdata.forEach(entry => {
      if (entry.lookupsDFF && Array.isArray(entry.lookupsDFF.items)) {
        entry.lookupsDFF.items.forEach(item => {
          const flexContext = item.__FLEX_Context ? item.__FLEX_Context.trim().toUpperCase() : '';
          // const requiredFlag = item.requiredForLOValidation ? item.requiredForLOValidation.trim().toUpperCase() : '';
          // const inventoryOrg = item.inventoryOrg ? item.inventoryOrg.trim() : '';
          const validationParts = item.validationOptions ? item.validationOptions.split('|') : [];
            // const requiredFlag = item.validationOptions ? item.validationOptions.split('|')[0].trim().toUpperCase() : '';
            const requiredFlag = validationParts.length > 2 ? validationParts[2].trim().toUpperCase() : '';
            console.log('++++++++++++++++++++requiredFlag++++++++++++++++++++'+requiredFlag);
          const inventoryOrg = item.inventoryOrg ? item.inventoryOrg.split('|')[0].trim() : '';
          console.log('++++++++++++++++++++inventoryOrg++++++++++++++++++++'+inventoryOrg);
          if (
            flexContext === 'STP_CMN_PURDOCATTRXREF_DFF' &&
            requiredFlag === 'Y' &&
            inventoryOrg !== ''
          ) {
            seen.add(inventoryOrg);
          }
        });
      }
    });
    const orgToCheck = Org ? Org.trim().toUpperCase() : '';
    const uppercaseSeen = new Set([...seen].map(org => org.toUpperCase()));
    return uppercaseSeen.has(orgToCheck);
  };

  /**
   *
   * @param {String} arg1
   * @return {String}
   */




  return PageModule;
});
