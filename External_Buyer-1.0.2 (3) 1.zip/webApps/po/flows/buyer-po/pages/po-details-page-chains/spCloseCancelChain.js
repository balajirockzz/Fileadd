define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class spCloseCancelChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.SecondaryActionValue 
     */
    async run(context, { SecondaryActionValue }) {
      const { $page, $flow, $application, $constants, $variables } = context;


      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.closeReason',
    '$page.variables.cancelReason',
    '$page.variables.poCloseAction',
    '$page.variables.communicationEmail',
  ],
      });

      if (SecondaryActionValue === 'CANCEL_PO') {
        const ojDialogCancelPoOpen = await Actions.callComponentMethod(context, {
          selector: '#oj-dialog-cancel-po',
          method: 'open',
        });

        $variables.communicationEmail = $flow.variables.transReqDetails.SupplierEmailAddress;
      }
      else if(SecondaryActionValue === 'CLOSE_PO'){
        const ojDialogClosePoOpen = await Actions.callComponentMethod(context, {
          selector: '#oj-dialog-close-po',
          method: 'open',
        });

      }
  
    }
  }

  return spCloseCancelChain;
});
