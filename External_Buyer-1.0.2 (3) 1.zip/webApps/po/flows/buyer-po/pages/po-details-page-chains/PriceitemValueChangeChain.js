define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PriceitemValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application } = context;

     $page.variables.lineDetails.Amount = $page.variables.lineDetails.Quantity && 
$page.variables.lineDetails.Price ?  
($page.variables.lineDetails.Quantity * 
$page.variables.lineDetails.Price) : null;


    }
  }

  return PriceitemValueChangeChain;
});
