define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class viewLineDetailsChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application, $constants, $variables } = context;


      $variables.hyperlinkPriceflag = true;

           $variables.lineDetails = current.row;   
      $variables.lineDetails.Amount = (current.row.Price) * (current.row.Quantity);
      $variables.lineDetails.attribute10 =[current.row.Item,current.row.attribute1];
      
     

      const response2 = await Actions.callRest(context, {
        endpoint: 'ics_conn/getSTP_PROC_EXT_005_PO_GETSO1_0',
        uriParams: {
          'doc_style': $page.variables.DocumentStyle,
          'item_number': current.row.Item,
          'procurement_bu': $flow.variables.transReqDetails.ProcurementBU,
          'supplier_name': $flow.variables.transReqDetails.Supplier,
          'supplier_site': $flow.variables.transReqDetails.SupplierSite,
        },
      });

      if (response2.ok) {
        if (response2.body.Results) {

          $variables.SourceAgreementNumberADP.data = await $application.functions.getADPData(response2.body.Results, 'SourceAgreementNumber');
        }
      }

      $variables.lineDetails.SourceAgreementNumber  = current.row.SourceAgreementNumber;

     let poHeaderId = current.row.POHeaderId;
     let poLineId = current.row.POLineId;
      const response = await Actions.callRest(context, {
        endpoint: 'fscm_conn/getPurchaseOrdersChildLines',
        uriParams: {
          poheaderid: poHeaderId,
          polineid: poLineId,
        },
      });

      if (response.ok) {

        $variables.lineDetails.PromisedDeliveryDate = response.body.schedules.items[0].PromisedDeliveryDate;
        $variables.lineDetails.RequestedDeliveryDate = response.body.schedules.items[0].RequestedDeliveryDate;
        $variables.lineDetails.ReceivedAmount = response.body.schedules.items[0].ReceivedAmount;
        $variables.lineDetails.ReceivedQuantity = response.body.schedules.items[0].ReceivedQuantity;
        $variables.lineDetails.OrganizationCode = response.body.schedules.items[0].ShipToOrganizationCode;
        $variables.lineDetails.BilledAmount = response.body.schedules.items[0].BilledAmount;
        $variables.lineDetails.BilledQuantity = response.body.schedules.items[0].BilledQuantity;
        // $variables.lineDetails.SourceAgreementNumber  = response.body.SourceAgreementNumber;



      }

if (current.row && current.row.DFF && current.row.DFF.items && Array.isArray(current.row.DFF.items) && current.row.DFF.items.length > 0) {
    // If items[0] exists and is not empty
    $variables.DFFlines = current.row.DFF.items[0];
} else {
    // If items is undefined, empty, or not an array, assign an empty object
    $variables.DFFlines = {};
}

      if (!$variables.lineDetails.POLineId) {

        $variables.updateLineFlag = true;
      }

      $variables.ManualPriceCheckFlag = true;

      const lineDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#lineDialog',
        method: 'open',
      });
    }
  }

  return viewLineDetailsChain;
});
