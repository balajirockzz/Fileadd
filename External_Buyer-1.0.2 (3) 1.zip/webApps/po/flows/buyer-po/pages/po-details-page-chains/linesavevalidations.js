define([
  'vb/action/actionChain',
    'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class linesavevalidations extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const progresBarOpen = await Actions.callComponentMethod(context, {
        selector: '#ProgresBar',
        method: 'open',
      });

      // MAV_PUR_DOC_ATTR_XREF
      const response11 = await Actions.callRest(context, {
        endpoint: 'FSCMApiConnection/getCommonLookupsTypeChildLookupCodes2',
        uriParams: {
          type: 'STP_CMN_PURDOCATTRXREF_LKP',
        },
      });

      const filterOrgs = await $functions.filterOrgs(response11.body.items, $variables.organizationCode);

      $variables.RequireForLovalidation = filterOrgs;

            // find supplier address id
            const response2 = await Actions.callRest(context, {
              endpoint: 'FSCMApiConnection/getSuppliersSupplieridChildSitesSiteid',
              uriParams: {
                supplierid: $variables.SupplierId,
                siteid: $flow.variables.transReqDetails.SupplierSiteId,
              },
            });
// add the address id with supplier id
      const response3 = await Actions.callRest(context, {
        endpoint: 'FSCMApiConnection/getSuppliersSupplierIdChildAddressesSupplierAddressId',
        uriParams: {
          SupplierAddressId: response2.body.SupplierAddressId,
          SupplierId: $variables.SupplierId,
          fields: 'AddressName,CountryCode,Country,City',
        },
      });

            $variables.Country_var = response3.body.CountryCode;

      // to check the requestion bu and get the loaction id
      const response4 = await Actions.callRest(context, {
        endpoint: 'FSCMApiConnection/getFinBusinessUnitsLOV',
        uriParams: {
          q: "BusinessUnitName="+"'"+ $variables.clientbu_var+"'",
          onlyData: 'true',
        },
      });
            if (response4.body.items[0].LocationId === null || response4.body.items[0].LocationId === undefined) {
        $variables.location_id_var = 0;
      } else {
        $variables.location_id_var = response4.body.items[0].LocationId;
      }

      // by passing the location id need to get the country code
      const response5 = await Actions.callRest(context, {
        endpoint: 'hcm_conn/getLocations2',
        uriParams: {
          q: "LocationId="+ $variables.location_id_var,
        },
      });

      if ($variables.Country_var === 'IN' && response5.body.items[0].Country === 'IN') {

        // validate both the country codes
        const checkCountry2 = await $functions.checkCountry($variables.Country_var, response5.body.items[0].Country);

        // to check wheather the po is there in service level or not/MAV_PROC_BU_LINE_OF_SERVICE
        const response = await Actions.callRest(context, {
          endpoint: 'fscm_conn/getCommonLookups',
          uriParams: {
            q: "Tag IN ('SERVICE','MANUFACTURING') and Meaning=" + "'"+ $flow.variables.transReqDetails.ProcurementBU+"'",
            LookupType: 'STP_PROC_EXT_024_BULINESER_LKP',
          },
        });

                  // to find the hsnsac code
                  const response6 = await Actions.callRest(context, {
                    endpoint: 'fscm_conn/getItemsV2ItemidChildItemEffCategoryCategoryidChildItemEFFBTaxPrivateVO',
                    uriParams: {
                      fields: 'hsnSac',
                      categoryid: $variables.hnsec_var,
                      itemid: $variables.hnsec_var,
                    },
                  });

        // to get the output as true or false
        const checkStatus2 = await $functions.checkStatus(response.body.count, checkCountry2, response6.body.items[0].hsnSac);

        if (checkStatus2 === "true") {

          const response12 = await Actions.callRest(context, {
            endpoint: 'fscm_conn/getSuppliersSupplierIdChildSitesSupplierSiteIdChildDFF',
            uriParams: {
              SupplierId: $variables.SupplierId,
              SupplierSiteId: $flow.variables.transReqDetails.SupplierSiteId,
            },
          });

          // const response10 = await Actions.callRest(context, {
          //   endpoint: 'FSCMApiConnection/getTaxRegistrations2',
          //   uriParams: {
          //     q: "PartyName="+"'"+$flow.variables.transReqDetails.Supplier+"'"+"and PartyCountryCode ='IN'",
          //   },
          // });

          if (response12.body.items[0].gstRegistration === 'GST Registered') {
            $variables.line_valid_var = 'Yes';
          } else {
            $variables.line_valid_var = 'No';
          }
        } else {
          $variables.line_valid_var = 'FalseHsnc';
        }
      } else if ($variables.RequireForLovalidation === 'true') {

        // for taking count/MAV_CN_EXCLD_PO_STYLE_L_O_CODE
        const response7 = await Actions.callRest(context, {
          endpoint: 'fscm_conn/getCommonLookups',
          uriParams: {
            q: "Meaning="+"'"+ $flow.variables.transReqDetails.DocumentStyle+"'",
            onlyData: 'true',
            LookupType: 'STP_CMN_CN_EXCLPOSTYLOCODE_LKP',
          },
        });

        if (response7.body.count === 0) {

          // MAV_BU_LOCAL_CURRENCY
          const response8 = await Actions.callRest(context, {
            endpoint: 'fscm_conn/getCommonLookups',
            uriParams: {
              q: "Meaning="+"'"+ $variables.clientbu_var+"'",
              onlyData: 'true',
              fields: 'Tag',
              LookupType: 'STP_CMN_BULOCALCURRENCY_LKP',
            },
          });

          if (response8.body.count === 0) {
            $variables.tag_var = 'null';
          } else {
            $variables.tag_var = response8.body.items[0].Tag;
          }

          const response9 = await Actions.callRest(context, {
            endpoint: 'FSCMApiConnection/getItemsV2IdChildItemEffCategoryId2ChildItemEFFBCompliancePrivateVO2',
            uriParams: {
              id: $variables.hnsec_var,
              id2: $variables.hnsec_var,
            },
          });

          const polovalidation = await $functions.polovalidation(response9.body.items[0].localOverseasCode, $variables.tag_var, $flow.variables.transReqDetails.CurrencyCode);

          $variables.line_valid_var = polovalidation;
        } else {

          $variables.line_valid_var = 'Yes';
        }
      } else {
        $variables.line_valid_var = 'Yes';
      }

      const progresBarClose = await Actions.callComponentMethod(context, {
        selector: '#ProgresBar',
        method: 'close',
      });

    }
  }

  return linesavevalidations;
});