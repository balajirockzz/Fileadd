define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class supplierChangeChain extends ActionChain {

    
     
    async run(context, { details }) {
      const { $page, $flow, $application, $variables } = context;

      await $application.functions.openSpinnerDialog();

  //     await Actions.resetVariables(context, {
  //       variables: [
  //   '$flow.variables.transReqDetails.supplier_site',
  // ],
  //     });

      if( details && details.SUPPLIER_SITE_ID) {

        const results = await Promise.all([
          async () => {

                                 $page.variables.supplierSIteADP.data = $application.functions.filterADPData(
              $application.functions.getADPData($application.variables.buyerAssoc.ASSOCIATIONS,'SUPPLIER_SITE_ID'),['SUPPLIER_ID'],[details.SUPPLIER_ID])

      // const response = await Actions.callRest(context, {
      //       endpoint: 'fscm_conn/getSuppliersSite',
      //       uriParams: {
      //         q: 'SupplierSite in '+ $application.functions.getInClause($flow.variables.supplierAssoc.supplierSiteList),
      //         SupplierId: details.SUPPLIER_ID,
      //       },
      // });

          
      //             if (response.ok) {
                
      //          $page.variables.supplierSIteADP.data = response.body.items;
      //          console.log(">>", $page.variables.supplierSIteADP.data)
      //             }
            
           
          },
          async () => {

            const response2 = await Actions.callRest(context, {
              endpoint: 'fscm_conn/getSupplierContacts',
              uriParams: {
                id: details.SUPPLIER_ID,
              },
            });

            if (response2.ok) {
              let items =response2.body.items;
              $page.variables.supplierContactsADP.data = items;

              if(items.length >0){
              //   $flow.variables.transReqDetails.supplier_contact_id = items[0].SupplierContactId;
              //  $flow.variables.transReqDetails.supplier_contact = items[0].LastName+', '+items[0].FirstName;
              }
            
            }
          },
        ].map(sequence => sequence()));

      }
      else{
      $page.variables.supplierSIteADP.data = [];
      }

      $page.variables.SupplierId = details.SUPPLIER_ID;
      $flow.variables.transReqDetails.Supplier =details.SUPPLIER_NAME;
      $variables.supplierNumber = details.SUPPLIER_NUMBER;

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.supplierSIteADP,
      });

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.RequisitionBuADP,
      });

      await Actions.resetVariables(context, {
        variables: [
    '$flow.variables.transReqDetails.RequisitioningBUId',
    '$flow.variables.transReqDetails.SupplierSiteId',
  ],
      });


      await $application.functions.closeSpinnerDialog();
    }
  }

  return supplierChangeChain;
});
