define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class poCloseChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $application.functions.openSpinnerDialog();

      const ojDialogCancelPoClose = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-cancel-po',
        method: 'close',
      });

     let communicationMethodFormatted;

switch ($variables.poCancelCommunicationMethod) {
  case "EMAIL":
    communicationMethodFormatted = "E-Mail";
    break;
  case "FAX":
    communicationMethodFormatted = "Fax";
    break;
  case "PRINT":
    communicationMethodFormatted = "Print";
    break;
  default:
    communicationMethodFormatted = $variables.poCancelCommunicationMethod; // fallback to original value
}

let bodyvar = {
  "cancellationReason": $variables.cancelReason,
  "initiatingParty": "buyer",
  "communicationMethod": communicationMethodFormatted,
  "email": $variables.communicationEmail
};


      const response = await Actions.callRest(context, {
        endpoint: 'fscm_conn/cancelPurchaseOrder',
        uriParams: {
          purchaseOrdersUniqID: $flow.variables.transReqDetails.POHeaderId,
        },
        body: bodyvar,
      });

      if (!response.ok) {
        const statusText = await $functions.getStatusText(response.status);

            let errorvar = JSON.stringify(response.body);
            const errorObj = JSON.parse(errorvar);
             const errorMessage = errorObj["o:errorDetails"][0].detail;

          await Actions.fireNotificationEvent(context, {
            message: JSON.stringify(errorMessage),
            summary: statusText,
          });
      } else {

        await Actions.fireNotificationEvent(context, {
          summary: $flow.variables.transReqDetails.OrderNumber + ' canceled successfully!',
          type: 'confirmation',
          displayMode: 'transient',
        });

        const toPoSearch = await Actions.navigateToPage(context, {
          page: 'po-search',
        });
      }

      await $application.functions.closeSpinnerDialog();

    }
  }

  return poCloseChain;
});
