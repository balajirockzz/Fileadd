define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SubmitActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const progresBarOpen = await Actions.callComponentMethod(context, {
        selector: '#ProgresBar',
        method: 'open',
      });

      let lines = $page.variables.requestLinesADP.data;

      const result=await $functions.isTotalAmountUnderLimit($variables.requestLinesADP.data, undefined, $variables.DFFheaders.attachment);

      if (result==true) {

        const allHaveSameSourceAgreementNumber = await $functions.allHaveSameSourceAgreementNumber($variables.requestLinesADP.data);

        if (allHaveSameSourceAgreementNumber === true) {

          const manualPriceCheckfunc = await $functions.manualPriceCheckfunc($variables.requestLinesADP.data, $variables.DFFheaders.attachment);

          if (manualPriceCheckfunc==true) {
          

          if ($flow.variables.transReqDetails.POHeaderId) {

          $variables.DFFheaders.__FLEX_Context = $flow.variables.transReqDetails.DocumentStyle;
          $variables.DFFheaders.__FLEX_Context_DisplayValue = $flow.variables.transReqDetails.DocumentStyle;
          $variables.lineDFF.__FLEX_Context = $flow.variables.transReqDetails.DocumentStyle;
          $variables.lineDFF.__FLEX_Context_DisplayValue = $flow.variables.transReqDetails.DocumentStyle;

            if ($variables.submitComments) {
            

              const ojDialogSubmitClose = await Actions.callComponentMethod(context, {
              selector: '#oj-dialog-submit',
              method: 'close',
              });

            const filteredData = $variables.requestLinesADP.data.filter(item => item.CreatedBy);

            const createPayload1 = await $functions.createchangeOrderPayload($flow.variables.transReqDetails, filteredData, $variables.submitComments, $variables.DFFheaders, $variables.lineDFF);
            

            const response = await Actions.callRest(context, {
              endpoint: 'fscm_conn/patchDraftPurchaseOrdersDraftPurchaseOrdersUniqID',
              body: createPayload1,
              uriParams: {
                draftPurchaseOrdersUniqID: $flow.variables.transReqDetails.POHeaderId,
              },
            });

            if (!response.ok) {

                  const statusText = await $functions.getStatusText(response.status);

            let    errorvar = JSON.stringify(response.body);
                const errorObj = JSON.parse(errorvar);
                 const errorMessage = errorObj["o:errorDetails"][0].detail;
            
              await Actions.fireNotificationEvent(context, {
                summary: JSON.stringify(errorMessage),
              });
            }

              const response5 = await Actions.callRest(context, {
                endpoint: 'fscm_conn/getPurchasingLineTypesLOV',
                fields: 'DefaultMatchApprovalLevelCode,DefaultInvoiceMatchOptionCode',
                onlyData: 'true',
                uriParams: {
                  fields: 'DefaultMatchApprovalLevelCode,DefaultInvoiceMatchOptionCode,DefaultMatchApprovalLevel',
                  onlyData: 'true',
                },
              });

            const createlinePayload = await $functions.createlinePayload($flow.variables.transReqDetails, $variables.requestLinesADP.data, response5.body.items[0], $variables.lineDFF);

            let linedetailsbodyarray = [];
            linedetailsbodyarray = createlinePayload;


                   if (response.ok) {

            

            const results = await ActionUtils.forEach(linedetailsbodyarray.lines, async (item, index) => {

              const response4 = await Actions.callRest(context, {
                endpoint: 'fscm_conn/addLineToPurchaseOrder',
                uriParams: {
                  draftPurchaseOrdersUniqID: $flow.variables.transReqDetails.POHeaderId,
                },
                body: item,
              });

              if (!response4.ok) {
                 $variables.checkFlag = true;
              }

            }, { mode: 'serial' });

            if ($variables.checkFlag === true) {
              await Actions.fireNotificationEvent(context, {
                summary: 'Rest Api error, cannot add line.',
                displayMode: 'transient',
              });

                  const progresBarClose = await Actions.callComponentMethod(context, {
                    selector: '#ProgresBar',
                    method: 'close',
                  });
            }
            }
            if (response.ok && $variables.checkFlag !== true) {
              const response2 = await Actions.callRest(context, {
                endpoint: 'fscm_conn/submitDraftPurchaseOrder',
                uriParams: {
                  draftPurchaseOrdersUniqID: response.body.POHeaderId,
                },
              });

              
              if (!response2.ok) {
                    const statusText2 = await $functions.getStatusText(response2.status);

                let errorvar = JSON.stringify(response.body);
                const errorObj = JSON.parse(errorvar);
                 const errorMessage = errorObj["o:errorDetails"][0].detail;

              await Actions.fireNotificationEvent(context, {
                message: JSON.stringify(errorMessage),
                summary: statusText2,
              });
              }
                

              await Actions.fireNotificationEvent(context, {
                summary: "PO Updated with number : "+ response.body.OrderNumber,
                displayMode: 'transient',
                type: 'info',
              });

                const progresBarClose2 = await Actions.callComponentMethod(context, {
                  selector: '#ProgresBar',
                  method: 'close',
                });

              const toPoSearch = await Actions.navigateToPage(context, {
                page: 'po-search',
              });
           }
           }
           else{
              await Actions.fireNotificationEvent(context, {
                summary: 'Please enter the comments.',
                displayMode: 'transient',
              });

              const progresBarClose3 = await Actions.callComponentMethod(context, {
                selector: '#ProgresBar',
                method: 'close',
              });
            
           }
          } else {

            const response3 = await Actions.callRest(context, {
              endpoint: 'fscm_conn/getPurchasingLineTypesLOV',
              uriParams: {
                fields: 'DefaultMatchApprovalLevelCode,DefaultInvoiceMatchOptionCode,DefaultMatchApprovalLevel',
                onlyData: 'true',
              },
            });

          $variables.DFFheaders.__FLEX_Context = $flow.variables.transReqDetails.DocumentStyle;
          $variables.DFFheaders.__FLEX_Context_DisplayValue = $flow.variables.transReqDetails.DocumentStyle;
          $variables.lineDFF.__FLEX_Context = $flow.variables.transReqDetails.DocumentStyle;
          $variables.lineDFF.__FLEX_Context_DisplayValue = $flow.variables.transReqDetails.DocumentStyle;

            const createPayload1 = await $functions.createPayload($flow.variables.transReqDetails, $variables.requestLinesADP.data, response3.body.items[0], $variables.DFFheaders, $variables.lineDFF);
            

            const response = await Actions.callRest(context, {
              endpoint: 'fscm_conn/postDraftPurchaseOrders',
              body: createPayload1,
            });

            if (response.ok) {
              const response2 = await Actions.callRest(context, {
                endpoint: 'fscm_conn/submitDraftPurchaseOrder',
                uriParams: {
                  draftPurchaseOrdersUniqID: response.body.POHeaderId,
                },
              });


              await Actions.fireNotificationEvent(context, {
                summary: "PO Created with number : "+ response.body.OrderNumber,
                displayMode: 'transient',
                type: 'info',
              });

              if (!response2.ok) {
                  const statusText3 = await $functions.getStatusText(response2.status);

                let errorvar = JSON.stringify(response.body);
                const errorObj = JSON.parse(errorvar);
                 const errorMessage = errorObj["o:errorDetails"][0].detail;

              await Actions.fireNotificationEvent(context, {
                message: JSON.stringify(errorMessage),
                summary: statusText3,
              });
              }

              const progresBarClose4 = await Actions.callComponentMethod(context, {
                selector: '#ProgresBar',
                method: 'close',
              });

              const toPoSearch = await Actions.navigateToPage(context, {
                page: 'po-search',
              });
              } else {

                const statusText4 = await $functions.getStatusText(response.status);

              let errorvar = JSON.stringify(response.body);
                const errorObj = JSON.parse(errorvar);
                 const errorMessage = errorObj["o:errorDetails"][0].detail;

              await Actions.fireNotificationEvent(context, {
                message: JSON.stringify(errorMessage),
                summary: statusText4,
              });

              const progresBarClose5 = await Actions.callComponentMethod(context, {
                selector: '#ProgresBar',
                method: 'close',
              });
           }
          }
          } else {
            await Actions.fireNotificationEvent(context, {
              summary: 'Header Attachment is mandatory if Purchase Order total is greater than 25000 USD OR if price is manually entered. Kindly add an attachment.',
            });
          }
        } else {
           await Actions.fireNotificationEvent(context, {
             summary: 'Either multiple Source BPOs are referenced in this document OR there exists a line without a BPO reference. Kindly ensure all lines are referencing same source document to proceed with approval',
           });
        }
      }
      else{
        

        await Actions.fireNotificationEvent(context, {
          type: 'error',
          displayMode: 'transient',
          summary: 'Header Attachment is mandatory if Purchase Order total is greater than 25000 USD OR if price is manually entered. Kindly add an attachment.',
        });
      }

      // $flow.variables.transReqDetails.lines.items = $variables.requestLinesADP.data;

      const progresBarClose6 = await Actions.callComponentMethod(context, {
        selector: '#ProgresBar',
        method: 'close',
      });

     
      
      
    }
  }

  return SubmitActionChain;
});
