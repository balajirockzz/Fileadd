define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class shiptoValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if(data){
       $flow.variables.transReqDetails.ShipToLocationCode = data.LocationName;

        let location_var='LocationCode='+"'"+data.LocationName+"'";

        // ---- TODO: Add your code here ---- //
        console.log('+++++++++++++++++++++++'+location_var);

        const response = await Actions.callRest(context, {
          endpoint: 'hcm_conn/getLocationsV2_2',
          uriParams: {
            q: location_var,
          },
        });

        if (!response.ok) {
          $variables.org_Error_var = 'OrganizationName='+"'"+' '+"'";
          
          
        } else {

          //  let organization_var='OrganizationName='+"'"+response.body.items[0].InventoryOrganizationName+"'";
          $variables.org_Error_var = 'OrganizationName='+"'"+response.body.items[0].InventoryOrganizationName+"'";

        }

        const response2 = await Actions.callRest(context, {
          endpoint: 'fscm_conn/getInventoryOrganizations2',
          uriParams: {
            q: $variables.org_Error_var,
          },
        });

        if (response2.body.count === 0) {
        } else {
           $variables.organizationCode = response2.body.items[0].OrganizationCode;
        }
      }    }
  }

  return shiptoValueChangeChain;
});
