define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class lineDetailSaveChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {number} params.lineId 
     */
    async run(context, { lineId }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $application.functions.openSpinnerDialog();

 console.log('++line_valid_var++'+$variables.line_valid_var);

      await Actions.callChain(context, {
        chain: 'linesavevalidations',
      });

      if ($variables.line_valid_var === "true" || $variables.line_valid_var === 'Yes'){
        await Actions.resetVariables(context, {
          variables: [
    '$page.variables.reasonCodeFlag',
    '$page.variables.itemBuyerValFlag',
  ],
        });

        if (lineId) {

        if (!lineId.CreatedBy) {

        await Actions.fireDataProviderEvent(context, {
          target: $variables.requestLinesADP,
          remove: {
            data: lineId,
            keys: lineId.POLineId,
          },
        });
        }else {
             let val =  JSON.parse(JSON.stringify(lineId));

        val.CancelFlag ='true';
        val.Status = 'Cancel';


         await Actions.fireDataProviderEvent(context, {
            update: {
              data: val,
              keys: val.POLineId,
            },
            target: $variables.requestLinesADP,
          });
        }
        } else {

        if ($application.functions.isFormValid('line_form')) {   
            if ($variables.lineDetails.Quantity===0) {

        await Actions.fireNotificationEvent(context, {
          summary: 'Quantity cannot be 0',
          displayMode: 'transient',
          type: 'warning',
        });
        }
         if ($variables.lineDetails.Price===0) {

        await Actions.fireNotificationEvent(context, {
          summary: 'Price cannot be 0',
          type: 'warning',
          displayMode: 'transient',
        });
        } if($variables.lineDetails.RequestedDeliveryDate==null) {
        
        await Actions.fireNotificationEvent(context, {
          summary: 'Need by Date should not be Null',
          type: 'warning',
          displayMode: 'transient',
        });
        }
            if ($flow.variables.transReqDetails.DocumentStyle !=='Dell-3PP & SnP Purchase Orders Style') {
            

            if ($variables.DFFlines.itemBuyer1==null || $variables.DFFlines.itemBuyer1==undefined || $variables.DFFlines.itemBuyer1=='') {
               await Actions.fireNotificationEvent(context, {
                 summary: 'No default buyer assigned to item - kindly update Buyer Name to submit PO for Approval',
                 type: 'warning',
                 displayMode: 'transient',
               });
              } else {
                $variables.itemBuyerValFlag = true;
            }
            } else {
              $variables.itemBuyerValFlag = true;
            }
            if ($variables.DFFlines.reasonCode=='40') {
              if ($variables.DFFlines.internalComments===null || $variables.DFFlines.internalComments===undefined || $variables.DFFlines.internalComments==='') {

                  await Actions.fireNotificationEvent(context, {
                   summary: 'Internal Comments are mandatory when reason code selected is One Cost Loaded - Other(write in notes)',
                   type: 'warning',
                   displayMode: 'transient',
                 });
              } else {
                 $variables.reasonCodeFlag = true;
              }
            } else {

              $variables.reasonCodeFlag = true;
            }

        if($page.variables.ManualPriceCheckFlag== false){
            if ($page.variables.DFFlines.reasonCode==null) {
              await Actions.fireNotificationEvent(context, {
          summary: 'Reason code is mandatory when the PO Price is manually entered',
          type: 'warning',
          displayMode: 'transient',
        });
              } else {
                $variables.ManualPriceCheckFlag = true;
            }
        }
              if ($variables.lineDetails.Quantity!==0 && $variables.lineDetails.Price!==0 && $variables.ManualPriceCheckFlag== true  && $variables.itemBuyerValFlag==true && $variables.reasonCodeFlag==true) {
        

     



          if ( $variables.updateLineFlag==true) {

              $variables.lineDetails.POLineId = $variables.lineDetails.LineNumber;
          }
    
 
              
        //      $variables.lineDetails.CreatedBy = $application.user.username;
        //  $variables.lineDetails.LastUpdatedBy = $application.user.username;

        if ($variables.lineDetails.POLineId ) {

          $variables.lineDetails.DFF.items[0].PoLineId= $variables.lineDetails.POLineId;
         $variables.lineDetails.DFF.items[0] = $variables.DFFlines;

          await Actions.fireDataProviderEvent(context, {
            update: {
              data: $variables.lineDetails,
              keys: $variables.lineDetails.POLineId,
            },
            target: $variables.requestLinesADP,
          });
          }
        else {

              const checkitem = await $functions.checkItemsPOline($variables.requestLinesADP.data, $variables.lineDetails);

              if (checkitem.success === false) {

         // $variables.lineDetails.POLineId = $variables.requestLinesADP.data.length + 1;
          $variables.lineDetails.LineNumber = 
  ($page.variables.requestLinesADP.data.length > 0 && 
   $page.variables.requestLinesADP.data[$page.variables.requestLinesADP.data.length - 1].LineNumber !== undefined)
    ? ($page.variables.requestLinesADP.data[$page.variables.requestLinesADP.data.length - 1].LineNumber + 1)
    : 1;
                      // $variables.lineDetails.DFF.items[0].PoLineId= $variables.lineDetails.POLineId;
            $variables.lineDetails.DFF = {
    items: []
};
     $variables.lineDetails.DFF.items[0] = $variables.DFFlines;

          await Actions.fireDataProviderEvent(context, {
            add: {
                data: $variables.lineDetails,
                keys: $variables.lineDetails.POLineId,
                indexes: 0,
            },
            target: $variables.requestLinesADP,
          });
              } else {
                await Actions.fireNotificationEvent(context, {
                  summary: JSON.stringify(checkitem.message),
                  displayMode: 'transient',
                });
              }
           
        
        }

              const lineDialogClose2 = await Actions.callComponentMethod(context, {
                selector: '#lineDialog',
                method: 'close',
              });

                await Actions.resetVariables(context, {
                  variables: [
    '$page.variables.disableItemFlag',
    '$page.variables.updateLineFlag',
    '$page.variables.ManualPriceCheckFlag',
  ],
                });
              }
        }
         
        }

        await $application.functions.closeSpinnerDialog();
      } else if ($variables.line_valid_var === 'falsepolo') {
        await Actions.fireNotificationEvent(context, {
          summary: "PO Creation is blocked due to Inconsistent L/O code with PO Currency"+"("+$flow.variables.transReqDetails.CurrencyCode+")",
        });
      } else if ($variables.line_valid_var === 'No') {
      } else if ($variables.line_valid_var === 'FalseHsnc') {
        await Actions.fireNotificationEvent(context, {
          summary: 'PO Creation is blocked as the Item doesn\'t have an HSN Code assigned at Item Master.',
        });
      }

    
     }
  }

  return lineDetailSaveChain;
});
