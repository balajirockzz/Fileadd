define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class doRequestChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {number} params.headerId 
     * @param {string} params.action 
     */
    async run(context, { headerId, action }) {
      const { $flow, $application, $variables } = context;

      if (action === 'DELETE') {
        const response = await Actions.callRest(context, {
          endpoint: 'ords/deletePO',
          uriParams: {
            id: headerId,
          },
        });

        if (response.ok) {

          await Actions.fireNotificationEvent(context, {
            displayMode: 'transient',
            type: 'confirmation',
            summary: 'Deleted the request ',
          });
        }
      }

      if (action === 'CANCEL') {
        $variables.CancelBPORequestPayload.PO_HeaderId = headerId;
        $variables.CancelBPORequestPayload.CancelReason = "Cancel";

        const response2 = await Actions.callRest(context, {
          endpoint: 'ics_conn/STP_PROC_EXT_005_CANCEL_BPO1_0PurchaseAgreementService2',
          body: $variables.CancelBPORequestPayload,
        });

        if (response2.body.Status === 'Succeeded') {
          await Actions.fireNotificationEvent(context, {
            summary: 'BPO has been canceled successfully.',
            displayMode: 'transient',
            type: 'confirmation',
          });

        } else {
           await Actions.fireNotificationEvent(context, {
             summary: 'Error occurred while cancelling the BPO.',
             type: 'error',
           });
        }
      }
    }
  }

  return doRequestChain;
});
