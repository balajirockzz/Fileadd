define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class openActionHistory extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.PoNumber 
     */
    async run(context, { PoNumber }) {
      const { $flow, $application } = context;

      let actionReport ='/Custom/Extension/STP/STP_PROC_EXT_005_External_Buyer_PO_ActionHistory_Report.xdo';
      let approvalReport ='/Custom/Extension/STP/STP_PROC_EXT_005_External_Buyer_PO_ApprovalHierarchy_Report.xdo';

      let actionArray =[];
      let approvalArray =[];
      const results = await Promise.all([
        async () => {
          const bIPReportPayload = await $application.functions.getBIPReportPayload(approvalReport,PoNumber);

          const BIPReportResult = await Actions.callRest(context, {
            endpoint: 'BIPReport_conn/postExternalReportWSSService',
            body: bIPReportPayload,
          });

          if (BIPReportResult.ok) {
               approvalArray = await $application.functions.getarrayfromBIPReport(BIPReportResult.body);     
               $flow.variables.actionApprovalADP.data = approvalArray;     
         }
        },
        async () => {

          const bIPReportPayload = await $application.functions.getBIPReportPayload(actionReport,PoNumber);

          const BIPReportResult = await Actions.callRest(context, {
            endpoint: 'BIPReport_conn/postExternalReportWSSService',
            body: bIPReportPayload,
          });

          if (BIPReportResult.ok) {
              actionArray = await $application.functions.getarrayfromBIPReport(BIPReportResult.body);     
                    
         }
        },
      ].map(sequence => sequence()));


      const results2 = await ActionUtils.forEach(actionArray, async (item, index) => {

        const results3 = await ActionUtils.forEach(approvalArray, async (data, i) => {
          if(item.PO_VERSION_ID === data.VERSION_ID && item.ACTION_CODE === 'SUBMIT'){
            if(!actionArray[index].approvals)
             actionArray[index].approvals =[];
            actionArray[index].approvals.push(data);
          }


        }, { mode: 'serial' });
        
        
      }, { mode: 'serial' });
           $flow.variables.actionHistoryADP.data = actionArray;
      


     
    }
  }

  return openActionHistory;
});
