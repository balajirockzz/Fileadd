define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class supplierValueItemChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      
     await $application.functions.openSpinnerDialog();

  //     await Actions.resetVariables(context, {
  //       variables: [
  //   '$flow.variables.transReqDetails.supplier_site',
  // ],
  //     });

      if( data && data.SupplierId) {

        const results = await Promise.all([
          async () => {

      const response = await Actions.callRest(context, {
            endpoint: 'fscm_conn/getSuppliersSite',
            uriParams: {
              q: 'SupplierSite in '+ $application.functions.getInClause($flow.variables.supplierAssoc.supplierSiteList),
              SupplierId: data.SupplierId,
            },
      });

          
                  if (response.ok) {
                
               $page.variables.supplierSIteADP.data = response.body.items;
                  }
            
           
          },
          async () => {

            const response2 = await Actions.callRest(context, {
              endpoint: 'fscm_conn/getSupplierContacts',
              uriParams: {
                id: data.SupplierId,
              },
            });

            if (response2.ok) {
              let items =response2.body.items;
              $page.variables.supplierContactsADP.data = items;

              if(items.length >0){
                $flow.variables.transReqDetails.SupplierContactId = items[0].SupplierContactId;
               $flow.variables.transReqDetails.SupplierContact = items[0].LastName+', '+items[0].FirstName;
              }
            
            }
          },
        ].map(sequence => sequence()));

      }
      else{
      $page.variables.supplierSIteADP.data = [];
      }

      $page.variables.SupplierId = data.SupplierId;
      $flow.variables.transReqDetails.Supplier =data.Supplier;

      await $application.functions.closeSpinnerDialog();
    
    }


    
  }

  return supplierValueItemChangeChain;
});
