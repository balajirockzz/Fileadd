define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class CancelBPOLines extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const results = await ActionUtils.forEach($variables.requestLinesADP.data, async (item, index) => {

        // ---- TODO: Add your code here ---- //
        
        console.log("Cancellation start");

        if ($variables.requestLinesADP.data[index].Status ==="Canceled") {
          // ---- TODO: Add your code here ---- //
          console.log("Cancellation start line", + $variables.requestLinesADP.data[index].AgreementLineId);

          $flow.variables.CancelBPORequestPayload.PO_HeaderId = $variables.requestLinesADP.data[index].AgreementHeaderId;
          $flow.variables.CancelBPORequestPayload.PO_LineID = $variables.requestLinesADP.data[index].AgreementLineId;
          $flow.variables.CancelBPORequestPayload.CancelReason = $variables.submitComments;

          const response = await Actions.callRest(context, {
            endpoint: 'ics_conn/STP_PROC_EXT_005_CANCEL_BPO1_0PurchaseAgreementService2',
            body: $flow.variables.CancelBPORequestPayload,
          });

          if (response.body.Status === "Error") {
          }
          //.InterfaceHeaderId .InterfaceLineId
        }
      }, { mode: 'serial' });
    }
  }

  return CancelBPOLines;
});
