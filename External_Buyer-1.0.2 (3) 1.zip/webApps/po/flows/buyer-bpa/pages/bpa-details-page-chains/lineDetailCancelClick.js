define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class lineDetailCancelClick extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {number} params.lineId 
     */
    async run(context, { lineId }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

    

      

        if (lineId) {

          if(!lineId.CreatedBy){

          await Actions.fireDataProviderEvent(context, {
            target: $variables.requestLinesADP,
            remove: {
              data: lineId,
              keys: lineId.AgreementLineId,
            },
          });
          }
          else{

            let val =  JSON.parse(JSON.stringify(lineId));

            val.Status ='Canceled';


           await Actions.fireDataProviderEvent(context, {
                update: {
                  data: val,
                  keys: val.AgreementLineId,
                },
                target: $variables.requestLinesADP,
              }, { id: 'E' });
          }
        } else {

          if ($application.functions.isFormValid('line_form')) {    

            if ($variables.lineDetails.AgreementLineId) {
              await Actions.fireDataProviderEvent(context, {
                update: {
                  data: $variables.lineDetails,
                  keys: $variables.lineDetails.AgreementLineId,
                },
                target: $variables.requestLinesADP,
              }, { id: 'E' });
            }
            else {
              $variables.lineDetails.AgreementLineId = $variables.requestLinesADP.data.length + 1;
             // $variables.lineDetails.line_num = $variables.requestLinesADP.data.length + 1;
               $variables.lineDetails.ActionCode = "ADD";
              await Actions.fireDataProviderEvent(context, {
                add: {
                  data: $variables.lineDetails,
                  keys: $variables.lineDetails.AgreementLineId,
                  indexes: 0,
                },
                target: $variables.requestLinesADP,
              });
            }
          }
         
        

        const lineDialogClose = await Actions.callComponentMethod(context, {
          selector: '#lineDialog',
          method: 'close',
        });
    }
      

      const totalSum = await $functions.calculateAggrementSum($variables.requestLinesADP.data);

      $flow.variables.transReqDetails.AgreementAmount = totalSum;
     }
  }

  return lineDetailCancelClick;
});
