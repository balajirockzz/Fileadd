define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class supplierSiteChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      let reqBuArray =[];

      if(!data)
      data = metadata.itemContext.data;

      if(data){
                        reqBuArray = await $application.functions.filterADPData($application.functions.getADPData($application.variables.buyerAssoc.ASSOCIATIONS,'ASSOCIATION_ID'), [
  'SUPPLIER_SITE_ID',
], [
  data.SUPPLIER_SITE_ID,
]);
        const results = await Promise.all([
          async () => {

                  const responseReqBU = await Actions.callRest(context, {
        endpoint: 'fscm_conn/getSupplierAssignments',
        uriParams: {
          siteId: data.SUPPLIER_SITE_ID,
          supplierId: data.SUPPLIER_ID,
          q: 'ClientBUId in '+$application.functions.getInClause(
            reqBuArray,'REQUISITION_BU_ID'
          ),
        },
      });

            if (responseReqBU.ok) {
              $variables.RequisitionBuADP.data = responseReqBU.body.items;
              if(responseReqBU.body.items.length !==0){
                $variables.controlDetailsTemp.RequisitioningBUId = responseReqBU.body.items[0].ClientBUId;
                $variables.controlDetailsTemp.BilltoBUId = responseReqBU.body.items[0].BillToBUId;
                $variables.controlDetailsTemp.ShipToLocationId = responseReqBU.body.items[0].ShipToLocationId;
                $variables.controlDetailsTemp.BillToLocationId = responseReqBU.body.items[0].BillToLocationId;
                $variables.controlDetailsTemp.RequisitioningBU = responseReqBU.body.items[0].ClientBU;
                $variables.controlDetailsTemp.BillToBU = responseReqBU.body.items[0].BillToBU;
                $variables.controlDetailsTemp.ShipToLocation = responseReqBU.body.items[0].ShipToLocation;
                $variables.controlDetailsTemp.BillToLocation = responseReqBU.body.items[0].BillToLocation;
                 $variables.controlDetailsTemp.EnabledFlag = true;
                $variables.Location_var = responseReqBU.body.items[0].ShipToLocation; 
              
              }
               
            }
            
          },
          async () => {
          
                  const responseReqBU = await Actions.callRest(context, {
                    endpoint: 'fscm_conn/getSupplierAssignments',
                    uriParams: {
                      siteId: data.SUPPLIER_SITE_ID,
                      supplierId: data.SUPPLIER_ID,
                    },
                  });
          
            if (responseReqBU.ok) {
              
              $variables.billToBUADP.data = responseReqBU.body.items;
              
            }
            
          },
          async () => {

            $flow.variables.transReqDetails.SupplierSite = data.SUPPLIER_SITE;

                  const response = await Actions.callRest(context, {
                    endpoint: 'fscm_conn/getSupplierSite',
                    uriParams: {
                      supplierId: data.SUPPLIER_ID,
                      siteId: data.SUPPLIER_SITE_ID,
                    },
                  });
              
                      if (response.ok) {                
                        data = response.body;

      // $flow.variables.transReqDetails.SupplierSite = data? data.SupplierSite:null;
       $flow.variables.transReqDetails.SupplierCommunicationMethodCode = data.CommunicationMethodCode  ? data.CommunicationMethod:null;
       $flow.variables.transReqDetails.SupplierEmailAddress = data.Email  ? data.Email:null;
       $flow.variables.transReqDetails.PaymentTerms = data.PaymentTerms ? data.PaymentTerms:null;
       $flow.variables.transReqDetails.CurrencyCode =data.InvoiceCurrencyCode ? data.InvoiceCurrencyCode:( data.PaymentCurrencyCode? data.PaymentCurrencyCode  :'US Dollar');               $flow.variables.transReqDetails.SupplierSite = data.SupplierSite;
       //added by AT
      // $flow.variables.transReqDetails.Currency = data.InvoiceCurrency ? data.InvoiceCurrency: (data.PaymentCurrency? data.PaymentCurrency :'US Dollar');
       $flow.variables.transReqDetails.FreightTermsCode = data.FreightTermsCode  ? data.FreightTermsCode:null;
        $flow.variables.transReqDetails.FOBCode = data.FOBCode  ? data.FOBCode:null;
                      }
          },
        ].map(sequence => sequence()));


      //  $variables.controlDetails.purchasingsite = data.SupplierSiteId;

    }



  
    }
  }

  return supplierSiteChain;
});
