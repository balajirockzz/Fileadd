define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class supplierChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.details 
     */
    async run(context, { details }) {
      const { $page, $flow, $application, $variables } = context;

      await $application.functions.openSpinnerDialog();

  //     await Actions.resetVariables(context, {
  //       variables: [
  //   '$flow.variables.transReqDetails.supplier_site',
  // ],
  //     });

      const response = await Actions.callRest(context, {
        endpoint: 'fscm_conn/getSuppliersSite',
        uriParams: {
          SupplierId: $variables.lineDetails.SUPPLIER_ID,
        },
      });
        
       $page.variables.supplierSIteADP.data = response.body.items;

      await $application.functions.closeSpinnerDialog();
    }
  }

  return supplierChangeChain;
});
