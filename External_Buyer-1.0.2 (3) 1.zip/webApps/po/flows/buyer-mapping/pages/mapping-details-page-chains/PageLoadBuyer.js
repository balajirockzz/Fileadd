define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageLoadBuyer extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $application.functions.openSpinnerDialog();

      await Actions.resetVariables(context, {
        variables: [
    '$flow.variables.buyerADP',
  ],
      });

      const generateBIPReportREqPayload1 = await $functions.generateBIPReportREqPayload1();

      const responseofthebip = await Actions.callRest(context, {
        endpoint: 'BIPReport_conn/postExternalReportWSSService',
        body: generateBIPReportREqPayload1,
      });

      const convertbipresponseintoarray = await $functions.convertbipresponseintoarray(responseofthebip.body);

      $variables.BuyerADP.data = convertbipresponseintoarray;

      await $application.functions.closeSpinnerDialog();
    }
  }

  return PageLoadBuyer;
});
