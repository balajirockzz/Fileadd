define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class disableLineChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.row 
     * @param {boolean} params.value 
     */
    async run(context, { row, value }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const currentdate = await $functions.currentdateandtime();

      $variables.lineDetails = row;
      $variables.lineDetails.ENABLED_FLAG = value;
      $variables.lineDetails.CREATED_BY = $application.user.username;

         if (value === false) {
        $variables.lineDetails.DISABLED_DATE = currentdate;
      }
      else {
         $variables.lineDetails.DISABLED_DATE = '';
      }

      await Actions.callChain(context, {
        chain: 'lineDetailSaveChain',
        params: {
          lineId: $variables.lineDetails.ASSOCIATION_ID,
        },
      });
    }
  }

  return disableLineChain;
});
