define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class buyerDetailSaveChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.details 
     * @param {string} params.deleteFlag 
     */
    async run(context, { details, deleteFlag = 'N' }) {
      const { $page, $flow, $application, $constants, $variables, $eq } = context;

      await $application.functions.openSpinnerDialog();

      if (deleteFlag === 'Y') {
        await Actions.fireDataProviderEvent(context, {
          remove: {
            data: details,
            keys: [details.PERSON_ID],
          },
          target: $variables.AddBuyerADP,
        });
      }
      else{

     if($variables.lineDetails.CREATED_BY ){



      await Actions.fireDataProviderEvent(context, {
        target: $variables.AddBuyerADP,
        update: {
          data: details,
          keys: [details.PERSON_ID],
        },
      });
         
     }
     else{

          const response = await Actions.callRest(context, {
            endpoint: 'ords_conn/getBuyerGroupDetails',
            uriParams: {
              id: 'U'+details.PERSON_NUMBER,
            },
          });

          if (response.ok) {          
            await Actions.fireNotificationEvent(context, {
              summary: details.DISPLAY_NAME+' is already part of a Buyer Group',
            });
          } else {
                // $variables.lineDetails.CREATED_BY = $application.user.username;
               //  $variables.lineDetails.ASSOCIATION_ID = $variables.mappingDetailsADP.data.length +1;

     await Actions.fireDataProviderEvent(context, {
       add: {
         data: details,
         keys: [details.PERSON_ID],
         indexes: 0,
       },
       target: $variables.AddBuyerADP,
     });

            await Actions.fireNotificationEvent(context, {
              displayMode: 'transient',
              type: 'confirmation',
              summary: details.DISPLAY_NAME+' is added to this Buyer Group',
            });
          }
     }
      }

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.buyerVal',
  ],
      });

      await $application.functions.closeSpinnerDialog();

     }
  }

  return buyerDetailSaveChain;
});
