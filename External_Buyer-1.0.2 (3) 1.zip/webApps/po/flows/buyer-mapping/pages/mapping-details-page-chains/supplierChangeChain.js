define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class supplierChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.details 
     */
    async run(context, { details }) {
      const { $page, $flow, $application } = context;

      await $application.functions.openSpinnerDialog();

  //     await Actions.resetVariables(context, {
  //       variables: [
  //   '$flow.variables.transReqDetails.supplier_site',
  // ],
  //     });

      if( details && details.SupplierId) {

        const results = await Promise.all([
          async () => {

      const response = await Actions.callRest(context, {
            endpoint: 'fscm_conn/getSuppliersSite',
            uriParams: {
              SupplierId: details.SupplierId,
            },
      });

          
                  if (response.ok) {
                
               $page.variables.supplierSIteADP.data = response.body.items;
                  }
            
           
          },
        ].map(sequence => sequence()));

      }
      else{
      $page.variables.supplierSIteADP.data = [];
      }

      $page.variables.SupplierId = details.SupplierId;
      $page.variables.lineDetails.SUPPLIER_NAME =details.Supplier;
      $page.variables.lineDetails.SUPPLIER_NUMBER =details.SupplierNumber;
      $page.variables.lineDetails.SUPPLIER_ID =details.SupplierId;

      await $application.functions.closeSpinnerDialog();
    }
  }

  return supplierChangeChain;
});
