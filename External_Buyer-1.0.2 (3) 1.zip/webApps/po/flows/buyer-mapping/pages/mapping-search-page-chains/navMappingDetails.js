define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navMappingDetails extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.row 
     */
    async run(context, { row }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$flow.variables.transReqDetails',
  ],
      });

      const toBugetTranferDetails = await Actions.navigateToPage(context, {
        page: 'mapping-details',
        params: {
          headerId: row?row.buyer_group_id:'',
        },
      });
    }
  }

  return navMappingDetails;
});
