define([], () => {
  'use strict';

  class PageModule {

 downloadCSVFromArray(dataArray, fileName = "data.csv") {
    if (!dataArray || dataArray.length === 0) {
        console.warn("No data available to export.");
        return;
    }

    const headers = Object.keys(dataArray[0]);
    const csvRows = [];
    csvRows.push(headers.join(","));

    for (const row of dataArray) {
        const values = headers.map(header => {
            const val = row[header] === null || row[header] === undefined ? "" : row[header];
            return `"${String(val).replace(/"/g, '""')}"`;
        });
        csvRows.push(values.join(","));
    }

    const csvString = csvRows.join("\n");
    const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", fileName);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};

  }
  
  return PageModule;
});
