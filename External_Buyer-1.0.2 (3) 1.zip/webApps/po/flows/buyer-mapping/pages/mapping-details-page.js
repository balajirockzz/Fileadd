define([], () => {
  'use strict';

  class PageModule {

    generateBIPReportREqPayload(po_number){
let payload =`<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:pub="http://xmlns.oracle.com/oxp/service/PublicReportService">
   <soap:Header/>
   <soap:Body>
      <pub:runReport>
         <pub:reportRequest>
            <pub:attributeFormat>csv</pub:attributeFormat>
            <pub:parameterNameValues>
               <pub:item>
                  <pub:name>p_po_number</pub:name>
                  <pub:values>
                     <pub:item>`+po_number+`</pub:item>
                  </pub:values>
               </pub:item>
            </pub:parameterNameValues>
            <pub:reportAbsolutePath>/Custom/Extension/STP/STP_PROC_EXT_005_External_Buyer_PO_ActionHistory_Report.xdo</pub:reportAbsolutePath>
            <pub:sizeOfDataChunkDownload>-1</pub:sizeOfDataChunkDownload>
         </pub:reportRequest>
      </pub:runReport>
   </soap:Body>
</soap:Envelope>`;

return payload;

}

    generateBIPReportREqPayload1() {
      let payload = `<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:pub="http://xmlns.oracle.com/oxp/service/PublicReportService">
   <soap:Header/>
   <soap:Body>
      <pub:runReport>
         <pub:reportRequest> 
          <pub:attributeFormat>csv</pub:attributeFormat>
            <pub:reportAbsolutePath>/Custom/GBL_Custom/Extension/STP/PROC/Reports/STP_PROC_EXT_005_External_Buyer_Group_RPT.xdo</pub:reportAbsolutePath>
            <pub:sizeOfDataChunkDownload>-1</pub:sizeOfDataChunkDownload> 
         </pub:reportRequest>
         <pub:appParams>?</pub:appParams>
      </pub:runReport>
   </soap:Body>
</soap:Envelope>`;

      return payload;

    }


    getExternalIdentifierNumber(externalIdentifierNumber_ADP, externalIdentifierTypeSeach){

     
     for (let i = 0; i < externalIdentifierNumber_ADP.length; i++) 
     { if (externalIdentifierNumber_ADP[i].ExternalIdentifierType === externalIdentifierTypeSeach) 
         {  
          return externalIdentifierNumber_ADP[i].ExternalIdentifierNumber; 
        }    
       
     }
     return null;
}



 convertbipresponseintoarray(payload){
 
 
              function parseCSV(str) {
    const rows = [];
    let row = [];
    let value = '';
    let inQuotes = false;
 
    for (let i = 0; i < str.length; i++) {
        const char = str[i];
        const nextChar = str[i + 1];
 
        if (char === '"' && inQuotes && nextChar === '"') {
            value += '"';
            i++;
        } else if (char === '"') {
            inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
            row.push(value);
            value = '';
        } else if (char === '\n' && !inQuotes) {
            row.push(value);
            rows.push(row);
            row = [];
            value = '';
        } else {
            value += char;
        }
    }
 
    if (value) {
        row.push(value);
    }
    if (row.length > 0) {
        rows.push(row);
    }
 
    return rows;
}
 
  const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(payload, "text/xml");
    const base64reportbyte = xmlDoc.querySelector("reportBytes").textContent;
    const base64decode = atob(base64reportbyte);
 
    // Parse the CSV data using the custom parser
    const data = parseCSV(base64decode);
 
 
 
    const titles = data[0];
    const jsonArray = data.slice(1).map(line => {
        return titles.reduce((obj, title, index) => {
            obj[title] = line[index];
            return obj;
        }, {});
    });
 
    // Call the downloadCSV function with jsonArray and headers
 
    return jsonArray;
 
 
 
             
            }
 









      }

     PageModule.prototype.isCrossDivision = function (linesData) {
      let returnVal = 'Y';
      linesData.forEach(element => {
        if(element.from_division !== element.to_division){
          returnVal = 'N';
        }
      });
         return returnVal;
    };

     PageModule.prototype.isSameReviewer = function (linesData) {
      let returnVal = 'Y';
      let from_reviewer = null;
      let to_reviewer = null;
      linesData.forEach(element => {
        if(element.from_reviewer !== element.to_reviewer){
           returnVal = 'N';
        }
        if(from_reviewer && element.from_reviewer !== from_reviewer){
           returnVal = 'FROM';
        }
        if(to_reviewer && element.from_reviewer !== to_reviewer){
           returnVal = 'TO';
        }
        from_reviewer = element.from_reviewer ;
        to_reviewer = element.to_reviewer ;
      });
      return returnVal;
    };
PageModule.prototype.currentdateandtime = function () {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed, so add 1
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};



  
  return PageModule;
});
