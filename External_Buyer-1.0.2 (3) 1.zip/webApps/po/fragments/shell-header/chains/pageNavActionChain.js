define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class pageNavActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.event 
     */
    async run(context, { event }) {
      const { $fragment, $application } = context;

      await Actions.fireEvent(context, {
        event: 'application:navPageEvent',
        payload: {
          page: event.srcElement.id,
        },
      });


      // await Actions.callChain(context, {
      //   chain: 'application:navtoPageActionChain',
      //   params: {
      //     page: event.srcElement.id,
      //   },
      // });
    }
  }

  return pageNavActionChain;
});
