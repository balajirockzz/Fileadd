define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navPoDetails extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.row 
     */
    async run(context, { row }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$flow.variables.transReqDetails',
  ],
      });

      $flow.variables.transReqDetails.buyer_name = $application.user.username;

      if(row && row.po_header_id ){
        const response = await Actions.callRest(context, {
          endpoint: 'fscm/getPurchaseOrder',
          uriParams: {
            purchaseOrdersUniqID: row.po_header_id,
          },
        });

        if (response.ok &&  response.body.StatusCode !== row.po_status) {
          const response2 = await Actions.callRest(context, {
            endpoint: 'ords/updatePODetails',
            uriParams: {
              id: row.request_id ,
            },
            body: { "po_status" : response.body.StatusCode},
          });
        }
       
      }

      const toBugetTranferDetails = await Actions.navigateToPage(context, {
        page: 'bpa-details',
        params: {
          headerId: row && row.request_id ? row.request_id:'' ,
        },
      });
    }
  }

  return navPoDetails;
});
