/* Copyright (c) 2024, Oracle and/or its affiliates */

define(['oj-sp/spectra-shell/config/config','ojs/ojpagingdataproviderview', 'ojs/ojarraydataprovider','ojs/ojconverter-number'],
 function(config,PagingDataProviderView, ArrayDataProvider,ojconverter_number_1, download) {
  'use strict';

  class AppModule {
  }

   AppModule.prototype.closePopUp = function (evt) {
      if (evt) {
        //   $(evt.srcElement).parents( "oj-dialog oj-popup").css("display","none" );
        $(evt.srcElement).parents("oj-dialog,oj-popup").each(function () { this.close(); });
        // $(evt.srcElement).parents( "oj-popup").css("display","none" );
        //  $('.oj-component-overlay').remove();
      }
    };

 AppModule.prototype.getCurConvertor = function (currency) {
     let curConverter = new ojconverter_number_1.IntlNumberConverter({
                  style: 'currency',
                  currency: currency,
                  currencyDisplay: 'code'
              });
         return curConverter;
    };

    // PANEL FORM MANDATORY FEILD VALIDATION
    AppModule.prototype.isFormValid = function (formData) {
      let tracker = document.getElementById(formData);
      if (tracker.valid === "valid") {
        return true;
      } else {
        tracker.showMessages();
        tracker.focusOn("@firstInvalidShown");
        return false;
      }
    };

    // ASSIGN DATA TO PDP VARIABLE
    AppModule.prototype.createPDP = function (dataArray, idattributevalue) {
      return new PagingDataProviderView(new ArrayDataProvider(dataArray, {
        idAttribute: idattributevalue
      }));
    };

    // OPEN LOADING SYMBOL
    AppModule.prototype.openSpinnerDialog = function () {
      document.getElementById("loading").style.display = "block";
    };

    // CLOSE LOADING SYMBOL
    AppModule.prototype.closeSpinnerDialog = function () {
      document.getElementById("loading").style.display = "none";
    };

    // RESET TABLE ROW SELECTION
    AppModule.prototype.resetTableSelection = function (pTableName) {
      document.getElementById(pTableName).selection = [];
    };

    // Get Attachment IFRAME URL
  AppModule.prototype.getCommonAttachAppUrl = function (pDeepLink, pEntityId, pRoValue, pEntityCode, pPkName) {
    let result = "NO_DATA";
    if (pDeepLink !== '' && pEntityId !== '' && pRoValue !== '') {
      let host = window.location.hostname;
      result = "https://" + host + "/" + pDeepLink + "extN=" + pEntityCode + "&pkN=" + pPkName + "&pkV=" + pEntityId + "&ro=" + pRoValue;
    }
    return result;
  };


    AppModule.prototype.getformatteddate = function (pdate) {
      if (pdate) {
        let d = new Date(pdate);
        d = new Date(d.getTime() - 3000000);
        let date_format_str = (d.getDate().toString().length === 2 ? d.getDate().toString() : "0" + d.getDate().toString()) + "-" + d.toLocaleString('default', { month: 'short' }) + "-" + d.getFullYear().toString() + " " + (d.getHours().toString().length == 2 ? d.getHours().toString() : "0" + d.getHours().toString()) + ":" + ((parseInt(d.getMinutes() / 5) * 5).toString().length == 2 ? (parseInt(d.getMinutes() / 5) * 5).toString() : "0" + (parseInt(d.getMinutes() / 5) * 5).toString());
        //       console.log(date_format_str);
        return date_format_str;
      }
      else {
        return '';
      }
    };

    AppModule.prototype.getInClause = function (arrayList,attr) {
      let returnArray =[];
      arrayList.forEach( (item) =>{
        if(item[attr])
        if(!returnArray.includes(item[attr]))
        returnArray.push(item[attr]);
      });      
      if(attr)
      return '(\''+returnArray.toString().replaceAll(",","\',\'")+'\')';
      else
      return '(\''+arrayList.toString().replaceAll(",","\',\'")+'\')';       
    };

    AppModule.prototype.getLOV = function (arrayList) {
      let returnVal =[];
      arrayList.forEach((item) => {
        returnVal.push ( {"label": item , "value" :item });
      }
      );
      console.log('11'+ returnVal);
     return returnVal;
    };

    AppModule.prototype.getADPData = function (arrayList,idAttr) {
      let returnVal =[];
      let arrayItem =[];
      arrayList.forEach((item) => {
        if( !arrayItem.includes(item[idAttr])){
        returnVal.push(item);
        arrayItem.push(item[idAttr]);
        }
      }
      );
     return returnVal;
    };

     AppModule.prototype.getADPData = function (arrayList,idAttr) {
      let returnVal =[];
      let arrayItem =[];
      arrayList.forEach((item) => {
        if( !arrayItem.includes(item[idAttr])){
        returnVal.push(item);
        arrayItem.push(item[idAttr]);
        }
      }
      );
     return returnVal;
    };


     AppModule.prototype.filterADPData = function (arrayList,attrs,vals) {
      let returnVal =[];
      let arrayItem =[];

      if(!attrs || attrs.length <1)
      returnVal =arrayList 
      else{
      arrayList.forEach((item) => {
        let isMatched = false;
        attrs.forEach( (attr,i)=>{
          if(item[attr] === vals[i])
          isMatched = true;
        });
        if(isMatched)
        returnVal.push(item);
      }
      );}
     return returnVal;
    };


    AppModule.prototype.getOnlyDateWithTimezoneAccounted = function (pDate) {
      if (pDate) {
        let d = new Date(pDate);
        let timeZoneDifference = (d.getTimezoneOffset() / 60) * -1; //convert to positive value.
        d.setTime(d.getTime() + (timeZoneDifference * 60) * 60 * 1000);
        return d.toISOString().substring(0, 10);
      }
      else {
        return '';
      }
    };

    AppModule.prototype.getDateTimeWithTimezoneAccounted = function (pDate) {
      if (pDate) {
        let actualDate = pDate;
        if (pDate.endsWith("Z")) {
          actualDate = pDate.replace("Z", "");
        }
        // console.log("======== actualDate ==========>", actualDate);
        let d = new Date(actualDate);
        let timeZoneDifference = (d.getTimezoneOffset() / 60) * -1; //convert to positive value.
        d.setTime(d.getTime() + (timeZoneDifference * 60) * 60 * 1000);
        // console.log("======== d.toISOString() ==========>", d.toISOString());
        return d.toISOString();
      }
      else {
        return '';
      }
    }; 

    AppModule.prototype.getBIPReportPayload = function(reportPath, po_number){
    let payload =`<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:pub="http://xmlns.oracle.com/oxp/service/PublicReportService">
   <soap:Header/>
   <soap:Body>
      <pub:runReport>
         <pub:reportRequest>
            <pub:attributeFormat>csv</pub:attributeFormat>
            <pub:parameterNameValues>
               <pub:item>
                  <pub:name>p_po_number</pub:name>
                  <pub:values>
                     <pub:item>`+po_number+`</pub:item>
                  </pub:values>
               </pub:item>
            </pub:parameterNameValues>
            <pub:reportAbsolutePath>`+reportPath+`</pub:reportAbsolutePath>
            <pub:sizeOfDataChunkDownload>-1</pub:sizeOfDataChunkDownload>
         </pub:reportRequest>
      </pub:runReport>
   </soap:Body>
</soap:Envelope>`;

return payload;



    };

   AppModule.prototype.getBIPReportPayloadExportBPAUtility = function(reportPath, bpa_number,from_date,to_date,buyer,status){
    let payload =`<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:pub="http://xmlns.oracle.com/oxp/service/PublicReportService">
   <soap:Header/>
   <soap:Body>
      <pub:runReport>
         <pub:reportRequest>
            <pub:attributeFormat>csv</pub:attributeFormat>
            <pub:parameterNameValues>
               <pub:item>
                  <pub:name>p_bpa_number</pub:name>
                  <pub:values>
                     <pub:item>`+bpa_number+`</pub:item>
                  </pub:values>
               </pub:item>
                <pub:item>
                  <pub:name>p_start_date</pub:name>
                  <pub:values>
                     <pub:item>`+from_date+`</pub:item>
                  </pub:values>
               </pub:item>
               <pub:item>
                  <pub:name>p_end_date</pub:name>
                  <pub:values>
                     <pub:item>`+to_date+`</pub:item>
                  </pub:values>
               </pub:item>
               <pub:item>
                  <pub:name>p_buyer</pub:name>
                  <pub:values>
                     <pub:item>`+buyer+`</pub:item>
                  </pub:values>
               </pub:item>
               <pub:item>
                  <pub:name>p_order_status</pub:name>
                  <pub:values>
                     <pub:item>`+status+`</pub:item>
                  </pub:values>
               </pub:item>
            </pub:parameterNameValues>
            <pub:reportAbsolutePath>`+reportPath+`</pub:reportAbsolutePath>
            <pub:sizeOfDataChunkDownload>-1</pub:sizeOfDataChunkDownload>
         </pub:reportRequest>
      </pub:runReport>
   </soap:Body>
</soap:Envelope>`;

return payload;



    };




    AppModule.prototype.getarrayfromBIPReport = function(payload){
      const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(payload, "text/xml");

    const base64reportbyte = xmlDoc.querySelector("reportBytes").textContent;

    const base64decode = atob(base64reportbyte);

    const data = base64decode.split("\n");

    const titles = data[0].split(",");

    const jsonArray = data.slice(1, data.length-1).map(line => {
        const values = line.split(",");
        return titles.reduce((obj, title, index) => {
            obj[title] = values[index];
            return obj;
        }, {});
    });

    return jsonArray;
    };
  return AppModule;
});
